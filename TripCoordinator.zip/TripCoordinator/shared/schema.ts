import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  decimal,
  boolean,
  date,
  time,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  preferredBudget: decimal("preferred_budget", { precision: 10, scale: 2 }),
  preferredAreas: text("preferred_areas").array(),
  travelStyle: varchar("travel_style", { length: 50 }),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const trips = pgTable("trips", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  startDate: date("start_date").notNull(),
  endDate: date("end_date").notNull(),
  budget: decimal("budget", { precision: 10, scale: 2 }),
  tripCode: varchar("trip_code", { length: 10 }).unique().notNull(),
  creatorId: varchar("creator_id").notNull().references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const tripParticipants = pgTable("trip_participants", {
  id: serial("id").primaryKey(),
  tripId: integer("trip_id").notNull().references(() => trips.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id),
  joinedAt: timestamp("joined_at").defaultNow(),
});

export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  tripId: integer("trip_id").notNull().references(() => trips.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  date: date("date").notNull(),
  time: time("time"),
  category: varchar("category", { length: 50 }).notNull(),
  estimatedCost: decimal("estimated_cost", { precision: 10, scale: 2 }),
  notes: text("notes"),
  creatorId: varchar("creator_id").notNull().references(() => users.id),
  isLockedIn: boolean("is_locked_in").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const activityVotes = pgTable("activity_votes", {
  id: serial("id").primaryKey(),
  activityId: integer("activity_id").notNull().references(() => activities.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const tripRecommendations = pgTable("trip_recommendations", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  destination: varchar("destination", { length: 255 }).notNull(),
  country: varchar("country", { length: 100 }).notNull(),
  estimatedBudget: decimal("estimated_budget", { precision: 10, scale: 2 }).notNull(),
  duration: integer("duration").notNull(), // in days
  description: text("description").notNull(),
  highlights: text("highlights").array().notNull(),
  bestTime: varchar("best_time", { length: 100 }),
  activities: text("activities").array(),
  budgetBreakdown: jsonb("budget_breakdown"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const tripStories = pgTable("trip_stories", {
  id: serial("id").primaryKey(),
  tripId: integer("trip_id").notNull().references(() => trips.id, { onDelete: "cascade" }),
  authorId: varchar("author_id").notNull().references(() => users.id),
  title: varchar("title").notNull(),
  content: text("content").notNull(),
  images: text("images").array().default([]),
  location: varchar("location"),
  isPublic: boolean("is_public").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const storyLikes = pgTable("story_likes", {
  id: serial("id").primaryKey(),
  storyId: integer("story_id").notNull().references(() => tripStories.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("story_likes_story_id_idx").on(table.storyId),
  index("story_likes_user_id_idx").on(table.userId),
]);

export const storyComments = pgTable("story_comments", {
  id: serial("id").primaryKey(),
  storyId: integer("story_id").notNull().references(() => tripStories.id, { onDelete: "cascade" }),
  authorId: varchar("author_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => [
  index("story_comments_story_id_idx").on(table.storyId),
]);

// AI Travel Companion tables
export const aiDecisions = pgTable("ai_decisions", {
  id: serial("id").primaryKey(),
  tripId: integer("trip_id").notNull().references(() => trips.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  context: text("context").notNull(), // Current situation description
  question: text("question").notNull(), // User's question
  suggestion: text("suggestion").notNull(), // AI's recommendation
  reasoning: text("reasoning").notNull(), // Why this suggestion
  alternatives: text("alternatives").array().default([]), // Other options
  urgency: varchar("urgency", { enum: ["low", "medium", "high", "emergency"] }).default("medium"),
  location: text("location"), // Current location context
  isAccepted: boolean("is_accepted"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Smart Budgeting tables
export const budgetCategories = pgTable("budget_categories", {
  id: serial("id").primaryKey(),
  tripId: integer("trip_id").notNull().references(() => trips.id, { onDelete: "cascade" }),
  name: varchar("name", { length: 100 }).notNull(),
  allocatedAmount: decimal("allocated_amount", { precision: 10, scale: 2 }).notNull(),
  spentAmount: decimal("spent_amount", { precision: 10, scale: 2 }).default("0"),
  color: varchar("color", { length: 7 }).default("#3b82f6"), // Hex color
  createdAt: timestamp("created_at").defaultNow(),
});

export const expenses = pgTable("expenses", {
  id: serial("id").primaryKey(),
  tripId: integer("trip_id").notNull().references(() => trips.id, { onDelete: "cascade" }),
  categoryId: integer("category_id").references(() => budgetCategories.id, { onDelete: "set null" }),
  paidById: varchar("paid_by_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  description: text("description").notNull(),
  splitWith: varchar("split_with").array().default([]), // User IDs to split with
  splitType: varchar("split_type", { enum: ["equal", "custom", "percentage"] }).default("equal"),
  splitAmounts: text("split_amounts"), // JSON string for custom splits
  receiptUrl: text("receipt_url"),
  location: text("location"),
  isSettled: boolean("is_settled").default(false),
  expenseDate: timestamp("expense_date").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Dynamic Social Map tables
export const tripLocations = pgTable("trip_locations", {
  id: serial("id").primaryKey(),
  tripId: integer("trip_id").notNull().references(() => trips.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  name: varchar("name", { length: 200 }).notNull(),
  latitude: decimal("latitude", { precision: 10, scale: 8 }).notNull(),
  longitude: decimal("longitude", { precision: 11, scale: 8 }).notNull(),
  address: text("address"),
  category: varchar("category", { length: 50 }), // restaurant, hotel, attraction, etc.
  rating: decimal("rating", { precision: 2, scale: 1 }),
  visitedAt: timestamp("visited_at"),
  photos: text("photos").array().default([]),
  notes: text("notes"),
  isPublic: boolean("is_public").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const footprintTrail = pgTable("footprint_trail", {
  id: serial("id").primaryKey(),
  tripId: integer("trip_id").notNull().references(() => trips.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  latitude: decimal("latitude", { precision: 10, scale: 8 }).notNull(),
  longitude: decimal("longitude", { precision: 11, scale: 8 }).notNull(),
  accuracy: decimal("accuracy", { precision: 5, scale: 2 }), // GPS accuracy in meters
  activity: varchar("activity", { length: 50 }), // walking, driving, stopped, etc.
  timestamp: timestamp("timestamp").notNull(),
});

// Emotional Itinerary Tracker tables
export const moodCheckins = pgTable("mood_checkins", {
  id: serial("id").primaryKey(),
  tripId: integer("trip_id").notNull().references(() => trips.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  activityId: integer("activity_id").references(() => activities.id, { onDelete: "cascade" }),
  mood: varchar("mood", { enum: ["excited", "happy", "content", "neutral", "tired", "stressed", "disappointed"] }).notNull(),
  energy: integer("energy").notNull(), // 1-5 scale
  satisfaction: integer("satisfaction").notNull(), // 1-5 scale
  notes: text("notes"),
  photos: text("photos").array().default([]),
  location: text("location"),
  weather: text("weather"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const emotionalInsights = pgTable("emotional_insights", {
  id: serial("id").primaryKey(),
  tripId: integer("trip_id").notNull().references(() => trips.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  insight: text("insight").notNull(),
  category: varchar("category", { enum: ["pattern", "recommendation", "warning", "celebration"] }).notNull(),
  confidence: decimal("confidence", { precision: 3, scale: 2 }), // 0-1 confidence score
  relatedMoods: text("related_moods").array().default([]),
  suggestions: text("suggestions").array().default([]),
  createdAt: timestamp("created_at").defaultNow(),
});

// Rescue Me Panic Mode tables
export const emergencyContacts = pgTable("emergency_contacts", {
  id: serial("id").primaryKey(),
  tripId: integer("trip_id").notNull().references(() => trips.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  name: varchar("name", { length: 100 }).notNull(),
  phone: varchar("phone", { length: 20 }).notNull(),
  relationship: varchar("relationship", { length: 50 }),
  isLocal: boolean("is_local").default(false), // Local to trip destination
  isPrimary: boolean("is_primary").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const panicAlerts = pgTable("panic_alerts", {
  id: serial("id").primaryKey(),
  tripId: integer("trip_id").notNull().references(() => trips.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  alertType: varchar("alert_type", { enum: ["medical", "security", "lost", "accident", "general"] }).notNull(),
  severity: varchar("severity", { enum: ["low", "medium", "high", "critical"] }).notNull(),
  location: text("location"),
  latitude: decimal("latitude", { precision: 10, scale: 8 }),
  longitude: decimal("longitude", { precision: 11, scale: 8 }),
  description: text("description"),
  status: varchar("status", { enum: ["active", "acknowledged", "resolved", "false_alarm"] }).default("active"),
  responderId: varchar("responder_id").references(() => users.id),
  resolvedAt: timestamp("resolved_at"),
  contactsNotified: text("contacts_notified").array().default([]),
  localServicesContacted: text("local_services_contacted").array().default([]),
  createdAt: timestamp("created_at").defaultNow(),
});

export const localHelp = pgTable("local_help", {
  id: serial("id").primaryKey(),
  tripId: integer("trip_id").notNull().references(() => trips.id, { onDelete: "cascade" }),
  category: varchar("category", { enum: ["medical", "police", "embassy", "transport", "accommodation", "guide", "translator"] }).notNull(),
  name: varchar("name", { length: 200 }).notNull(),
  phone: varchar("phone", { length: 20 }),
  address: text("address"),
  latitude: decimal("latitude", { precision: 10, scale: 8 }),
  longitude: decimal("longitude", { precision: 11, scale: 8 }),
  website: text("website"),
  hours: text("hours"),
  language: varchar("language", { length: 10 }).default("en"),
  rating: decimal("rating", { precision: 2, scale: 1 }),
  verified: boolean("verified").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  createdTrips: many(trips),
  tripParticipants: many(tripParticipants),
  createdActivities: many(activities),
  activityVotes: many(activityVotes),
  recommendations: many(tripRecommendations),
  tripStories: many(tripStories),
  storyLikes: many(storyLikes),
  storyComments: many(storyComments),
  aiDecisions: many(aiDecisions),
  expenses: many(expenses),
  tripLocations: many(tripLocations),
  footprintTrail: many(footprintTrail),
  moodCheckins: many(moodCheckins),
  emotionalInsights: many(emotionalInsights),
  emergencyContacts: many(emergencyContacts),
  panicAlerts: many(panicAlerts),
}));

export const tripsRelations = relations(trips, ({ one, many }) => ({
  creator: one(users, {
    fields: [trips.creatorId],
    references: [users.id],
  }),
  participants: many(tripParticipants),
  activities: many(activities),
  stories: many(tripStories),
  aiDecisions: many(aiDecisions),
  budgetCategories: many(budgetCategories),
  expenses: many(expenses),
  tripLocations: many(tripLocations),
  footprintTrail: many(footprintTrail),
  moodCheckins: many(moodCheckins),
  emotionalInsights: many(emotionalInsights),
  emergencyContacts: many(emergencyContacts),
  panicAlerts: many(panicAlerts),
  localHelp: many(localHelp),
}));

export const tripParticipantsRelations = relations(tripParticipants, ({ one }) => ({
  trip: one(trips, {
    fields: [tripParticipants.tripId],
    references: [trips.id],
  }),
  user: one(users, {
    fields: [tripParticipants.userId],
    references: [users.id],
  }),
}));

export const activitiesRelations = relations(activities, ({ one, many }) => ({
  trip: one(trips, {
    fields: [activities.tripId],
    references: [trips.id],
  }),
  creator: one(users, {
    fields: [activities.creatorId],
    references: [users.id],
  }),
  votes: many(activityVotes),
}));

export const activityVotesRelations = relations(activityVotes, ({ one }) => ({
  activity: one(activities, {
    fields: [activityVotes.activityId],
    references: [activities.id],
  }),
  user: one(users, {
    fields: [activityVotes.userId],
    references: [users.id],
  }),
}));

export const tripRecommendationsRelations = relations(tripRecommendations, ({ one }) => ({
  user: one(users, {
    fields: [tripRecommendations.userId],
    references: [users.id],
  }),
}));

export const tripStoriesRelations = relations(tripStories, ({ one, many }) => ({
  trip: one(trips, {
    fields: [tripStories.tripId],
    references: [trips.id],
  }),
  author: one(users, {
    fields: [tripStories.authorId],
    references: [users.id],
  }),
  likes: many(storyLikes),
  comments: many(storyComments),
}));

export const storyLikesRelations = relations(storyLikes, ({ one }) => ({
  story: one(tripStories, {
    fields: [storyLikes.storyId],
    references: [tripStories.id],
  }),
  user: one(users, {
    fields: [storyLikes.userId],
    references: [users.id],
  }),
}));

export const storyCommentsRelations = relations(storyComments, ({ one }) => ({
  story: one(tripStories, {
    fields: [storyComments.storyId],
    references: [tripStories.id],
  }),
  author: one(users, {
    fields: [storyComments.authorId],
    references: [users.id],
  }),
}));

// Insert schemas
export const insertTripSchema = createInsertSchema(trips).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertActivitySchema = createInsertSchema(activities).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  isLockedIn: true,
});

export const insertTripParticipantSchema = createInsertSchema(tripParticipants).omit({
  id: true,
  joinedAt: true,
});

export const insertActivityVoteSchema = createInsertSchema(activityVotes).omit({
  id: true,
  createdAt: true,
});

export const insertTripRecommendationSchema = createInsertSchema(tripRecommendations).omit({
  id: true,
  createdAt: true,
});

export const updateUserPreferencesSchema = createInsertSchema(users).pick({
  preferredBudget: true,
  preferredAreas: true,
  travelStyle: true,
});

export const insertTripStorySchema = createInsertSchema(tripStories).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertStoryLikeSchema = createInsertSchema(storyLikes).omit({
  id: true,
  createdAt: true,
});

export const insertStoryCommentSchema = createInsertSchema(storyComments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// New feature schemas
export const insertAiDecisionSchema = createInsertSchema(aiDecisions).omit({
  id: true,
  createdAt: true,
});

export const insertBudgetCategorySchema = createInsertSchema(budgetCategories).omit({
  id: true,
  createdAt: true,
});

export const insertExpenseSchema = createInsertSchema(expenses).omit({
  id: true,
  createdAt: true,
});

export const insertTripLocationSchema = createInsertSchema(tripLocations).omit({
  id: true,
  createdAt: true,
});

export const insertFootprintTrailSchema = createInsertSchema(footprintTrail).omit({
  id: true,
});

export const insertMoodCheckinSchema = createInsertSchema(moodCheckins).omit({
  id: true,
  createdAt: true,
});

export const insertEmotionalInsightSchema = createInsertSchema(emotionalInsights).omit({
  id: true,
  createdAt: true,
});

export const insertEmergencyContactSchema = createInsertSchema(emergencyContacts).omit({
  id: true,
  createdAt: true,
});

export const insertPanicAlertSchema = createInsertSchema(panicAlerts).omit({
  id: true,
  createdAt: true,
});

export const insertLocalHelpSchema = createInsertSchema(localHelp).omit({
  id: true,
  createdAt: true,
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type InsertTrip = z.infer<typeof insertTripSchema>;
export type Trip = typeof trips.$inferSelect;
export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type Activity = typeof activities.$inferSelect;
export type InsertTripParticipant = z.infer<typeof insertTripParticipantSchema>;
export type TripParticipant = typeof tripParticipants.$inferSelect;
export type InsertActivityVote = z.infer<typeof insertActivityVoteSchema>;
export type ActivityVote = typeof activityVotes.$inferSelect;
export type InsertTripRecommendation = z.infer<typeof insertTripRecommendationSchema>;
export type TripRecommendation = typeof tripRecommendations.$inferSelect;
export type UpdateUserPreferences = z.infer<typeof updateUserPreferencesSchema>;
export type InsertTripStory = z.infer<typeof insertTripStorySchema>;
export type TripStory = typeof tripStories.$inferSelect;
export type InsertStoryLike = z.infer<typeof insertStoryLikeSchema>;
export type StoryLike = typeof storyLikes.$inferSelect;
export type InsertStoryComment = z.infer<typeof insertStoryCommentSchema>;
export type StoryComment = typeof storyComments.$inferSelect;

// New feature types
export type InsertAiDecision = z.infer<typeof insertAiDecisionSchema>;
export type AiDecision = typeof aiDecisions.$inferSelect;
export type InsertBudgetCategory = z.infer<typeof insertBudgetCategorySchema>;
export type BudgetCategory = typeof budgetCategories.$inferSelect;
export type InsertExpense = z.infer<typeof insertExpenseSchema>;
export type Expense = typeof expenses.$inferSelect;
export type InsertTripLocation = z.infer<typeof insertTripLocationSchema>;
export type TripLocation = typeof tripLocations.$inferSelect;
export type InsertFootprintTrail = z.infer<typeof insertFootprintTrailSchema>;
export type FootprintTrail = typeof footprintTrail.$inferSelect;
export type InsertMoodCheckin = z.infer<typeof insertMoodCheckinSchema>;
export type MoodCheckin = typeof moodCheckins.$inferSelect;
export type InsertEmotionalInsight = z.infer<typeof insertEmotionalInsightSchema>;
export type EmotionalInsight = typeof emotionalInsights.$inferSelect;
export type InsertEmergencyContact = z.infer<typeof insertEmergencyContactSchema>;
export type EmergencyContact = typeof emergencyContacts.$inferSelect;
export type InsertPanicAlert = z.infer<typeof insertPanicAlertSchema>;
export type PanicAlert = typeof panicAlerts.$inferSelect;
export type InsertLocalHelp = z.infer<typeof insertLocalHelpSchema>;
export type LocalHelp = typeof localHelp.$inferSelect;
