import OpenAI from "openai";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

interface ChatRequest {
  message: string;
  tripContext?: {
    tripName?: string;
    destination?: string;
    budget?: string;
    startDate?: string;
    endDate?: string;
  };
  userContext?: {
    userId?: string;
    userName?: string;
  };
}

export class AssistantService {
  async generateResponse(request: ChatRequest): Promise<{ message: string }> {
    try {
      const systemPrompt = this.buildSystemPrompt(request.tripContext);
      const userMessage = this.buildUserMessage(request);

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: systemPrompt,
          },
          {
            role: "user",
            content: userMessage,
          },
        ],
        temperature: 0.7,
        max_tokens: 500,
      });

      const assistantMessage = response.choices[0]?.message?.content || 
        "I'm sorry, I couldn't generate a response. Please try again.";

      return { message: assistantMessage };
    } catch (error) {
      console.error("Assistant service error:", error);
      throw new Error("Failed to generate assistant response");
    }
  }

  private buildSystemPrompt(tripContext?: ChatRequest['tripContext']): string {
    let prompt = `You are a helpful travel planning assistant for the Planit app. You help users plan trips, suggest activities, provide travel advice, and answer questions about using the app.

Your key capabilities:
- Trip planning advice and suggestions
- Activity recommendations based on destination and interests
- Budget planning and cost estimates
- Travel tips and logistics advice
- App usage guidance and support
- Restaurant and accommodation suggestions
- Packing lists and travel essentials

Guidelines:
- Be friendly, helpful, and encouraging
- Provide practical, actionable advice
- Ask clarifying questions when needed
- Keep responses concise but informative
- Focus on the user's specific needs and context
- If you don't know something specific, acknowledge it and suggest alternatives`;

    if (tripContext) {
      prompt += `\n\nCurrent trip context:`;
      if (tripContext.tripName) prompt += `\n- Trip: ${tripContext.tripName}`;
      if (tripContext.destination) prompt += `\n- Destination: ${tripContext.destination}`;
      if (tripContext.budget) prompt += `\n- Budget: $${tripContext.budget}`;
      if (tripContext.startDate && tripContext.endDate) {
        prompt += `\n- Dates: ${tripContext.startDate} to ${tripContext.endDate}`;
      }
    }

    return prompt;
  }

  private buildUserMessage(request: ChatRequest): string {
    let message = request.message;

    if (request.userContext?.userName) {
      message = `${request.userContext.userName} asks: ${message}`;
    }

    return message;
  }
}

export const assistantService = new AssistantService();