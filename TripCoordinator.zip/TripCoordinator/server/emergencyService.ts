import { db } from "./db";
import { 
  emergencyContacts, 
  panicAlerts, 
  localHelp,
  type InsertEmergencyContact,
  type InsertPanicAlert,
  type InsertLocalHelp,
  type EmergencyContact,
  type PanicAlert,
  type LocalHelp 
} from "@shared/schema";
import { eq, and, sql } from "drizzle-orm";

interface EmergencyResponse {
  alertId: number;
  localServices: LocalHelp[];
  emergencyContacts: EmergencyContact[];
  autoActions: string[];
  immediateSteps: string[];
}

interface LocationData {
  latitude: number;
  longitude: number;
  address?: string;
}

export class EmergencyService {
  async createPanicAlert(alertData: InsertPanicAlert): Promise<EmergencyResponse> {
    // Create the panic alert
    const [alert] = await db
      .insert(panicAlerts)
      .values({
        ...alertData,
        status: "active",
      })
      .returning();

    // Get emergency contacts for the trip
    const contacts = await db
      .select()
      .from(emergencyContacts)
      .where(
        and(
          eq(emergencyContacts.tripId, alertData.tripId),
          eq(emergencyContacts.userId, alertData.userId)
        )
      );

    // Get local help services based on alert type and location
    const services = await this.findLocalServices(
      alertData.tripId,
      alertData.alertType,
      alertData.latitude ? {
        latitude: parseFloat(alertData.latitude.toString()),
        longitude: parseFloat(alertData.longitude?.toString() || "0"),
      } : undefined
    );

    // Generate automatic actions based on severity
    const autoActions = this.generateAutoActions(alert, contacts, services);
    
    // Generate immediate steps for the user
    const immediateSteps = this.generateImmediateSteps(alert);

    // Execute auto-actions if critical severity
    if (alert.severity === "critical") {
      await this.executeEmergencyProtocol(alert, contacts, services);
    }

    return {
      alertId: alert.id,
      localServices: services,
      emergencyContacts: contacts,
      autoActions,
      immediateSteps,
    };
  }

  async updateAlertStatus(
    alertId: number, 
    status: "active" | "acknowledged" | "resolved" | "false_alarm",
    responderId?: string
  ): Promise<PanicAlert> {
    const updateData: Partial<InsertPanicAlert> = {
      status,
      responderId,
    };

    if (status === "resolved") {
      updateData.resolvedAt = new Date();
    }

    const [updatedAlert] = await db
      .update(panicAlerts)
      .set(updateData)
      .where(eq(panicAlerts.id, alertId))
      .returning();

    return updatedAlert;
  }

  async addEmergencyContact(contactData: InsertEmergencyContact): Promise<EmergencyContact> {
    const [contact] = await db
      .insert(emergencyContacts)
      .values(contactData)
      .returning();

    return contact;
  }

  async updateEmergencyContact(
    contactId: number, 
    updates: Partial<InsertEmergencyContact>
  ): Promise<EmergencyContact> {
    const [updatedContact] = await db
      .update(emergencyContacts)
      .set(updates)
      .where(eq(emergencyContacts.id, contactId))
      .returning();

    return updatedContact;
  }

  async deleteEmergencyContact(contactId: number): Promise<void> {
    await db.delete(emergencyContacts).where(eq(emergencyContacts.id, contactId));
  }

  async getTripEmergencyContacts(tripId: number, userId: string): Promise<EmergencyContact[]> {
    return await db
      .select()
      .from(emergencyContacts)
      .where(
        and(
          eq(emergencyContacts.tripId, tripId),
          eq(emergencyContacts.userId, userId)
        )
      );
  }

  async addLocalHelpService(serviceData: InsertLocalHelp): Promise<LocalHelp> {
    const [service] = await db
      .insert(localHelp)
      .values(serviceData)
      .returning();

    return service;
  }

  async findLocalServices(
    tripId: number,
    category?: string,
    location?: LocationData,
    radius: number = 50000 // 50km default radius in meters
  ): Promise<LocalHelp[]> {
    let query = db.select().from(localHelp).where(eq(localHelp.tripId, tripId));

    if (category) {
      query = query.where(eq(localHelp.category, category as any));
    }

    // If location provided, could add distance calculation
    // For now, return all services for the trip
    const services = await query;

    // Sort by verified status and rating
    return services.sort((a, b) => {
      if (a.verified !== b.verified) return a.verified ? -1 : 1;
      const ratingA = parseFloat(a.rating?.toString() || "0");
      const ratingB = parseFloat(b.rating?.toString() || "0");
      return ratingB - ratingA;
    });
  }

  async getTripAlerts(tripId: number, activeOnly: boolean = false): Promise<PanicAlert[]> {
    let query = db.select().from(panicAlerts).where(eq(panicAlerts.tripId, tripId));

    if (activeOnly) {
      query = query.where(eq(panicAlerts.status, "active"));
    }

    return await query.orderBy(sql`${panicAlerts.createdAt} DESC`);
  }

  async getUserAlerts(userId: string, activeOnly: boolean = false): Promise<PanicAlert[]> {
    let query = db.select().from(panicAlerts).where(eq(panicAlerts.userId, userId));

    if (activeOnly) {
      query = query.where(eq(panicAlerts.status, "active"));
    }

    return await query.orderBy(sql`${panicAlerts.createdAt} DESC`);
  }

  private generateAutoActions(
    alert: PanicAlert, 
    contacts: EmergencyContact[], 
    services: LocalHelp[]
  ): string[] {
    const actions: string[] = [];

    // Notification actions
    if (contacts.length > 0) {
      const primaryContacts = contacts.filter(c => c.isPrimary);
      const contactsToNotify = primaryContacts.length > 0 ? primaryContacts : contacts.slice(0, 2);
      
      actions.push(`Automatically notifying ${contactsToNotify.length} emergency contacts`);
    }

    // Service recommendations
    const relevantServices = services.filter(s => 
      s.category === this.mapAlertTypeToServiceCategory(alert.alertType)
    );

    if (relevantServices.length > 0) {
      actions.push(`Found ${relevantServices.length} nearby ${alert.alertType} services`);
    }

    // Location sharing
    if (alert.latitude && alert.longitude) {
      actions.push("Automatically sharing location with emergency contacts");
    }

    // Severity-specific actions
    if (alert.severity === "critical") {
      actions.push("Escalating to local emergency services");
      actions.push("Activating continuous location tracking");
    }

    return actions;
  }

  private generateImmediateSteps(alert: PanicAlert): string[] {
    const steps: string[] = [];

    switch (alert.alertType) {
      case "medical":
        steps.push("If life-threatening, call local emergency number immediately");
        steps.push("Find nearest hospital or medical facility");
        steps.push("Contact your travel insurance provider");
        steps.push("Keep important medical information accessible");
        break;

      case "security":
        steps.push("Move to a safe, public location if possible");
        steps.push("Contact local police if in immediate danger");
        steps.push("Notify your accommodation or tour guide");
        steps.push("Keep emergency contacts informed of your status");
        break;

      case "lost":
        steps.push("Stay calm and retrace your steps");
        steps.push("Use GPS navigation to find nearest landmark");
        steps.push("Contact your group or accommodation");
        steps.push("Consider using local transportation to return");
        break;

      case "accident":
        steps.push("Ensure everyone's safety first");
        steps.push("Call emergency services if injuries occurred");
        steps.push("Document the incident with photos if safe");
        steps.push("Contact local authorities and insurance");
        break;

      default:
        steps.push("Assess the situation and your immediate safety");
        steps.push("Contact emergency services if needed");
        steps.push("Reach out to your emergency contacts");
        steps.push("Follow local emergency procedures");
    }

    return steps;
  }

  private async executeEmergencyProtocol(
    alert: PanicAlert,
    contacts: EmergencyContact[],
    services: LocalHelp[]
  ): Promise<void> {
    // In a real implementation, this would:
    // 1. Send SMS/calls to emergency contacts
    // 2. Share location data
    // 3. Contact local emergency services if needed
    // 4. Activate continuous monitoring

    const contactsToNotify = contacts.filter(c => c.isPrimary).slice(0, 3);
    const servicesToContact = services
      .filter(s => s.verified && s.category === this.mapAlertTypeToServiceCategory(alert.alertType))
      .slice(0, 2);

    // Update alert with executed actions
    await db
      .update(panicAlerts)
      .set({
        contactsNotified: contactsToNotify.map(c => c.id.toString()),
        localServicesContacted: servicesToContact.map(s => s.id.toString()),
      })
      .where(eq(panicAlerts.id, alert.id));
  }

  private mapAlertTypeToServiceCategory(alertType: string): string {
    switch (alertType) {
      case "medical": return "medical";
      case "security": return "police";
      case "lost": return "guide";
      case "accident": return "medical";
      default: return "police";
    }
  }

  async getEmergencyNumbers(tripId: number): Promise<Record<string, string>> {
    // In a real implementation, this would fetch country-specific emergency numbers
    // based on the trip destination
    return {
      police: "112", // European emergency number
      medical: "112",
      fire: "112",
      tourist_police: "+1-555-HELP", // Example tourist helpline
      embassy: "+1-555-EMBASSY", // Example embassy contact
    };
  }
}

export const emergencyService = new EmergencyService();