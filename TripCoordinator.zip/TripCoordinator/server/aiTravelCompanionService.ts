import OpenAI from "openai";
import { db } from "./db";
import { aiDecisions, type InsertAiDecision, type AiDecision } from "@shared/schema";
import { eq, and, desc } from "drizzle-orm";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

interface DecisionRequest {
  tripId: number;
  userId: string;
  context: string;
  question: string;
  location?: string;
  urgency?: "low" | "medium" | "high" | "emergency";
  timeOfDay?: string;
  weather?: string;
  budget?: number;
  groupSize?: number;
}

interface DecisionResponse {
  suggestion: string;
  reasoning: string;
  alternatives: string[];
  urgency: "low" | "medium" | "high" | "emergency";
  confidence: number;
  actionItems?: string[];
  warnings?: string[];
}

export class AiTravelCompanionService {
  async generateDecision(request: DecisionRequest): Promise<AiDecision> {
    try {
      // Get recent decisions for context
      const recentDecisions = await db
        .select()
        .from(aiDecisions)
        .where(
          and(
            eq(aiDecisions.tripId, request.tripId),
            eq(aiDecisions.userId, request.userId)
          )
        )
        .orderBy(desc(aiDecisions.createdAt))
        .limit(5);

      const systemPrompt = this.buildSystemPrompt(request, recentDecisions);
      const userMessage = this.buildUserMessage(request);

      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userMessage },
        ],
        response_format: { type: "json_object" },
        temperature: 0.7,
        max_tokens: 1000,
      });

      const decisionData = JSON.parse(response.choices[0].message.content || "{}") as DecisionResponse;

      // Store the decision in database
      const insertData: InsertAiDecision = {
        tripId: request.tripId,
        userId: request.userId,
        context: request.context,
        question: request.question,
        suggestion: decisionData.suggestion,
        reasoning: decisionData.reasoning,
        alternatives: decisionData.alternatives,
        urgency: decisionData.urgency || request.urgency || "medium",
        location: request.location,
      };

      const [savedDecision] = await db
        .insert(aiDecisions)
        .values(insertData)
        .returning();

      return savedDecision;
    } catch (error) {
      console.error("Error generating AI decision:", error);
      throw new Error("Failed to generate travel decision");
    }
  }

  async acceptDecision(decisionId: number): Promise<void> {
    await db
      .update(aiDecisions)
      .set({ isAccepted: true })
      .where(eq(aiDecisions.id, decisionId));
  }

  async getTripDecisions(tripId: number, userId: string, limit: number = 20): Promise<AiDecision[]> {
    return await db
      .select()
      .from(aiDecisions)
      .where(
        and(
          eq(aiDecisions.tripId, tripId),
          eq(aiDecisions.userId, userId)
        )
      )
      .orderBy(desc(aiDecisions.createdAt))
      .limit(limit);
  }

  async getEmergencyDecision(request: DecisionRequest): Promise<AiDecision> {
    const emergencyRequest = {
      ...request,
      urgency: "emergency" as const,
      context: `EMERGENCY SITUATION: ${request.context}`,
    };

    const systemPrompt = `You are an AI travel emergency assistant. Provide immediate, actionable advice for emergency situations.
    
    EMERGENCY PROTOCOLS:
    - Prioritize safety above all else
    - Provide clear, step-by-step instructions
    - Include emergency contact information when relevant
    - Suggest immediate actions and backup plans
    - Consider local emergency services and resources
    
    Format your response as JSON with:
    {
      "suggestion": "Primary immediate action to take",
      "reasoning": "Why this is the best immediate response",
      "alternatives": ["Alternative emergency options"],
      "urgency": "emergency",
      "confidence": 0.95,
      "actionItems": ["Step 1", "Step 2", "Step 3"],
      "warnings": ["Important safety warnings"]
    }`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: `EMERGENCY: ${emergencyRequest.question}\nContext: ${emergencyRequest.context}\nLocation: ${emergencyRequest.location || "Unknown"}` },
        ],
        response_format: { type: "json_object" },
        temperature: 0.3, // Lower temperature for more consistent emergency responses
        max_tokens: 1200,
      });

      const decisionData = JSON.parse(response.choices[0].message.content || "{}") as DecisionResponse;

      const insertData: InsertAiDecision = {
        tripId: emergencyRequest.tripId,
        userId: emergencyRequest.userId,
        context: emergencyRequest.context,
        question: emergencyRequest.question,
        suggestion: decisionData.suggestion,
        reasoning: decisionData.reasoning,
        alternatives: decisionData.alternatives,
        urgency: "emergency",
        location: emergencyRequest.location,
      };

      const [savedDecision] = await db
        .insert(aiDecisions)
        .values(insertData)
        .returning();

      return savedDecision;
    } catch (error) {
      console.error("Error generating emergency decision:", error);
      throw new Error("Failed to generate emergency travel decision");
    }
  }

  private buildSystemPrompt(request: DecisionRequest, recentDecisions: AiDecision[]): string {
    const contextHistory = recentDecisions.length > 0 
      ? `Recent decisions made:\n${recentDecisions.map(d => `- ${d.question}: ${d.suggestion}`).join('\n')}\n\n`
      : '';

    return `You are an AI Travel Companion providing real-time decision assistance for travelers.

    Your role:
    - Provide practical, actionable travel advice
    - Consider safety, budget, time, and local conditions
    - Offer multiple options when possible
    - Be concise but thorough
    - Prioritize user safety and satisfaction

    Context Information:
    - Current location: ${request.location || "Not specified"}
    - Time of day: ${request.timeOfDay || "Not specified"}
    - Weather: ${request.weather || "Not specified"}
    - Budget consideration: ${request.budget ? `$${request.budget}` : "Not specified"}
    - Group size: ${request.groupSize || "Not specified"}
    - Urgency level: ${request.urgency || "medium"}

    ${contextHistory}

    Guidelines:
    - For low urgency: Provide thoughtful recommendations with multiple options
    - For medium urgency: Focus on practical solutions with quick implementation
    - For high urgency: Prioritize immediate, actionable advice
    - For emergency: Focus on safety and immediate assistance

    Format your response as JSON with:
    {
      "suggestion": "Primary recommendation",
      "reasoning": "Why this is the best option",
      "alternatives": ["Other viable options"],
      "urgency": "assessed urgency level",
      "confidence": 0.85
    }`;
  }

  private buildUserMessage(request: DecisionRequest): string {
    return `Current situation: ${request.context}

    Question: ${request.question}

    Please provide a helpful travel decision with practical advice.`;
  }
}

export const aiTravelCompanionService = new AiTravelCompanionService();