import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertTripSchema, insertActivitySchema, insertTripParticipantSchema, insertActivityVoteSchema, updateUserPreferencesSchema, insertTripStorySchema, insertStoryCommentSchema } from "@shared/schema";
import { recommendationService } from "./recommendationService";
import { assistantService } from "./assistantService";
import { z } from "zod";

function generateTripCode(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < 8; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Trip routes
  // Demo mode trip creation (for interview demo)
  app.post('/api/trips/demo', async (req, res) => {
    try {
      // Use a fixed demo user ID for consistency
      const demoUserId = "demo-user-interview";
      
      // Ensure demo user exists
      try {
        let demoUser = await storage.getUser(demoUserId);
        if (!demoUser) {
          demoUser = await storage.upsertUser({
            id: demoUserId,
            email: "demo@interview.com",
            firstName: "Demo",
            lastName: "User",
            profileImageUrl: null,
          });
        }
      } catch (userError) {
        console.log("Creating demo user:", userError);
      }
      
      const tripData = insertTripSchema.parse({
        ...req.body,
        creatorId: demoUserId,
        tripCode: generateTripCode(),
      });
      
      const trip = await storage.createTrip(tripData);
      
      // Add creator as participant
      try {
        await storage.addTripParticipant({
          tripId: trip.id,
          userId: demoUserId,
        });
      } catch (participantError) {
        console.log("Participant creation failed, continuing:", participantError);
      }
      
      res.json(trip);
    } catch (error) {
      console.error("Error creating demo trip:", error);
      res.status(500).json({ message: "Failed to create demo trip", error: error.message });
    }
  });

  app.post('/api/trips', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const tripData = insertTripSchema.parse({
        ...req.body,
        creatorId: userId,
        tripCode: generateTripCode(),
      });
      
      const trip = await storage.createTrip(tripData);
      res.json(trip);
    } catch (error) {
      console.error("Error creating trip:", error);
      res.status(500).json({ message: "Failed to create trip" });
    }
  });

  app.get('/api/trips', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const trips = await storage.getUserTrips(userId);
      res.json(trips);
    } catch (error) {
      console.error("Error fetching trips:", error);
      res.status(500).json({ message: "Failed to fetch trips" });
    }
  });

  app.get('/api/trips/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const tripId = parseInt(req.params.id);
      
      // Check if user is participant
      const isParticipant = await storage.isUserTripParticipant(tripId, userId);
      if (!isParticipant) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const trip = await storage.getTripById(tripId);
      if (!trip) {
        return res.status(404).json({ message: "Trip not found" });
      }
      
      res.json(trip);
    } catch (error) {
      console.error("Error fetching trip:", error);
      res.status(500).json({ message: "Failed to fetch trip" });
    }
  });

  app.delete('/api/trips/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const tripId = parseInt(req.params.id);
      
      const trip = await storage.getTripById(tripId);
      if (!trip) {
        return res.status(404).json({ message: "Trip not found" });
      }
      
      if (trip.creatorId !== userId) {
        return res.status(403).json({ message: "Only trip creator can delete trip" });
      }
      
      await storage.deleteTrip(tripId);
      res.json({ message: "Trip deleted successfully" });
    } catch (error) {
      console.error("Error deleting trip:", error);
      res.status(500).json({ message: "Failed to delete trip" });
    }
  });

  // Join trip by code
  app.post('/api/trips/join', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { tripCode } = req.body;
      
      const trip = await storage.getTripByCode(tripCode);
      if (!trip) {
        return res.status(404).json({ message: "Trip not found" });
      }
      
      // Check if already participant
      const isParticipant = await storage.isUserTripParticipant(trip.id, userId);
      if (isParticipant) {
        return res.status(400).json({ message: "Already a participant" });
      }
      
      await storage.addTripParticipant({
        tripId: trip.id,
        userId,
      });
      
      res.json({ message: "Joined trip successfully", trip });
    } catch (error) {
      console.error("Error joining trip:", error);
      res.status(500).json({ message: "Failed to join trip" });
    }
  });

  // Leave trip
  app.post('/api/trips/:id/leave', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const tripId = parseInt(req.params.id);
      
      const trip = await storage.getTripById(tripId);
      if (!trip) {
        return res.status(404).json({ message: "Trip not found" });
      }
      
      if (trip.creatorId === userId) {
        return res.status(400).json({ message: "Trip creator cannot leave trip" });
      }
      
      await storage.removeTripParticipant(tripId, userId);
      res.json({ message: "Left trip successfully" });
    } catch (error) {
      console.error("Error leaving trip:", error);
      res.status(500).json({ message: "Failed to leave trip" });
    }
  });

  // Trip participants
  app.get('/api/trips/:id/participants', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const tripId = parseInt(req.params.id);
      
      const isParticipant = await storage.isUserTripParticipant(tripId, userId);
      if (!isParticipant) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const participants = await storage.getTripParticipants(tripId);
      res.json(participants);
    } catch (error) {
      console.error("Error fetching participants:", error);
      res.status(500).json({ message: "Failed to fetch participants" });
    }
  });

  // Activity routes
  app.get('/api/trips/:id/activities', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const tripId = parseInt(req.params.id);
      
      const isParticipant = await storage.isUserTripParticipant(tripId, userId);
      if (!isParticipant) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const activities = await storage.getTripActivities(tripId);
      res.json(activities);
    } catch (error) {
      console.error("Error fetching activities:", error);
      res.status(500).json({ message: "Failed to fetch activities" });
    }
  });

  app.post('/api/trips/:id/activities', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const tripId = parseInt(req.params.id);
      
      const isParticipant = await storage.isUserTripParticipant(tripId, userId);
      if (!isParticipant) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const activityData = insertActivitySchema.parse({
        ...req.body,
        tripId,
        creatorId: userId,
      });
      
      const activity = await storage.createActivity(activityData);
      res.json(activity);
    } catch (error) {
      console.error("Error creating activity:", error);
      res.status(500).json({ message: "Failed to create activity" });
    }
  });

  app.put('/api/activities/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const activityId = parseInt(req.params.id);
      
      // For simplicity, allow any trip participant to edit activities
      // In a more complex system, you might want to restrict to activity creator
      const updateData = insertActivitySchema.partial().parse(req.body);
      const activity = await storage.updateActivity(activityId, updateData);
      res.json(activity);
    } catch (error) {
      console.error("Error updating activity:", error);
      res.status(500).json({ message: "Failed to update activity" });
    }
  });

  app.delete('/api/activities/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const activityId = parseInt(req.params.id);
      
      await storage.deleteActivity(activityId);
      res.json({ message: "Activity deleted successfully" });
    } catch (error) {
      console.error("Error deleting activity:", error);
      res.status(500).json({ message: "Failed to delete activity" });
    }
  });

  // Vote routes
  app.post('/api/activities/:id/vote', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const activityId = parseInt(req.params.id);
      
      const voteData = insertActivityVoteSchema.parse({
        activityId,
        userId,
      });
      
      const added = await storage.toggleActivityVote(voteData);
      res.json({ voted: added });
    } catch (error) {
      console.error("Error toggling vote:", error);
      res.status(500).json({ message: "Failed to toggle vote" });
    }
  });

  // Recommendation routes
  app.post('/api/recommendations/generate', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { budget, preferredAreas, travelStyle, duration, travelDates } = req.body;
      
      if (!budget || budget <= 0) {
        return res.status(400).json({ message: "Valid budget is required" });
      }
      
      const recommendations = await recommendationService.generateRecommendations(userId, {
        budget: parseFloat(budget),
        preferredAreas: preferredAreas || [],
        travelStyle,
        duration: duration || 7,
        travelDates,
      });
      
      res.json(recommendations);
    } catch (error) {
      console.error("Error generating recommendations:", error);
      res.status(500).json({ message: "Failed to generate recommendations" });
    }
  });

  app.get('/api/recommendations', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const limit = parseInt(req.query.limit as string) || 10;
      
      const recommendations = await recommendationService.getUserRecommendations(userId, limit);
      res.json(recommendations);
    } catch (error) {
      console.error("Error fetching recommendations:", error);
      res.status(500).json({ message: "Failed to fetch recommendations" });
    }
  });

  app.delete('/api/recommendations/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const recommendationId = parseInt(req.params.id);
      
      await recommendationService.deleteRecommendation(userId, recommendationId);
      res.json({ message: "Recommendation deleted successfully" });
    } catch (error) {
      console.error("Error deleting recommendation:", error);
      res.status(500).json({ message: "Failed to delete recommendation" });
    }
  });

  app.put('/api/user/preferences', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const preferences = updateUserPreferencesSchema.parse(req.body);
      
      await recommendationService.updateUserPreferences(userId, preferences);
      res.json({ message: "Preferences updated successfully" });
    } catch (error) {
      console.error("Error updating preferences:", error);
      res.status(500).json({ message: "Failed to update preferences" });
    }
  });

  app.post('/api/recommendations/:id/create-trip', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const recommendationId = parseInt(req.params.id);
      
      const recommendations = await storage.getUserRecommendations(userId, 50);
      const recommendation = recommendations.find(r => r.id === recommendationId);
      
      if (!recommendation) {
        return res.status(404).json({ message: "Recommendation not found" });
      }
      
      const tripData = insertTripSchema.parse({
        name: `${recommendation.destination} Adventure`,
        startDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 30 days from now
        endDate: new Date(Date.now() + (30 + recommendation.duration) * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        budget: recommendation.estimatedBudget,
        creatorId: userId,
        tripCode: generateTripCode(),
      });
      
      const trip = await storage.createTrip(tripData);
      res.json(trip);
    } catch (error) {
      console.error("Error creating trip from recommendation:", error);
      res.status(500).json({ message: "Failed to create trip from recommendation" });
    }
  });

  // Virtual Assistant
  app.post('/api/assistant/chat', isAuthenticated, async (req: any, res) => {
    try {
      const { message, tripContext, userContext } = req.body;
      
      if (!message || typeof message !== 'string') {
        return res.status(400).json({ message: "Message is required" });
      }

      const response = await assistantService.generateResponse({
        message,
        tripContext,
        userContext
      });

      res.json(response);
    } catch (error) {
      console.error("Error generating assistant response:", error);
      res.status(500).json({ message: "Failed to generate response" });
    }
  });

  // Trip Stories
  app.get('/api/stories', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stories = await storage.getPublicStories(20);
      
      // Update userHasLiked for current user
      const storiesWithUserLikes = await Promise.all(
        stories.map(async (story) => {
          const userLike = await storage.getUserLikeForStory(story.id, userId);
          return {
            ...story,
            userHasLiked: !!userLike,
          };
        })
      );
      
      res.json(storiesWithUserLikes);
    } catch (error) {
      console.error("Error fetching stories:", error);
      res.status(500).json({ message: "Failed to fetch stories" });
    }
  });

  app.post('/api/stories', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const storyData = insertTripStorySchema.parse({
        ...req.body,
        authorId: userId,
      });
      
      const story = await storage.createTripStory(storyData);
      res.json(story);
    } catch (error) {
      console.error("Error creating story:", error);
      res.status(500).json({ message: "Failed to create story" });
    }
  });

  app.post('/api/stories/:id/like', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const storyId = parseInt(req.params.id);
      
      const liked = await storage.toggleStoryLike({
        storyId,
        userId,
      });
      
      res.json({ liked });
    } catch (error) {
      console.error("Error toggling story like:", error);
      res.status(500).json({ message: "Failed to toggle like" });
    }
  });

  app.post('/api/stories/:id/comments', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const storyId = parseInt(req.params.id);
      
      const commentData = insertStoryCommentSchema.parse({
        ...req.body,
        storyId,
        authorId: userId,
      });
      
      const comment = await storage.createStoryComment(commentData);
      res.json(comment);
    } catch (error) {
      console.error("Error creating comment:", error);
      res.status(500).json({ message: "Failed to create comment" });
    }
  });

  // AI Travel Companion routes
  app.post('/api/ai-companion/decision', isAuthenticated, async (req: any, res) => {
    try {
      const { aiTravelCompanionService } = await import('./aiTravelCompanionService');
      const userId = req.user.claims.sub;
      const { tripId, context, question, location, urgency, timeOfDay, weather, budget, groupSize } = req.body;

      if (!tripId || !context || !question) {
        return res.status(400).json({ message: "tripId, context, and question are required" });
      }

      const decision = await aiTravelCompanionService.generateDecision({
        tripId,
        userId,
        context,
        question,
        location,
        urgency,
        timeOfDay,
        weather,
        budget,
        groupSize,
      });

      res.json(decision);
    } catch (error) {
      console.error("Error generating AI decision:", error);
      res.status(500).json({ message: "Failed to generate travel decision" });
    }
  });

  app.post('/api/ai-companion/emergency', isAuthenticated, async (req: any, res) => {
    try {
      const { aiTravelCompanionService } = await import('./aiTravelCompanionService');
      const userId = req.user.claims.sub;
      const { tripId, context, question, location } = req.body;

      const decision = await aiTravelCompanionService.getEmergencyDecision({
        tripId,
        userId,
        context,
        question,
        location,
        urgency: "emergency",
      });

      res.json(decision);
    } catch (error) {
      console.error("Error generating emergency decision:", error);
      res.status(500).json({ message: "Failed to generate emergency decision" });
    }
  });

  app.patch('/api/ai-companion/decisions/:id/accept', isAuthenticated, async (req: any, res) => {
    try {
      const { aiTravelCompanionService } = await import('./aiTravelCompanionService');
      const decisionId = parseInt(req.params.id);
      
      await aiTravelCompanionService.acceptDecision(decisionId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error accepting decision:", error);
      res.status(500).json({ message: "Failed to accept decision" });
    }
  });

  app.get('/api/ai-companion/decisions/:tripId', isAuthenticated, async (req: any, res) => {
    try {
      const { aiTravelCompanionService } = await import('./aiTravelCompanionService');
      const userId = req.user.claims.sub;
      const tripId = parseInt(req.params.tripId);
      
      const decisions = await aiTravelCompanionService.getTripDecisions(tripId, userId);
      res.json(decisions);
    } catch (error) {
      console.error("Error fetching decisions:", error);
      res.status(500).json({ message: "Failed to fetch decisions" });
    }
  });

  // Smart Budgeting routes
  app.post('/api/budget/categories', isAuthenticated, async (req: any, res) => {
    try {
      const { smartBudgetingService } = await import('./smartBudgetingService');
      const { tripId, name, allocatedAmount, color } = req.body;

      if (!tripId || !name || !allocatedAmount) {
        return res.status(400).json({ message: "tripId, name, and allocatedAmount are required" });
      }

      const category = await smartBudgetingService.createBudgetCategory({
        tripId,
        name,
        allocatedAmount,
        color,
      });

      res.json(category);
    } catch (error) {
      console.error("Error creating budget category:", error);
      res.status(500).json({ message: "Failed to create budget category" });
    }
  });

  app.post('/api/budget/expenses', isAuthenticated, async (req: any, res) => {
    try {
      const { smartBudgetingService } = await import('./smartBudgetingService');
      const userId = req.user.claims.sub;
      const { tripId, categoryId, amount, description, splitWith, splitType, splitAmounts, location, expenseDate } = req.body;

      if (!tripId || !amount || !description || !expenseDate) {
        return res.status(400).json({ message: "tripId, amount, description, and expenseDate are required" });
      }

      const expense = await smartBudgetingService.addExpense({
        tripId,
        categoryId,
        paidById: userId,
        amount,
        description,
        splitWith: splitWith || [],
        splitType: splitType || "equal",
        splitAmounts,
        location,
        expenseDate: new Date(expenseDate),
      });

      res.json(expense);
    } catch (error) {
      console.error("Error adding expense:", error);
      res.status(500).json({ message: "Failed to add expense" });
    }
  });

  app.get('/api/budget/summary/:tripId', isAuthenticated, async (req: any, res) => {
    try {
      const { smartBudgetingService } = await import('./smartBudgetingService');
      const tripId = parseInt(req.params.tripId);
      
      const summary = await smartBudgetingService.getTripBudgetSummary(tripId);
      res.json(summary);
    } catch (error) {
      console.error("Error fetching budget summary:", error);
      res.status(500).json({ message: "Failed to fetch budget summary" });
    }
  });

  app.get('/api/budget/expenses/:tripId', isAuthenticated, async (req: any, res) => {
    try {
      const { smartBudgetingService } = await import('./smartBudgetingService');
      const tripId = parseInt(req.params.tripId);
      
      const expenses = await smartBudgetingService.getTripExpenses(tripId);
      res.json(expenses);
    } catch (error) {
      console.error("Error fetching expenses:", error);
      res.status(500).json({ message: "Failed to fetch expenses" });
    }
  });

  app.get('/api/budget/balances/:tripId', isAuthenticated, async (req: any, res) => {
    try {
      const { smartBudgetingService } = await import('./smartBudgetingService');
      const userId = req.user.claims.sub;
      const tripId = parseInt(req.params.tripId);
      
      const balances = await smartBudgetingService.getUserOwedAmounts(tripId, userId);
      res.json(balances);
    } catch (error) {
      console.error("Error fetching balances:", error);
      res.status(500).json({ message: "Failed to fetch balances" });
    }
  });

  // Social Map routes
  app.post('/api/map/locations', isAuthenticated, async (req: any, res) => {
    try {
      const { socialMapService } = await import('./socialMapService');
      const userId = req.user.claims.sub;
      const { tripId, name, latitude, longitude, address, category, rating, notes, isPublic } = req.body;

      if (!tripId || !name || !latitude || !longitude) {
        return res.status(400).json({ message: "tripId, name, latitude, and longitude are required" });
      }

      const location = await socialMapService.addTripLocation({
        tripId,
        userId,
        name,
        latitude: latitude.toString(),
        longitude: longitude.toString(),
        address,
        category,
        rating: rating?.toString(),
        notes,
        isPublic: isPublic !== false,
        visitedAt: new Date(),
      });

      res.json(location);
    } catch (error) {
      console.error("Error adding location:", error);
      res.status(500).json({ message: "Failed to add location" });
    }
  });

  app.get('/api/map/locations/:tripId', isAuthenticated, async (req: any, res) => {
    try {
      const { socialMapService } = await import('./socialMapService');
      const tripId = parseInt(req.params.tripId);
      const { category, publicOnly } = req.query;
      
      const locations = await socialMapService.getTripLocations(
        tripId, 
        category as string, 
        publicOnly === 'true'
      );
      res.json(locations);
    } catch (error) {
      console.error("Error fetching locations:", error);
      res.status(500).json({ message: "Failed to fetch locations" });
    }
  });

  app.post('/api/map/footprint', isAuthenticated, async (req: any, res) => {
    try {
      const { socialMapService } = await import('./socialMapService');
      const userId = req.user.claims.sub;
      const { tripId, latitude, longitude, accuracy, activity } = req.body;

      if (!tripId || !latitude || !longitude) {
        return res.status(400).json({ message: "tripId, latitude, and longitude are required" });
      }

      const footprint = await socialMapService.recordFootprint({
        tripId,
        userId,
        latitude: latitude.toString(),
        longitude: longitude.toString(),
        accuracy: accuracy?.toString(),
        activity,
        timestamp: new Date(),
      });

      res.json(footprint);
    } catch (error) {
      console.error("Error recording footprint:", error);
      res.status(500).json({ message: "Failed to record footprint" });
    }
  });

  app.get('/api/map/footprints/:tripId', isAuthenticated, async (req: any, res) => {
    try {
      const { socialMapService } = await import('./socialMapService');
      const tripId = parseInt(req.params.tripId);
      
      const footprints = await socialMapService.getTripFootprints(tripId);
      res.json(footprints);
    } catch (error) {
      console.error("Error fetching footprints:", error);
      res.status(500).json({ message: "Failed to fetch footprints" });
    }
  });

  // Emotional Tracker routes
  app.post('/api/mood/checkin', isAuthenticated, async (req: any, res) => {
    try {
      const { emotionalTrackerService } = await import('./emotionalTrackerService');
      const userId = req.user.claims.sub;
      const { tripId, activityId, mood, energy, satisfaction, notes, location, weather } = req.body;

      if (!tripId || !mood || energy === undefined || satisfaction === undefined) {
        return res.status(400).json({ message: "tripId, mood, energy, and satisfaction are required" });
      }

      const checkin = await emotionalTrackerService.recordMoodCheckin({
        tripId,
        userId,
        activityId,
        mood,
        energy,
        satisfaction,
        notes,
        location,
        weather,
      });

      res.json(checkin);
    } catch (error) {
      console.error("Error recording mood checkin:", error);
      res.status(500).json({ message: "Failed to record mood checkin" });
    }
  });

  app.get('/api/mood/checkins/:tripId', isAuthenticated, async (req: any, res) => {
    try {
      const { emotionalTrackerService } = await import('./emotionalTrackerService');
      const userId = req.user.claims.sub;
      const tripId = parseInt(req.params.tripId);
      
      const checkins = await emotionalTrackerService.getMoodCheckins(tripId, userId);
      res.json(checkins);
    } catch (error) {
      console.error("Error fetching mood checkins:", error);
      res.status(500).json({ message: "Failed to fetch mood checkins" });
    }
  });

  app.get('/api/mood/report/:tripId', isAuthenticated, async (req: any, res) => {
    try {
      const { emotionalTrackerService } = await import('./emotionalTrackerService');
      const userId = req.user.claims.sub;
      const tripId = parseInt(req.params.tripId);
      
      const report = await emotionalTrackerService.getWellbeingReport(tripId, userId);
      res.json(report);
    } catch (error) {
      console.error("Error generating wellbeing report:", error);
      res.status(500).json({ message: "Failed to generate wellbeing report" });
    }
  });

  // Emergency/Panic Mode routes
  app.post('/api/emergency/panic', isAuthenticated, async (req: any, res) => {
    try {
      const { emergencyService } = await import('./emergencyService');
      const userId = req.user.claims.sub;
      const { tripId, alertType, severity, location, latitude, longitude, description } = req.body;

      if (!tripId || !alertType || !severity) {
        return res.status(400).json({ message: "tripId, alertType, and severity are required" });
      }

      const response = await emergencyService.createPanicAlert({
        tripId,
        userId,
        alertType,
        severity,
        location,
        latitude: latitude?.toString(),
        longitude: longitude?.toString(),
        description,
      });

      res.json(response);
    } catch (error) {
      console.error("Error creating panic alert:", error);
      res.status(500).json({ message: "Failed to create panic alert" });
    }
  });

  app.post('/api/emergency/contacts', isAuthenticated, async (req: any, res) => {
    try {
      const { emergencyService } = await import('./emergencyService');
      const userId = req.user.claims.sub;
      const { tripId, name, phone, relationship, isLocal, isPrimary } = req.body;

      if (!tripId || !name || !phone) {
        return res.status(400).json({ message: "tripId, name, and phone are required" });
      }

      const contact = await emergencyService.addEmergencyContact({
        tripId,
        userId,
        name,
        phone,
        relationship,
        isLocal: isLocal || false,
        isPrimary: isPrimary || false,
      });

      res.json(contact);
    } catch (error) {
      console.error("Error adding emergency contact:", error);
      res.status(500).json({ message: "Failed to add emergency contact" });
    }
  });

  app.get('/api/emergency/contacts/:tripId', isAuthenticated, async (req: any, res) => {
    try {
      const { emergencyService } = await import('./emergencyService');
      const userId = req.user.claims.sub;
      const tripId = parseInt(req.params.tripId);
      
      const contacts = await emergencyService.getTripEmergencyContacts(tripId, userId);
      res.json(contacts);
    } catch (error) {
      console.error("Error fetching emergency contacts:", error);
      res.status(500).json({ message: "Failed to fetch emergency contacts" });
    }
  });

  app.get('/api/emergency/services/:tripId', isAuthenticated, async (req: any, res) => {
    try {
      const { emergencyService } = await import('./emergencyService');
      const tripId = parseInt(req.params.tripId);
      const { category } = req.query;
      
      const services = await emergencyService.findLocalServices(tripId, category as string);
      res.json(services);
    } catch (error) {
      console.error("Error fetching emergency services:", error);
      res.status(500).json({ message: "Failed to fetch emergency services" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
