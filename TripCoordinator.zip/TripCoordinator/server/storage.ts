import {
  users,
  trips,
  activities,
  tripParticipants,
  activityVotes,
  tripRecommendations,
  tripStories,
  storyLikes,
  storyComments,
  type User,
  type UpsertUser,
  type Trip,
  type InsertTrip,
  type Activity,
  type InsertActivity,
  type TripParticipant,
  type InsertTripParticipant,
  type ActivityVote,
  type InsertActivityVote,
  type TripRecommendation,
  type InsertTripRecommendation,
  type UpdateUserPreferences,
  type TripStory,
  type InsertTripStory,
  type StoryLike,
  type InsertStoryLike,
  type StoryComment,
  type InsertStoryComment,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, asc } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations
  // (IMPORTANT) these user operations are mandatory for Replit Auth.
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Trip operations
  createTrip(trip: InsertTrip): Promise<Trip>;
  getTripById(id: number): Promise<Trip | undefined>;
  getTripByCode(code: string): Promise<Trip | undefined>;
  getUserTrips(userId: string): Promise<Trip[]>;
  deleteTrip(id: number): Promise<void>;
  
  // Trip participant operations
  addTripParticipant(participant: InsertTripParticipant): Promise<TripParticipant>;
  getTripParticipants(tripId: number): Promise<(TripParticipant & { user: User })[]>;
  removeTripParticipant(tripId: number, userId: string): Promise<void>;
  isUserTripParticipant(tripId: number, userId: string): Promise<boolean>;
  
  // Activity operations
  createActivity(activity: InsertActivity): Promise<Activity>;
  getTripActivities(tripId: number): Promise<(Activity & { creator: User; votes: ActivityVote[]; voteCount: number })[]>;
  updateActivity(id: number, activity: Partial<InsertActivity>): Promise<Activity>;
  deleteActivity(id: number): Promise<void>;
  lockActivity(id: number): Promise<void>;
  
  // Vote operations
  toggleActivityVote(vote: InsertActivityVote): Promise<boolean>; // returns true if vote added, false if removed
  getActivityVotes(activityId: number): Promise<ActivityVote[]>;
  getUserVoteForActivity(activityId: number, userId: string): Promise<ActivityVote | undefined>;
  
  // Recommendation operations
  createTripRecommendation(recommendation: InsertTripRecommendation): Promise<TripRecommendation>;
  getUserRecommendations(userId: string, limit?: number): Promise<TripRecommendation[]>;
  deleteUserRecommendation(userId: string, recommendationId: number): Promise<void>;
  updateUserPreferences(userId: string, preferences: UpdateUserPreferences): Promise<void>;
  
  // Story operations
  createTripStory(story: InsertTripStory): Promise<TripStory>;
  getPublicStories(limit?: number): Promise<(TripStory & { author: User; trip: Trip; likes: StoryLike[]; comments: (StoryComment & { author: User })[]; likeCount: number; commentCount: number; userHasLiked: boolean })[]>;
  getUserStories(userId: string): Promise<TripStory[]>;
  getStoryById(id: number): Promise<TripStory | undefined>;
  updateStory(id: number, story: Partial<InsertTripStory>): Promise<TripStory>;
  deleteStory(id: number): Promise<void>;
  
  // Story like operations
  toggleStoryLike(like: InsertStoryLike): Promise<boolean>; // returns true if liked, false if unliked
  getStoryLikes(storyId: number): Promise<StoryLike[]>;
  getUserLikeForStory(storyId: number, userId: string): Promise<StoryLike | undefined>;
  
  // Story comment operations
  createStoryComment(comment: InsertStoryComment): Promise<StoryComment>;
  getStoryComments(storyId: number): Promise<(StoryComment & { author: User })[]>;
  deleteStoryComment(id: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  // (IMPORTANT) these user operations are mandatory for Replit Auth.
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Trip operations
  async createTrip(trip: InsertTrip): Promise<Trip> {
    const [newTrip] = await db.insert(trips).values(trip).returning();
    
    // Add creator as participant
    await this.addTripParticipant({
      tripId: newTrip.id,
      userId: trip.creatorId,
    });
    
    return newTrip;
  }

  async getTripById(id: number): Promise<Trip | undefined> {
    const [trip] = await db.select().from(trips).where(eq(trips.id, id));
    return trip;
  }

  async getTripByCode(code: string): Promise<Trip | undefined> {
    const [trip] = await db.select().from(trips).where(eq(trips.tripCode, code));
    return trip;
  }

  async getUserTrips(userId: string): Promise<Trip[]> {
    const userTrips = await db
      .select({
        id: trips.id,
        name: trips.name,
        startDate: trips.startDate,
        endDate: trips.endDate,
        budget: trips.budget,
        tripCode: trips.tripCode,
        creatorId: trips.creatorId,
        createdAt: trips.createdAt,
        updatedAt: trips.updatedAt,
      })
      .from(trips)
      .innerJoin(tripParticipants, eq(trips.id, tripParticipants.tripId))
      .where(eq(tripParticipants.userId, userId))
      .orderBy(desc(trips.createdAt));
    
    return userTrips;
  }

  async deleteTrip(id: number): Promise<void> {
    await db.delete(trips).where(eq(trips.id, id));
  }

  // Trip participant operations
  async addTripParticipant(participant: InsertTripParticipant): Promise<TripParticipant> {
    const [newParticipant] = await db
      .insert(tripParticipants)
      .values(participant)
      .returning();
    return newParticipant;
  }

  async getTripParticipants(tripId: number): Promise<(TripParticipant & { user: User })[]> {
    const participants = await db
      .select({
        id: tripParticipants.id,
        tripId: tripParticipants.tripId,
        userId: tripParticipants.userId,
        joinedAt: tripParticipants.joinedAt,
        user: users,
      })
      .from(tripParticipants)
      .innerJoin(users, eq(tripParticipants.userId, users.id))
      .where(eq(tripParticipants.tripId, tripId))
      .orderBy(asc(tripParticipants.joinedAt));
    
    return participants;
  }

  async removeTripParticipant(tripId: number, userId: string): Promise<void> {
    await db
      .delete(tripParticipants)
      .where(and(eq(tripParticipants.tripId, tripId), eq(tripParticipants.userId, userId)));
  }

  async isUserTripParticipant(tripId: number, userId: string): Promise<boolean> {
    const [participant] = await db
      .select()
      .from(tripParticipants)
      .where(and(eq(tripParticipants.tripId, tripId), eq(tripParticipants.userId, userId)));
    return !!participant;
  }

  // Activity operations
  async createActivity(activity: InsertActivity): Promise<Activity> {
    const [newActivity] = await db.insert(activities).values(activity).returning();
    return newActivity;
  }

  async getTripActivities(tripId: number): Promise<(Activity & { creator: User; votes: ActivityVote[]; voteCount: number })[]> {
    const activitiesWithCreator = await db
      .select({
        id: activities.id,
        tripId: activities.tripId,
        title: activities.title,
        description: activities.description,
        date: activities.date,
        time: activities.time,
        category: activities.category,
        estimatedCost: activities.estimatedCost,
        notes: activities.notes,
        creatorId: activities.creatorId,
        isLockedIn: activities.isLockedIn,
        createdAt: activities.createdAt,
        updatedAt: activities.updatedAt,
        creator: users,
      })
      .from(activities)
      .innerJoin(users, eq(activities.creatorId, users.id))
      .where(eq(activities.tripId, tripId))
      .orderBy(asc(activities.date), asc(activities.time));

    // Get votes for each activity
    const activitiesWithVotes = await Promise.all(
      activitiesWithCreator.map(async (activity) => {
        const votes = await this.getActivityVotes(activity.id);
        return {
          ...activity,
          votes,
          voteCount: votes.length,
        };
      })
    );

    return activitiesWithVotes;
  }

  async updateActivity(id: number, activity: Partial<InsertActivity>): Promise<Activity> {
    const [updatedActivity] = await db
      .update(activities)
      .set({ ...activity, updatedAt: new Date() })
      .where(eq(activities.id, id))
      .returning();
    return updatedActivity;
  }

  async deleteActivity(id: number): Promise<void> {
    await db.delete(activities).where(eq(activities.id, id));
  }

  async lockActivity(id: number): Promise<void> {
    await db
      .update(activities)
      .set({ isLockedIn: true, updatedAt: new Date() })
      .where(eq(activities.id, id));
  }

  // Vote operations
  async toggleActivityVote(vote: InsertActivityVote): Promise<boolean> {
    // Check if vote exists
    const existingVote = await this.getUserVoteForActivity(vote.activityId, vote.userId);
    
    if (existingVote) {
      // Remove vote
      await db
        .delete(activityVotes)
        .where(and(eq(activityVotes.activityId, vote.activityId), eq(activityVotes.userId, vote.userId)));
      return false;
    } else {
      // Add vote
      await db.insert(activityVotes).values(vote);
      
      // Check if activity should be locked in (e.g., 4+ votes)
      const votes = await this.getActivityVotes(vote.activityId);
      if (votes.length >= 4) {
        await this.lockActivity(vote.activityId);
      }
      
      return true;
    }
  }

  async getActivityVotes(activityId: number): Promise<ActivityVote[]> {
    const votes = await db
      .select()
      .from(activityVotes)
      .where(eq(activityVotes.activityId, activityId));
    return votes;
  }

  async getUserVoteForActivity(activityId: number, userId: string): Promise<ActivityVote | undefined> {
    const [vote] = await db
      .select()
      .from(activityVotes)
      .where(and(eq(activityVotes.activityId, activityId), eq(activityVotes.userId, userId)));
    return vote;
  }

  // Recommendation operations
  async createTripRecommendation(recommendation: InsertTripRecommendation): Promise<TripRecommendation> {
    const [newRecommendation] = await db
      .insert(tripRecommendations)
      .values(recommendation)
      .returning();
    return newRecommendation;
  }

  async getUserRecommendations(userId: string, limit: number = 10): Promise<TripRecommendation[]> {
    const recommendations = await db
      .select()
      .from(tripRecommendations)
      .where(eq(tripRecommendations.userId, userId))
      .orderBy(desc(tripRecommendations.createdAt))
      .limit(limit);
    return recommendations;
  }

  async deleteUserRecommendation(userId: string, recommendationId: number): Promise<void> {
    await db
      .delete(tripRecommendations)
      .where(and(eq(tripRecommendations.id, recommendationId), eq(tripRecommendations.userId, userId)));
  }

  async updateUserPreferences(userId: string, preferences: UpdateUserPreferences): Promise<void> {
    await db
      .update(users)
      .set({
        ...preferences,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));
  }

  // Story operations
  async createTripStory(story: InsertTripStory): Promise<TripStory> {
    const [newStory] = await db
      .insert(tripStories)
      .values(story)
      .returning();
    return newStory;
  }

  async getPublicStories(limit: number = 20): Promise<any[]> {
    const storiesWithDetails = await db
      .select({
        id: tripStories.id,
        tripId: tripStories.tripId,
        authorId: tripStories.authorId,
        title: tripStories.title,
        content: tripStories.content,
        images: tripStories.images,
        location: tripStories.location,
        isPublic: tripStories.isPublic,
        createdAt: tripStories.createdAt,
        updatedAt: tripStories.updatedAt,
        author: users,
        trip: trips,
      })
      .from(tripStories)
      .leftJoin(users, eq(tripStories.authorId, users.id))
      .leftJoin(trips, eq(tripStories.tripId, trips.id))
      .where(eq(tripStories.isPublic, true))
      .orderBy(desc(tripStories.createdAt))
      .limit(limit);

    const storiesWithCounts = await Promise.all(
      storiesWithDetails.map(async (story) => {
        const likes = await this.getStoryLikes(story.id);
        const comments = await this.getStoryComments(story.id);
        
        return {
          ...story,
          likes,
          comments,
          likeCount: likes.length,
          commentCount: comments.length,
          userHasLiked: false,
        };
      })
    );

    return storiesWithCounts;
  }

  async getUserStories(userId: string): Promise<TripStory[]> {
    const stories = await db
      .select()
      .from(tripStories)
      .where(eq(tripStories.authorId, userId))
      .orderBy(desc(tripStories.createdAt));
    return stories;
  }

  async getStoryById(id: number): Promise<TripStory | undefined> {
    const [story] = await db
      .select()
      .from(tripStories)
      .where(eq(tripStories.id, id));
    return story;
  }

  async updateStory(id: number, story: Partial<InsertTripStory>): Promise<TripStory> {
    const [updatedStory] = await db
      .update(tripStories)
      .set({ ...story, updatedAt: new Date() })
      .where(eq(tripStories.id, id))
      .returning();
    return updatedStory;
  }

  async deleteStory(id: number): Promise<void> {
    await db.delete(tripStories).where(eq(tripStories.id, id));
  }

  async toggleStoryLike(like: InsertStoryLike): Promise<boolean> {
    const existingLike = await this.getUserLikeForStory(like.storyId, like.userId);
    
    if (existingLike) {
      await db
        .delete(storyLikes)
        .where(and(eq(storyLikes.storyId, like.storyId), eq(storyLikes.userId, like.userId)));
      return false;
    } else {
      await db.insert(storyLikes).values(like);
      return true;
    }
  }

  async getStoryLikes(storyId: number): Promise<StoryLike[]> {
    const likes = await db
      .select()
      .from(storyLikes)
      .where(eq(storyLikes.storyId, storyId));
    return likes;
  }

  async getUserLikeForStory(storyId: number, userId: string): Promise<StoryLike | undefined> {
    const [like] = await db
      .select()
      .from(storyLikes)
      .where(and(eq(storyLikes.storyId, storyId), eq(storyLikes.userId, userId)));
    return like;
  }

  async createStoryComment(comment: InsertStoryComment): Promise<StoryComment> {
    const [newComment] = await db
      .insert(storyComments)
      .values(comment)
      .returning();
    return newComment;
  }

  async getStoryComments(storyId: number): Promise<(StoryComment & { author: User })[]> {
    const comments = await db
      .select({
        id: storyComments.id,
        storyId: storyComments.storyId,
        authorId: storyComments.authorId,
        content: storyComments.content,
        createdAt: storyComments.createdAt,
        updatedAt: storyComments.updatedAt,
        author: users,
      })
      .from(storyComments)
      .leftJoin(users, eq(storyComments.authorId, users.id))
      .where(eq(storyComments.storyId, storyId))
      .orderBy(asc(storyComments.createdAt));
    return comments as any;
  }

  async deleteStoryComment(id: number): Promise<void> {
    await db.delete(storyComments).where(eq(storyComments.id, id));
  }
}

export const storage = new DatabaseStorage();
