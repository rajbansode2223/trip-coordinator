import { db } from "./db";
import { 
  moodCheckins, 
  emotionalInsights,
  activities,
  type InsertMoodCheckin,
  type InsertEmotionalInsight,
  type MoodCheckin,
  type EmotionalInsight 
} from "@shared/schema";
import { eq, and, desc, sql, gte, lte, avg, count } from "drizzle-orm";
import OpenAI from "openai";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

interface MoodTrend {
  date: string;
  averageMood: number;
  averageEnergy: number;
  averageSatisfaction: number;
  checkinCount: number;
}

interface MoodPattern {
  pattern: string;
  frequency: number;
  correlation: string;
  recommendation: string;
}

interface WellbeingReport {
  overallScore: number;
  trends: MoodTrend[];
  patterns: MoodPattern[];
  insights: EmotionalInsight[];
  recommendations: string[];
  alerts: string[];
}

export class EmotionalTrackerService {
  async recordMoodCheckin(checkinData: InsertMoodCheckin): Promise<MoodCheckin> {
    const [checkin] = await db
      .insert(moodCheckins)
      .values(checkinData)
      .returning();

    // Generate insights after recording mood
    await this.generateEmotionalInsights(checkinData.tripId, checkinData.userId);

    return checkin;
  }

  async getMoodCheckins(
    tripId: number,
    userId?: string,
    startDate?: Date,
    endDate?: Date
  ): Promise<MoodCheckin[]> {
    let query = db.select().from(moodCheckins).where(eq(moodCheckins.tripId, tripId));

    if (userId) {
      query = query.where(eq(moodCheckins.userId, userId));
    }

    if (startDate) {
      query = query.where(gte(moodCheckins.createdAt, startDate));
    }

    if (endDate) {
      query = query.where(lte(moodCheckins.createdAt, endDate));
    }

    return await query.orderBy(desc(moodCheckins.createdAt));
  }

  async generateEmotionalInsights(tripId: number, userId: string): Promise<void> {
    const recentCheckins = await this.getMoodCheckins(tripId, userId);
    
    if (recentCheckins.length < 3) {
      return; // Need minimum data for insights
    }

    try {
      const systemPrompt = `You are an AI emotional wellness analyst for travelers. Analyze mood patterns and provide insights.

      Guidelines:
      - Identify patterns in mood, energy, and satisfaction
      - Provide actionable recommendations
      - Flag concerning trends
      - Celebrate positive patterns
      - Consider travel context (activities, locations, time)

      Format response as JSON:
      {
        "insights": [
          {
            "insight": "Description of pattern or observation",
            "category": "pattern|recommendation|warning|celebration",
            "confidence": 0.85,
            "relatedMoods": ["mood1", "mood2"],
            "suggestions": ["suggestion1", "suggestion2"]
          }
        ]
      }`;

      const userMessage = this.buildMoodAnalysisPrompt(recentCheckins);

      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userMessage },
        ],
        response_format: { type: "json_object" },
        temperature: 0.7,
        max_tokens: 800,
      });

      const analysisData = JSON.parse(response.choices[0].message.content || "{}");

      // Store insights in database
      for (const insight of analysisData.insights || []) {
        const insertData: InsertEmotionalInsight = {
          tripId,
          userId,
          insight: insight.insight,
          category: insight.category,
          confidence: insight.confidence?.toString() || "0.5",
          relatedMoods: insight.relatedMoods || [],
          suggestions: insight.suggestions || [],
        };

        await db.insert(emotionalInsights).values(insertData);
      }
    } catch (error) {
      console.error("Error generating emotional insights:", error);
    }
  }

  async getWellbeingReport(tripId: number, userId: string): Promise<WellbeingReport> {
    const checkins = await this.getMoodCheckins(tripId, userId);
    const insights = await this.getEmotionalInsights(tripId, userId);

    // Calculate trends by day
    const trends = this.calculateMoodTrends(checkins);
    
    // Identify patterns
    const patterns = this.identifyMoodPatterns(checkins);

    // Calculate overall wellbeing score
    const overallScore = this.calculateOverallScore(checkins);

    // Generate recommendations
    const recommendations = this.generateRecommendations(checkins, insights);

    // Check for alerts
    const alerts = this.checkForAlerts(checkins, insights);

    return {
      overallScore,
      trends,
      patterns,
      insights,
      recommendations,
      alerts,
    };
  }

  async getEmotionalInsights(tripId: number, userId: string, limit: number = 10): Promise<EmotionalInsight[]> {
    return await db
      .select()
      .from(emotionalInsights)
      .where(
        and(
          eq(emotionalInsights.tripId, tripId),
          eq(emotionalInsights.userId, userId)
        )
      )
      .orderBy(desc(emotionalInsights.createdAt))
      .limit(limit);
  }

  async getMoodStats(tripId: number, userId?: string): Promise<{
    totalCheckins: number;
    averageMood: number;
    averageEnergy: number;
    averageSatisfaction: number;
    moodDistribution: Record<string, number>;
  }> {
    let query = db.select().from(moodCheckins).where(eq(moodCheckins.tripId, tripId));

    if (userId) {
      query = query.where(eq(moodCheckins.userId, userId));
    }

    const checkins = await query;

    const totalCheckins = checkins.length;
    const averageMood = this.moodToNumber(checkins.map(c => c.mood));
    const averageEnergy = checkins.reduce((sum, c) => sum + c.energy, 0) / totalCheckins || 0;
    const averageSatisfaction = checkins.reduce((sum, c) => sum + c.satisfaction, 0) / totalCheckins || 0;

    // Calculate mood distribution
    const moodDistribution: Record<string, number> = {};
    checkins.forEach(checkin => {
      moodDistribution[checkin.mood] = (moodDistribution[checkin.mood] || 0) + 1;
    });

    return {
      totalCheckins,
      averageMood,
      averageEnergy,
      averageSatisfaction,
      moodDistribution,
    };
  }

  private buildMoodAnalysisPrompt(checkins: MoodCheckin[]): string {
    const moodData = checkins.map(checkin => ({
      date: checkin.createdAt?.toISOString(),
      mood: checkin.mood,
      energy: checkin.energy,
      satisfaction: checkin.satisfaction,
      location: checkin.location,
      notes: checkin.notes,
      weather: checkin.weather,
    }));

    return `Analyze these mood check-ins from a traveler:

${JSON.stringify(moodData, null, 2)}

Identify patterns, trends, and provide insights for improving their travel experience.`;
  }

  private calculateMoodTrends(checkins: MoodCheckin[]): MoodTrend[] {
    const dailyData: Record<string, MoodCheckin[]> = {};

    checkins.forEach(checkin => {
      const date = checkin.createdAt?.toISOString().split('T')[0] || '';
      if (!dailyData[date]) {
        dailyData[date] = [];
      }
      dailyData[date].push(checkin);
    });

    return Object.entries(dailyData).map(([date, dayCheckins]) => ({
      date,
      averageMood: this.moodToNumber(dayCheckins.map(c => c.mood)),
      averageEnergy: dayCheckins.reduce((sum, c) => sum + c.energy, 0) / dayCheckins.length,
      averageSatisfaction: dayCheckins.reduce((sum, c) => sum + c.satisfaction, 0) / dayCheckins.length,
      checkinCount: dayCheckins.length,
    }));
  }

  private identifyMoodPatterns(checkins: MoodCheckin[]): MoodPattern[] {
    const patterns: MoodPattern[] = [];

    // Time-based patterns
    const timePatterns = this.analyzeTimePatterns(checkins);
    patterns.push(...timePatterns);

    // Location-based patterns
    const locationPatterns = this.analyzeLocationPatterns(checkins);
    patterns.push(...locationPatterns);

    // Activity-based patterns
    const activityPatterns = this.analyzeActivityPatterns(checkins);
    patterns.push(...activityPatterns);

    return patterns;
  }

  private analyzeTimePatterns(checkins: MoodCheckin[]): MoodPattern[] {
    // Analyze patterns by time of day, day of week, etc.
    return [];
  }

  private analyzeLocationPatterns(checkins: MoodCheckin[]): MoodPattern[] {
    // Analyze mood patterns by location
    return [];
  }

  private analyzeActivityPatterns(checkins: MoodCheckin[]): MoodPattern[] {
    // Analyze mood patterns by activity type
    return [];
  }

  private calculateOverallScore(checkins: MoodCheckin[]): number {
    if (checkins.length === 0) return 0;

    const moodScore = this.moodToNumber(checkins.map(c => c.mood));
    const energyScore = checkins.reduce((sum, c) => sum + c.energy, 0) / checkins.length;
    const satisfactionScore = checkins.reduce((sum, c) => sum + c.satisfaction, 0) / checkins.length;

    // Weighted average (mood 40%, energy 30%, satisfaction 30%)
    return Math.round((moodScore * 0.4 + energyScore * 0.3 + satisfactionScore * 0.3) * 10) / 10;
  }

  private generateRecommendations(checkins: MoodCheckin[], insights: EmotionalInsight[]): string[] {
    const recommendations: string[] = [];

    // Get recent mood trends
    const recentCheckins = checkins.slice(0, 5);
    const recentMoodScore = this.moodToNumber(recentCheckins.map(c => c.mood));

    if (recentMoodScore < 3) {
      recommendations.push("Consider taking a break or doing a relaxing activity");
      recommendations.push("Try connecting with your travel companions");
    }

    // Energy-based recommendations
    const recentEnergy = recentCheckins.reduce((sum, c) => sum + c.energy, 0) / recentCheckins.length;
    if (recentEnergy < 3) {
      recommendations.push("Get adequate rest and stay hydrated");
      recommendations.push("Consider lighter activities for today");
    }

    // Add AI-generated suggestions from insights
    insights.forEach(insight => {
      if (insight.suggestions) {
        recommendations.push(...insight.suggestions);
      }
    });

    return [...new Set(recommendations)]; // Remove duplicates
  }

  private checkForAlerts(checkins: MoodCheckin[], insights: EmotionalInsight[]): string[] {
    const alerts: string[] = [];

    // Check for concerning patterns
    const recentCheckins = checkins.slice(0, 3);
    const consecutiveLowMood = recentCheckins.every(c => this.moodToNumber([c.mood]) < 2);

    if (consecutiveLowMood) {
      alerts.push("Consecutive low mood detected - consider reaching out for support");
    }

    // Check for warning insights
    const warningInsights = insights.filter(i => i.category === "warning");
    warningInsights.forEach(insight => {
      alerts.push(insight.insight);
    });

    return alerts;
  }

  private moodToNumber(moods: string[]): number {
    const moodValues: Record<string, number> = {
      disappointed: 1,
      stressed: 2,
      tired: 2.5,
      neutral: 3,
      content: 4,
      happy: 4.5,
      excited: 5,
    };

    const total = moods.reduce((sum, mood) => sum + (moodValues[mood] || 3), 0);
    return total / moods.length;
  }
}

export const emotionalTrackerService = new EmotionalTrackerService();