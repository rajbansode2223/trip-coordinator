import { db } from "./db";
import { 
  budgetCategories, 
  expenses, 
  tripParticipants,
  type InsertBudgetCategory, 
  type InsertExpense,
  type BudgetCategory,
  type Expense 
} from "@shared/schema";
import { eq, and, sum, sql } from "drizzle-orm";

interface SplitCalculation {
  userId: string;
  amount: number;
  percentage?: number;
}

interface ExpenseWithSplits extends Expense {
  splits: SplitCalculation[];
  settledBy: string[];
}

interface BudgetSummary {
  totalBudget: number;
  totalSpent: number;
  remaining: number;
  categories: (BudgetCategory & {
    spentAmount: number;
    remainingAmount: number;
    percentageUsed: number;
  })[];
  dailyAverage: number;
  projectedTotal: number;
  warningLevel: "safe" | "caution" | "danger" | "exceeded";
}

export class SmartBudgetingService {
  async createBudgetCategory(category: InsertBudgetCategory): Promise<BudgetCategory> {
    const [newCategory] = await db
      .insert(budgetCategories)
      .values(category)
      .returning();
    
    return newCategory;
  }

  async updateBudgetCategory(id: number, updates: Partial<InsertBudgetCategory>): Promise<BudgetCategory> {
    const [updatedCategory] = await db
      .update(budgetCategories)
      .set(updates)
      .where(eq(budgetCategories.id, id))
      .returning();
    
    return updatedCategory;
  }

  async deleteBudgetCategory(id: number): Promise<void> {
    await db.delete(budgetCategories).where(eq(budgetCategories.id, id));
  }

  async addExpense(expenseData: InsertExpense): Promise<ExpenseWithSplits> {
    const [expense] = await db
      .insert(expenses)
      .values(expenseData)
      .returning();

    // Calculate splits based on split type
    const splits = await this.calculateSplits(expense);
    
    // Update category spent amount
    if (expense.categoryId) {
      await this.updateCategorySpentAmount(expense.categoryId);
    }

    return {
      ...expense,
      splits,
      settledBy: [],
    };
  }

  async updateExpense(id: number, updates: Partial<InsertExpense>): Promise<Expense> {
    const originalExpense = await db
      .select()
      .from(expenses)
      .where(eq(expenses.id, id))
      .then(rows => rows[0]);

    const [updatedExpense] = await db
      .update(expenses)
      .set(updates)
      .where(eq(expenses.id, id))
      .returning();

    // Update category spent amounts if category changed
    if (originalExpense?.categoryId) {
      await this.updateCategorySpentAmount(originalExpense.categoryId);
    }
    if (updatedExpense.categoryId && updatedExpense.categoryId !== originalExpense?.categoryId) {
      await this.updateCategorySpentAmount(updatedExpense.categoryId);
    }

    return updatedExpense;
  }

  async deleteExpense(id: number): Promise<void> {
    const expense = await db
      .select()
      .from(expenses)
      .where(eq(expenses.id, id))
      .then(rows => rows[0]);

    await db.delete(expenses).where(eq(expenses.id, id));

    // Update category spent amount
    if (expense?.categoryId) {
      await this.updateCategorySpentAmount(expense.categoryId);
    }
  }

  async settleExpense(expenseId: number, userId: string): Promise<void> {
    const expense = await db
      .select()
      .from(expenses)
      .where(eq(expenses.id, expenseId))
      .then(rows => rows[0]);

    if (!expense) throw new Error("Expense not found");

    const currentSettled = expense.contactsNotified || [];
    if (!currentSettled.includes(userId)) {
      await db
        .update(expenses)
        .set({
          contactsNotified: [...currentSettled, userId],
          isSettled: this.checkIfFullySettled(expense, [...currentSettled, userId]),
        })
        .where(eq(expenses.id, expenseId));
    }
  }

  async getTripBudgetSummary(tripId: number): Promise<BudgetSummary> {
    // Get all budget categories for the trip
    const categories = await db
      .select()
      .from(budgetCategories)
      .where(eq(budgetCategories.tripId, tripId));

    // Calculate spent amounts for each category
    const categoriesWithSpent = await Promise.all(
      categories.map(async (category) => {
        const spentResult = await db
          .select({ spent: sum(expenses.amount) })
          .from(expenses)
          .where(
            and(
              eq(expenses.tripId, tripId),
              eq(expenses.categoryId, category.id)
            )
          );

        const spentAmount = parseFloat(spentResult[0]?.spent || "0");
        const allocatedAmount = parseFloat(category.allocatedAmount);
        const remainingAmount = allocatedAmount - spentAmount;
        const percentageUsed = allocatedAmount > 0 ? (spentAmount / allocatedAmount) * 100 : 0;

        return {
          ...category,
          spentAmount,
          remainingAmount,
          percentageUsed,
        };
      })
    );

    // Calculate totals
    const totalBudget = categoriesWithSpent.reduce((sum, cat) => 
      sum + parseFloat(cat.allocatedAmount), 0);
    const totalSpent = categoriesWithSpent.reduce((sum, cat) => 
      sum + cat.spentAmount, 0);
    const remaining = totalBudget - totalSpent;

    // Calculate daily average and projections
    const tripDuration = await this.getTripDuration(tripId);
    const dailyAverage = tripDuration > 0 ? totalSpent / tripDuration : 0;
    const projectedTotal = dailyAverage * this.getTotalTripDays(tripId);

    // Determine warning level
    const percentageUsed = totalBudget > 0 ? (totalSpent / totalBudget) * 100 : 0;
    let warningLevel: BudgetSummary["warningLevel"] = "safe";
    if (percentageUsed > 100) warningLevel = "exceeded";
    else if (percentageUsed > 85) warningLevel = "danger";
    else if (percentageUsed > 70) warningLevel = "caution";

    return {
      totalBudget,
      totalSpent,
      remaining,
      categories: categoriesWithSpent,
      dailyAverage,
      projectedTotal,
      warningLevel,
    };
  }

  async getTripExpenses(tripId: number, limit: number = 50): Promise<ExpenseWithSplits[]> {
    const expenseList = await db
      .select()
      .from(expenses)
      .where(eq(expenses.tripId, tripId))
      .orderBy(sql`${expenses.expenseDate} DESC`)
      .limit(limit);

    return Promise.all(
      expenseList.map(async (expense) => {
        const splits = await this.calculateSplits(expense);
        return {
          ...expense,
          splits,
          settledBy: expense.contactsNotified || [],
        };
      })
    );
  }

  async getUserOwedAmounts(tripId: number, userId: string): Promise<{
    owes: { toUserId: string; amount: number; description: string }[];
    owed: { fromUserId: string; amount: number; description: string }[];
    netBalance: number;
  }> {
    const tripExpenses = await this.getTripExpenses(tripId);
    const owes: { toUserId: string; amount: number; description: string }[] = [];
    const owed: { fromUserId: string; amount: number; description: string }[] = [];

    for (const expense of tripExpenses) {
      if (expense.isSettled) continue;

      const userSplit = expense.splits.find(split => split.userId === userId);
      if (!userSplit) continue;

      if (expense.paidById === userId) {
        // User paid, others owe them
        expense.splits
          .filter(split => split.userId !== userId)
          .forEach(split => {
            owed.push({
              fromUserId: split.userId,
              amount: split.amount,
              description: expense.description,
            });
          });
      } else {
        // User owes the person who paid
        owes.push({
          toUserId: expense.paidById,
          amount: userSplit.amount,
          description: expense.description,
        });
      }
    }

    const totalOwes = owes.reduce((sum, item) => sum + item.amount, 0);
    const totalOwed = owed.reduce((sum, item) => sum + item.amount, 0);
    const netBalance = totalOwed - totalOwes;

    return { owes, owed, netBalance };
  }

  private async calculateSplits(expense: Expense): Promise<SplitCalculation[]> {
    const splitWith = expense.splitWith || [];
    const totalParticipants = splitWith.length + 1; // +1 for the payer
    const totalAmount = parseFloat(expense.amount);

    switch (expense.splitType) {
      case "equal":
        const equalAmount = totalAmount / totalParticipants;
        return [
          { userId: expense.paidById, amount: equalAmount },
          ...splitWith.map(userId => ({ userId, amount: equalAmount })),
        ];

      case "custom":
        if (expense.splitAmounts) {
          const customSplits = JSON.parse(expense.splitAmounts) as Record<string, number>;
          return Object.entries(customSplits).map(([userId, amount]) => ({
            userId,
            amount,
          }));
        }
        break;

      case "percentage":
        if (expense.splitAmounts) {
          const percentageSplits = JSON.parse(expense.splitAmounts) as Record<string, number>;
          return Object.entries(percentageSplits).map(([userId, percentage]) => ({
            userId,
            amount: (totalAmount * percentage) / 100,
            percentage,
          }));
        }
        break;
    }

    // Fallback to equal split
    const fallbackAmount = totalAmount / totalParticipants;
    return [
      { userId: expense.paidById, amount: fallbackAmount },
      ...splitWith.map(userId => ({ userId, amount: fallbackAmount })),
    ];
  }

  private async updateCategorySpentAmount(categoryId: number): Promise<void> {
    const spentResult = await db
      .select({ spent: sum(expenses.amount) })
      .from(expenses)
      .where(eq(expenses.categoryId, categoryId));

    const spentAmount = spentResult[0]?.spent || "0";

    await db
      .update(budgetCategories)
      .set({ spentAmount })
      .where(eq(budgetCategories.id, categoryId));
  }

  private checkIfFullySettled(expense: Expense, settledBy: string[]): boolean {
    const splitWith = expense.splitWith || [];
    const totalParticipants = splitWith.length + 1; // +1 for the payer
    return settledBy.length >= totalParticipants - 1; // -1 because payer doesn't need to settle
  }

  private async getTripDuration(tripId: number): Promise<number> {
    // This would calculate days since trip started
    // For now, return a placeholder
    return 1;
  }

  private getTotalTripDays(tripId: number): number {
    // This would calculate total trip duration
    // For now, return a placeholder
    return 7;
  }
}

export const smartBudgetingService = new SmartBudgetingService();