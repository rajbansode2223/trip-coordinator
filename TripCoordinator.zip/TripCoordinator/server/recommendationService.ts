import OpenAI from "openai";
import { storage } from "./storage";
import type { UpdateUserPreferences, InsertTripRecommendation } from "@shared/schema";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

interface RecommendationRequest {
  budget: number;
  preferredAreas: string[];
  travelStyle?: string;
  duration?: number;
  travelDates?: {
    startMonth: number;
    endMonth: number;
  };
}

interface RecommendationResponse {
  destination: string;
  country: string;
  estimatedBudget: number;
  duration: number;
  description: string;
  highlights: string[];
  bestTime: string;
  activities: string[];
  budgetBreakdown: {
    accommodation: number;
    food: number;
    activities: number;
    transportation: number;
    miscellaneous: number;
  };
}

export class RecommendationService {
  async generateRecommendations(
    userId: string,
    request: RecommendationRequest
  ): Promise<RecommendationResponse[]> {
    const { budget, preferredAreas, travelStyle, duration = 7, travelDates } = request;

    const prompt = this.buildRecommendationPrompt(budget, preferredAreas, travelStyle, duration, travelDates);

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: `You are a professional travel advisor with extensive knowledge of global destinations, current travel costs, and seasonal considerations. Provide realistic, budget-accurate travel recommendations based on current market prices and authentic destination information.`
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.7,
      });

      const recommendationsData = JSON.parse(response.choices[0].message.content || "{}");
      
      if (!recommendationsData.recommendations || !Array.isArray(recommendationsData.recommendations)) {
        throw new Error("Invalid response format from OpenAI");
      }

      const recommendations = recommendationsData.recommendations as RecommendationResponse[];

      // Save recommendations to database
      await Promise.all(
        recommendations.map(async (rec) => {
          const recommendationData: InsertTripRecommendation = {
            userId,
            destination: rec.destination,
            country: rec.country,
            estimatedBudget: rec.estimatedBudget.toString(),
            duration: rec.duration,
            description: rec.description,
            highlights: rec.highlights,
            bestTime: rec.bestTime,
            activities: rec.activities,
            budgetBreakdown: rec.budgetBreakdown,
          };
          
          await storage.createTripRecommendation(recommendationData);
        })
      );

      return recommendations;
    } catch (error) {
      console.error("Error generating recommendations:", error);
      throw new Error("Failed to generate travel recommendations");
    }
  }

  private buildRecommendationPrompt(
    budget: number,
    preferredAreas: string[],
    travelStyle?: string,
    duration: number = 7,
    travelDates?: { startMonth: number; endMonth: number }
  ): string {
    const areasText = preferredAreas.length > 0 ? preferredAreas.join(", ") : "any destination worldwide";
    const styleText = travelStyle ? ` with a ${travelStyle} travel style` : "";
    const datesText = travelDates 
      ? ` during months ${travelDates.startMonth}-${travelDates.endMonth}` 
      : " for any time of year";

    return `Generate 3-5 realistic travel destination recommendations for a ${duration}-day trip with a budget of $${budget.toLocaleString()} USD. 

Preferred areas/regions: ${areasText}
Travel style: ${travelStyle || "flexible"}
Travel timeframe: ${datesText}

Requirements:
- Use current 2024 travel costs and pricing
- Include authentic destinations with real accessibility and infrastructure
- Provide realistic budget breakdowns based on actual accommodation, food, activity, and transportation costs
- Consider seasonal factors, weather, and best travel times
- Match recommendations to the specified budget range (within 10-15% variance is acceptable)
- Include diverse activity types and experiences

Respond with a JSON object in this exact format:
{
  "recommendations": [
    {
      "destination": "City/Region Name",
      "country": "Country Name",
      "estimatedBudget": 2500,
      "duration": 7,
      "description": "Detailed description of the destination and why it fits the budget/preferences",
      "highlights": ["Top attraction 1", "Top attraction 2", "Top attraction 3"],
      "bestTime": "Best months to visit and why",
      "activities": ["Activity type 1", "Activity type 2", "Activity type 3", "Activity type 4"],
      "budgetBreakdown": {
        "accommodation": 800,
        "food": 420,
        "activities": 600,
        "transportation": 500,
        "miscellaneous": 180
      }
    }
  ]
}

Ensure all budget breakdowns add up to the estimatedBudget amount and reflect realistic current market prices.`;
  }

  async updateUserPreferences(userId: string, preferences: UpdateUserPreferences): Promise<void> {
    await storage.updateUserPreferences(userId, preferences);
  }

  async getUserRecommendations(userId: string, limit: number = 10) {
    return await storage.getUserRecommendations(userId, limit);
  }

  async deleteRecommendation(userId: string, recommendationId: number): Promise<void> {
    await storage.deleteUserRecommendation(userId, recommendationId);
  }
}

export const recommendationService = new RecommendationService();