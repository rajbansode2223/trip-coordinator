import { db } from "./db";
import { 
  tripLocations, 
  footprintTrail,
  type InsertTripLocation,
  type InsertFootprintTrail,
  type TripLocation,
  type FootprintTrail 
} from "@shared/schema";
import { eq, and, sql, between } from "drizzle-orm";

interface LocationWithDistance extends TripLocation {
  distance?: number;
  isCurrentLocation?: boolean;
}

interface FootprintData {
  userId: string;
  locations: FootprintTrail[];
  currentLocation?: {
    latitude: number;
    longitude: number;
    timestamp: Date;
  };
  totalDistance: number;
  averageSpeed: number;
}

interface MapBounds {
  north: number;
  south: number;
  east: number;
  west: number;
}

export class SocialMapService {
  async addTripLocation(locationData: InsertTripLocation): Promise<TripLocation> {
    const [location] = await db
      .insert(tripLocations)
      .values(locationData)
      .returning();

    return location;
  }

  async updateTripLocation(
    locationId: number, 
    updates: Partial<InsertTripLocation>
  ): Promise<TripLocation> {
    const [updatedLocation] = await db
      .update(tripLocations)
      .set(updates)
      .where(eq(tripLocations.id, locationId))
      .returning();

    return updatedLocation;
  }

  async deleteTripLocation(locationId: number): Promise<void> {
    await db.delete(tripLocations).where(eq(tripLocations.id, locationId));
  }

  async getTripLocations(
    tripId: number, 
    category?: string,
    publicOnly: boolean = false
  ): Promise<LocationWithDistance[]> {
    let query = db.select().from(tripLocations).where(eq(tripLocations.tripId, tripId));

    if (category) {
      query = query.where(eq(tripLocations.category, category));
    }

    if (publicOnly) {
      query = query.where(eq(tripLocations.isPublic, true));
    }

    const locations = await query.orderBy(sql`${tripLocations.createdAt} DESC`);

    // Could add distance calculations here based on user's current location
    return locations.map(loc => ({
      ...loc,
      distance: undefined, // Would calculate actual distance
      isCurrentLocation: false,
    }));
  }

  async recordFootprint(footprintData: InsertFootprintTrail): Promise<FootprintTrail> {
    const [footprint] = await db
      .insert(footprintTrail)
      .values(footprintData)
      .returning();

    return footprint;
  }

  async getUserFootprints(
    tripId: number,
    userId: string,
    startTime?: Date,
    endTime?: Date
  ): Promise<FootprintTrail[]> {
    let query = db
      .select()
      .from(footprintTrail)
      .where(
        and(
          eq(footprintTrail.tripId, tripId),
          eq(footprintTrail.userId, userId)
        )
      );

    if (startTime && endTime) {
      query = query.where(
        between(footprintTrail.timestamp, startTime, endTime)
      );
    }

    return await query.orderBy(footprintTrail.timestamp);
  }

  async getTripFootprints(
    tripId: number,
    timeRange?: { start: Date; end: Date }
  ): Promise<Record<string, FootprintData>> {
    let query = db
      .select()
      .from(footprintTrail)
      .where(eq(footprintTrail.tripId, tripId));

    if (timeRange) {
      query = query.where(
        between(footprintTrail.timestamp, timeRange.start, timeRange.end)
      );
    }

    const allFootprints = await query.orderBy(footprintTrail.timestamp);

    // Group by user
    const userFootprints: Record<string, FootprintData> = {};

    for (const footprint of allFootprints) {
      if (!userFootprints[footprint.userId]) {
        userFootprints[footprint.userId] = {
          userId: footprint.userId,
          locations: [],
          totalDistance: 0,
          averageSpeed: 0,
        };
      }

      userFootprints[footprint.userId].locations.push(footprint);
    }

    // Calculate statistics for each user
    for (const userId in userFootprints) {
      const userData = userFootprints[userId];
      userData.totalDistance = this.calculateTotalDistance(userData.locations);
      userData.averageSpeed = this.calculateAverageSpeed(userData.locations);
      
      // Set current location as the most recent one
      if (userData.locations.length > 0) {
        const latest = userData.locations[userData.locations.length - 1];
        userData.currentLocation = {
          latitude: parseFloat(latest.latitude.toString()),
          longitude: parseFloat(latest.longitude.toString()),
          timestamp: latest.timestamp,
        };
      }
    }

    return userFootprints;
  }

  async getMapBounds(tripId: number): Promise<MapBounds> {
    const locations = await db
      .select({
        lat: tripLocations.latitude,
        lng: tripLocations.longitude,
      })
      .from(tripLocations)
      .where(eq(tripLocations.tripId, tripId));

    const footprints = await db
      .select({
        lat: footprintTrail.latitude,
        lng: footprintTrail.longitude,
      })
      .from(footprintTrail)
      .where(eq(footprintTrail.tripId, tripId));

    const allCoords = [
      ...locations.map(l => ({ lat: parseFloat(l.lat.toString()), lng: parseFloat(l.lng.toString()) })),
      ...footprints.map(f => ({ lat: parseFloat(f.lat.toString()), lng: parseFloat(f.lng.toString()) })),
    ];

    if (allCoords.length === 0) {
      // Default bounds (world view)
      return {
        north: 85,
        south: -85,
        east: 180,
        west: -180,
      };
    }

    const lats = allCoords.map(c => c.lat);
    const lngs = allCoords.map(c => c.lng);

    const padding = 0.01; // Add small padding around bounds

    return {
      north: Math.max(...lats) + padding,
      south: Math.min(...lats) - padding,
      east: Math.max(...lngs) + padding,
      west: Math.min(...lngs) - padding,
    };
  }

  async getNearbyLocations(
    tripId: number,
    centerLat: number,
    centerLng: number,
    radiusKm: number = 5
  ): Promise<LocationWithDistance[]> {
    // This is a simplified version - in production, you'd use PostGIS or similar
    const locations = await this.getTripLocations(tripId);

    return locations
      .map(location => {
        const distance = this.calculateDistance(
          centerLat,
          centerLng,
          parseFloat(location.latitude.toString()),
          parseFloat(location.longitude.toString())
        );

        return {
          ...location,
          distance,
        };
      })
      .filter(location => (location.distance || 0) <= radiusKm)
      .sort((a, b) => (a.distance || 0) - (b.distance || 0));
  }

  async getLocationRecommendations(
    tripId: number,
    category: string,
    userLat?: number,
    userLng?: number
  ): Promise<LocationWithDistance[]> {
    const categoryLocations = await this.getTripLocations(tripId, category, true);

    // Filter for highly rated or recently visited locations
    const recommendations = categoryLocations.filter(location => {
      const rating = parseFloat(location.rating?.toString() || "0");
      return rating >= 4.0 || location.visitedAt; // High rating or previously visited
    });

    // Add distance calculations if user location provided
    if (userLat && userLng) {
      return recommendations.map(location => ({
        ...location,
        distance: this.calculateDistance(
          userLat,
          userLng,
          parseFloat(location.latitude.toString()),
          parseFloat(location.longitude.toString())
        ),
      }));
    }

    return recommendations;
  }

  async shareLocation(
    tripId: number,
    userId: string,
    latitude: number,
    longitude: number,
    message?: string
  ): Promise<TripLocation> {
    const locationData: InsertTripLocation = {
      tripId,
      userId,
      name: message || "Shared Location",
      latitude: latitude.toString(),
      longitude: longitude.toString(),
      category: "shared",
      isPublic: true,
      visitedAt: new Date(),
    };

    return await this.addTripLocation(locationData);
  }

  private calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
    const R = 6371; // Earth's radius in km
    const dLat = this.toRad(lat2 - lat1);
    const dLng = this.toRad(lng2 - lng1);
    
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this.toRad(lat1)) * Math.cos(this.toRad(lat2)) *
      Math.sin(dLng / 2) * Math.sin(dLng / 2);
    
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  private toRad(degrees: number): number {
    return degrees * (Math.PI / 180);
  }

  private calculateTotalDistance(locations: FootprintTrail[]): number {
    if (locations.length < 2) return 0;

    let total = 0;
    for (let i = 1; i < locations.length; i++) {
      const prev = locations[i - 1];
      const curr = locations[i];
      
      total += this.calculateDistance(
        parseFloat(prev.latitude.toString()),
        parseFloat(prev.longitude.toString()),
        parseFloat(curr.latitude.toString()),
        parseFloat(curr.longitude.toString())
      );
    }

    return total;
  }

  private calculateAverageSpeed(locations: FootprintTrail[]): number {
    if (locations.length < 2) return 0;

    const totalDistance = this.calculateTotalDistance(locations);
    const firstTime = locations[0].timestamp.getTime();
    const lastTime = locations[locations.length - 1].timestamp.getTime();
    const totalHours = (lastTime - firstTime) / (1000 * 60 * 60);

    return totalHours > 0 ? totalDistance / totalHours : 0;
  }
}

export const socialMapService = new SocialMapService();