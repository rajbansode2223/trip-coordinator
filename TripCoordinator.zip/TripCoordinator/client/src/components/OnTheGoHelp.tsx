import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { 
  HelpCircle, 
  Lightbulb, 
  BookOpen, 
  Users, 
  Calendar,
  MapPin,
  Sparkles,
  X,
  ChevronDown,
  MessageCircle
} from "lucide-react";
import VirtualAssistant from "./VirtualAssistant";

interface HelpTip {
  id: string;
  title: string;
  content: string;
  type: "tip" | "guide" | "shortcut";
  relevantPages: string[];
  priority: number;
}

interface ContextualHelp {
  title: string;
  description: string;
  actionText?: string;
  actionPath?: string;
}

export default function OnTheGoHelp() {
  const [location] = useLocation();
  const { user } = useAuth();
  const [showHelp, setShowHelp] = useState(false);
  const [showAssistant, setShowAssistant] = useState(false);
  const [contextualHelp, setContextualHelp] = useState<ContextualHelp | null>(null);
  const [relevantTips, setRelevantTips] = useState<HelpTip[]>([]);

  const helpTips: HelpTip[] = [
    {
      id: "join-trip",
      title: "Join a Trip",
      content: "Ask your friend for their trip code, then click 'Join Trip' to become a participant.",
      type: "guide",
      relevantPages: ["/"],
      priority: 1
    },
    {
      id: "activity-voting",
      title: "Activity Voting",
      content: "Vote on activities to help your group decide. Activities with 4+ votes get locked in automatically.",
      type: "tip",
      relevantPages: ["/trips/"],
      priority: 2
    },
    {
      id: "ai-recommendations",
      title: "AI Recommendations",
      content: "Get personalized destination suggestions based on your budget and preferences.",
      type: "guide",
      relevantPages: ["/recommendations"],
      priority: 1
    },
    {
      id: "trip-stories",
      title: "Share Your Journey",
      content: "Document your travel experiences and inspire others with trip stories.",
      type: "tip",
      relevantPages: ["/feed"],
      priority: 2
    },
    {
      id: "virtual-assistant",
      title: "Ask the Assistant",
      content: "Use the virtual assistant for travel advice, recommendations, and planning help.",
      type: "shortcut",
      relevantPages: ["/", "/trips/", "/recommendations", "/feed"],
      priority: 3
    },
    {
      id: "budget-tracking",
      title: "Budget Management",
      content: "Set a trip budget and track expenses across different categories.",
      type: "guide",
      relevantPages: ["/trips/"],
      priority: 2
    }
  ];

  useEffect(() => {
    updateContextualHelp();
    updateRelevantTips();
  }, [location]);

  const updateContextualHelp = () => {
    let help: ContextualHelp | null = null;

    if (location === "/") {
      help = {
        title: "Welcome to Planit!",
        description: "Start by creating a new trip or joining an existing one with a trip code.",
        actionText: "Get AI Recommendations",
        actionPath: "/recommendations"
      };
    } else if (location === "/recommendations") {
      help = {
        title: "AI-Powered Recommendations",
        description: "Get personalized travel suggestions based on your preferences and budget.",
        actionText: "Create Trip from Recommendation",
      };
    } else if (location === "/feed") {
      help = {
        title: "Trip Stories Feed",
        description: "Browse travel experiences from other users and share your own adventures.",
        actionText: "Share Your Story",
      };
    } else if (location.startsWith("/trips/")) {
      help = {
        title: "Trip Collaboration",
        description: "Work with your group to plan activities, manage budget, and coordinate travel details.",
        actionText: "Invite Friends",
      };
    }

    setContextualHelp(help);
  };

  const updateRelevantTips = () => {
    const relevant = helpTips
      .filter(tip => 
        tip.relevantPages.some(page => 
          page === location || (page.endsWith("/") && location.startsWith(page))
        )
      )
      .sort((a, b) => a.priority - b.priority)
      .slice(0, 3);

    setRelevantTips(relevant);
  };

  const getTipIcon = (type: string) => {
    switch (type) {
      case "tip": return Lightbulb;
      case "guide": return BookOpen;
      case "shortcut": return Sparkles;
      default: return HelpCircle;
    }
  };

  const getTipColor = (type: string) => {
    switch (type) {
      case "tip": return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "guide": return "bg-blue-100 text-blue-800 border-blue-200";
      case "shortcut": return "bg-purple-100 text-purple-800 border-purple-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  return (
    <>
      {/* Contextual Help Banner */}
      {contextualHelp && (
        <Card className="mb-4 border-l-4 border-l-green-500 bg-green-50/50">
          <CardContent className="pt-4">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <h4 className="font-semibold text-green-900 mb-1">{contextualHelp.title}</h4>
                <p className="text-sm text-green-700 mb-2">{contextualHelp.description}</p>
                {contextualHelp.actionText && contextualHelp.actionPath && (
                  <Button size="sm" className="bg-green-600 hover:bg-green-700">
                    {contextualHelp.actionText}
                  </Button>
                )}
              </div>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => setContextualHelp(null)}
                className="text-green-600 hover:text-green-700"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Floating Help Button */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col space-y-2">
        {/* Virtual Assistant Button */}
        <Dialog open={showAssistant} onOpenChange={setShowAssistant}>
          <DialogTrigger asChild>
            <Button
              size="lg"
              className="rounded-full shadow-lg bg-blue-600 hover:bg-blue-700 h-14 w-14"
              title="Virtual Assistant"
            >
              <MessageCircle className="h-6 w-6" />
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-hidden flex flex-col">
            <DialogHeader>
              <DialogTitle>Virtual Travel Assistant</DialogTitle>
            </DialogHeader>
            <div className="flex-1 overflow-hidden">
              <VirtualAssistant />
            </div>
          </DialogContent>
        </Dialog>

        {/* Help & Tips Button */}
        <Dialog open={showHelp} onOpenChange={setShowHelp}>
          <DialogTrigger asChild>
            <Button
              size="lg"
              variant="outline"
              className="rounded-full shadow-lg bg-white hover:bg-gray-50 h-12 w-12"
              title="Help & Tips"
            >
              <HelpCircle className="h-5 w-5" />
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center space-x-2">
                <HelpCircle className="h-5 w-5" />
                <span>Help & Tips</span>
              </DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4">
              {/* Relevant Tips */}
              {relevantTips.length > 0 && (
                <div>
                  <h4 className="font-medium text-gray-900 mb-3">Tips for this page</h4>
                  <div className="space-y-2">
                    {relevantTips.map((tip) => {
                      const IconComponent = getTipIcon(tip.type);
                      return (
                        <Card key={tip.id} className="border-l-4 border-l-blue-500">
                          <CardContent className="pt-3 pb-3">
                            <div className="flex items-start space-x-3">
                              <div className="p-1 rounded-lg bg-blue-100">
                                <IconComponent className="h-4 w-4 text-blue-600" />
                              </div>
                              <div className="flex-1">
                                <div className="flex items-center space-x-2 mb-1">
                                  <span className="font-medium text-sm">{tip.title}</span>
                                  <Badge className={`text-xs ${getTipColor(tip.type)}`}>
                                    {tip.type}
                                  </Badge>
                                </div>
                                <p className="text-xs text-gray-600">{tip.content}</p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Quick Actions */}
              <div>
                <h4 className="font-medium text-gray-900 mb-3">Quick Actions</h4>
                <div className="grid grid-cols-2 gap-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex items-center space-x-2"
                    onClick={() => {
                      setShowHelp(false);
                      setShowAssistant(true);
                    }}
                  >
                    <MessageCircle className="h-4 w-4" />
                    <span>Ask Assistant</span>
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => window.open("mailto:support@planit.com", "_blank")}
                  >
                    Contact Support
                  </Button>
                </div>
              </div>

              {/* Navigation Shortcuts */}
              <div>
                <h4 className="font-medium text-gray-900 mb-3">Quick Navigation</h4>
                <div className="grid grid-cols-1 gap-1">
                  <Button variant="ghost" size="sm" className="justify-start">
                    <MapPin className="h-4 w-4 mr-2" />
                    Dashboard
                  </Button>
                  <Button variant="ghost" size="sm" className="justify-start">
                    <Sparkles className="h-4 w-4 mr-2" />
                    AI Recommendations
                  </Button>
                  <Button variant="ghost" size="sm" className="justify-start">
                    <BookOpen className="h-4 w-4 mr-2" />
                    Trip Stories
                  </Button>
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
}