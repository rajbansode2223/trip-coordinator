import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Copy, Share2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface InviteModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  tripCode: string;
}

export default function InviteModal({ open, onOpenChange, tripCode }: InviteModalProps) {
  const { toast } = useToast();

  const copyTripCode = () => {
    navigator.clipboard.writeText(tripCode);
    toast({
      title: "Copied!",
      description: "Trip code copied to clipboard",
    });
  };

  const shareTrip = () => {
    if (navigator.share) {
      navigator.share({
        title: "Join my trip on Planit",
        text: `Join my trip using code: ${tripCode}`,
        url: window.location.href,
      });
    } else {
      // Fallback to copying URL
      navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Copied!",
        description: "Trip link copied to clipboard",
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Invite Friends</DialogTitle>
          <DialogDescription>
            Share your trip code or link with friends so they can join your adventure.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-6">
          <div className="space-y-2">
            <Label>Trip Code</Label>
            <div className="flex space-x-2">
              <Input 
                value={tripCode} 
                readOnly 
                className="font-mono text-center text-lg tracking-wider"
              />
              <Button onClick={copyTripCode} size="icon" variant="outline">
                <Copy className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-sm text-gray-600">
              Share this code with friends. They can enter it when joining a trip.
            </p>
          </div>
          
          <div className="space-y-4">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-background px-2 text-muted-foreground">Or</span>
              </div>
            </div>
            
            <Button onClick={shareTrip} className="w-full">
              <Share2 className="h-4 w-4 mr-2" />
              Share Trip Link
            </Button>
          </div>
          
          <div className="text-center">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Done
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
