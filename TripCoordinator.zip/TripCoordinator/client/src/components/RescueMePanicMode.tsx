import { useState, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { apiRequest } from "@/lib/queryClient";
import { 
  AlertTriangle, 
  Phone, 
  MapPin, 
  Plus, 
  Shield, 
  Hospital, 
  Car,
  Home,
  UserCheck,
  Clock,
  CheckCircle,
  X
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface EmergencyContact {
  id: number;
  name: string;
  phone: string;
  relationship?: string;
  isLocal: boolean;
  isPrimary: boolean;
}

interface PanicAlert {
  id: number;
  alertType: "medical" | "security" | "lost" | "accident" | "general";
  severity: "low" | "medium" | "high" | "critical";
  location?: string;
  latitude?: string;
  longitude?: string;
  description?: string;
  status: "active" | "acknowledged" | "resolved" | "false_alarm";
  createdAt: string;
}

interface LocalService {
  id: number;
  category: "medical" | "police" | "embassy" | "transport" | "accommodation" | "guide" | "translator";
  name: string;
  phone?: string;
  address?: string;
  website?: string;
  hours?: string;
  rating?: string;
  verified: boolean;
}

interface RescueMePanicModeProps {
  tripId: number;
}

export default function RescueMePanicMode({ tripId }: RescueMePanicModeProps) {
  const [showPanicAlert, setShowPanicAlert] = useState(false);
  const [showAddContact, setShowAddContact] = useState(false);
  const [currentLocation, setCurrentLocation] = useState<{lat: number, lng: number} | null>(null);
  const [panicData, setPanicData] = useState({
    alertType: "general" as const,
    severity: "medium" as const,
    description: "",
    location: "",
  });
  const [newContact, setNewContact] = useState({
    name: "",
    phone: "",
    relationship: "",
    isLocal: false,
    isPrimary: false,
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get user's current location for emergencies
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCurrentLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        () => {
          console.log("Location access denied");
        }
      );
    }
  }, []);

  const { data: emergencyContacts = [] } = useQuery({
    queryKey: ['/api/emergency/contacts', tripId],
    enabled: !!tripId,
  });

  const { data: localServices = [] } = useQuery({
    queryKey: ['/api/emergency/services', tripId],
    enabled: !!tripId,
  });

  const createPanicAlertMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest('/api/emergency/panic', {
        method: 'POST',
        body: JSON.stringify({
          tripId,
          ...data,
          latitude: currentLocation?.lat,
          longitude: currentLocation?.lng,
        }),
      });
    },
    onSuccess: (response) => {
      setShowPanicAlert(false);
      setPanicData({
        alertType: "general",
        severity: "medium",
        description: "",
        location: "",
      });
      
      toast({
        title: "Emergency Alert Activated",
        description: `Alert sent. ${response.autoActions?.length || 0} automatic actions triggered.`,
        variant: "destructive",
      });

      // Show immediate steps to user
      if (response.immediateSteps?.length > 0) {
        setTimeout(() => {
          toast({
            title: "Immediate Steps",
            description: response.immediateSteps[0],
          });
        }, 2000);
      }
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send emergency alert. Try calling emergency services directly.",
        variant: "destructive",
      });
    },
  });

  const addContactMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest('/api/emergency/contacts', {
        method: 'POST',
        body: JSON.stringify({ tripId, ...data }),
      });
    },
    onSuccess: () => {
      setShowAddContact(false);
      setNewContact({
        name: "",
        phone: "",
        relationship: "",
        isLocal: false,
        isPrimary: false,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/emergency/contacts', tripId] });
      toast({
        title: "Contact Added",
        description: "Emergency contact saved successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add emergency contact.",
        variant: "destructive",
      });
    },
  });

  const handlePanicAlert = () => {
    if (!panicData.description.trim()) {
      toast({
        title: "Missing Information",
        description: "Please describe the emergency situation.",
        variant: "destructive",
      });
      return;
    }

    createPanicAlertMutation.mutate(panicData);
  };

  const handleAddContact = () => {
    if (!newContact.name.trim() || !newContact.phone.trim()) {
      toast({
        title: "Missing Information",
        description: "Please provide name and phone number.",
        variant: "destructive",
      });
      return;
    }

    addContactMutation.mutate(newContact);
  };

  const getAlertTypeIcon = (type: string) => {
    switch (type) {
      case "medical": return <Hospital className="h-5 w-5" />;
      case "security": return <Shield className="h-5 w-5" />;
      case "lost": return <MapPin className="h-5 w-5" />;
      case "accident": return <Car className="h-5 w-5" />;
      default: return <AlertTriangle className="h-5 w-5" />;
    }
  };

  const getServiceIcon = (category: string) => {
    switch (category) {
      case "medical": return <Hospital className="h-4 w-4" />;
      case "police": return <Shield className="h-4 w-4" />;
      case "transport": return <Car className="h-4 w-4" />;
      case "accommodation": return <Home className="h-4 w-4" />;
      default: return <Phone className="h-4 w-4" />;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "low": return "bg-blue-100 text-blue-800";
      case "medium": return "bg-yellow-100 text-yellow-800";
      case "high": return "bg-orange-100 text-orange-800";
      case "critical": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="space-y-6">
      {/* Panic Button */}
      <Card className="border-red-200 bg-red-50">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-red-800">
            <AlertTriangle className="h-6 w-6" />
            <span>Emergency Assistance</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-red-700">
            Need immediate help? Our panic mode will alert your emergency contacts and provide local assistance.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Dialog open={showPanicAlert} onOpenChange={setShowPanicAlert}>
              <DialogTrigger asChild>
                <Button variant="destructive" size="lg" className="w-full">
                  <AlertTriangle className="h-5 w-5 mr-2" />
                  PANIC ALERT
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle className="text-red-800">Emergency Alert</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="bg-red-50 p-4 rounded-lg">
                    <p className="text-red-800 font-medium">
                      This will immediately notify your emergency contacts and local services.
                    </p>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="alertType">Emergency Type</Label>
                      <Select value={panicData.alertType} onValueChange={(value: any) => setPanicData(prev => ({ ...prev, alertType: value }))}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="medical">Medical Emergency</SelectItem>
                          <SelectItem value="security">Security Issue</SelectItem>
                          <SelectItem value="lost">Lost/Stranded</SelectItem>
                          <SelectItem value="accident">Accident</SelectItem>
                          <SelectItem value="general">General Emergency</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <Label htmlFor="severity">Severity</Label>
                      <Select value={panicData.severity} onValueChange={(value: any) => setPanicData(prev => ({ ...prev, severity: value }))}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low">Low - Need advice</SelectItem>
                          <SelectItem value="medium">Medium - Need help</SelectItem>
                          <SelectItem value="high">High - Urgent</SelectItem>
                          <SelectItem value="critical">Critical - Life threatening</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="description">Describe the Emergency</Label>
                    <Textarea
                      id="description"
                      placeholder="What's happening? Where are you? What help do you need?"
                      value={panicData.description}
                      onChange={(e) => setPanicData(prev => ({ ...prev, description: e.target.value }))}
                      rows={3}
                    />
                  </div>

                  <div>
                    <Label htmlFor="location">Location Details (Optional)</Label>
                    <Input
                      id="location"
                      placeholder="Building name, street address, landmarks"
                      value={panicData.location}
                      onChange={(e) => setPanicData(prev => ({ ...prev, location: e.target.value }))}
                    />
                  </div>

                  <div className="flex space-x-2">
                    <Button 
                      variant="destructive" 
                      onClick={handlePanicAlert}
                      disabled={createPanicAlertMutation.isPending}
                      className="flex-1"
                    >
                      <AlertTriangle className="h-4 w-4 mr-2" />
                      SEND EMERGENCY ALERT
                    </Button>
                    <Button variant="outline" onClick={() => setShowPanicAlert(false)}>
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>

            <Button 
              variant="outline" 
              size="lg" 
              onClick={() => window.open('tel:112')}
              className="w-full border-red-300 text-red-700 hover:bg-red-50"
            >
              <Phone className="h-5 w-5 mr-2" />
              Call 112 (EU Emergency)
            </Button>

            <Button 
              variant="outline" 
              size="lg" 
              onClick={() => {
                if (currentLocation) {
                  const mapsUrl = `https://www.google.com/maps?q=${currentLocation.lat},${currentLocation.lng}`;
                  window.open(mapsUrl, '_blank');
                }
              }}
              className="w-full border-blue-300 text-blue-700 hover:bg-blue-50"
            >
              <MapPin className="h-5 w-5 mr-2" />
              Share Location
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Emergency Contacts */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Phone className="h-5 w-5" />
              <span>Emergency Contacts</span>
            </div>
            <Dialog open={showAddContact} onOpenChange={setShowAddContact}>
              <DialogTrigger asChild>
                <Button size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Contact
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add Emergency Contact</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="contactName">Name</Label>
                      <Input
                        id="contactName"
                        placeholder="Full name"
                        value={newContact.name}
                        onChange={(e) => setNewContact(prev => ({ ...prev, name: e.target.value }))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="contactPhone">Phone Number</Label>
                      <Input
                        id="contactPhone"
                        placeholder="+1234567890"
                        value={newContact.phone}
                        onChange={(e) => setNewContact(prev => ({ ...prev, phone: e.target.value }))}
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="relationship">Relationship</Label>
                    <Input
                      id="relationship"
                      placeholder="e.g., Parent, Spouse, Friend"
                      value={newContact.relationship}
                      onChange={(e) => setNewContact(prev => ({ ...prev, relationship: e.target.value }))}
                    />
                  </div>

                  <div className="flex items-center space-x-4">
                    <label className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={newContact.isPrimary}
                        onChange={(e) => setNewContact(prev => ({ ...prev, isPrimary: e.target.checked }))}
                      />
                      <span className="text-sm">Primary Contact</span>
                    </label>
                    
                    <label className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={newContact.isLocal}
                        onChange={(e) => setNewContact(prev => ({ ...prev, isLocal: e.target.checked }))}
                      />
                      <span className="text-sm">Local Contact</span>
                    </label>
                  </div>

                  <div className="flex space-x-2">
                    <Button onClick={handleAddContact} disabled={addContactMutation.isPending}>
                      Add Contact
                    </Button>
                    <Button variant="outline" onClick={() => setShowAddContact(false)}>
                      Cancel
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {emergencyContacts.length === 0 ? (
              <p className="text-gray-500 text-center py-4">
                No emergency contacts added yet. Add contacts who can help in case of emergency.
              </p>
            ) : (
              emergencyContacts.map((contact: EmergencyContact) => (
                <div key={contact.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <UserCheck className="h-5 w-5 text-gray-500" />
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-medium">{contact.name}</span>
                        {contact.isPrimary && (
                          <Badge variant="default" className="text-xs">Primary</Badge>
                        )}
                        {contact.isLocal && (
                          <Badge variant="secondary" className="text-xs">Local</Badge>
                        )}
                      </div>
                      <p className="text-sm text-gray-600">{contact.relationship}</p>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => window.open(`tel:${contact.phone}`)}
                  >
                    <Phone className="h-4 w-4 mr-2" />
                    Call
                  </Button>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Local Emergency Services */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Shield className="h-5 w-5" />
            <span>Local Emergency Services</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {localServices.length === 0 ? (
              <div className="col-span-2">
                <p className="text-gray-500 text-center py-4">
                  Local emergency services will be populated based on your trip destination.
                </p>
              </div>
            ) : (
              localServices.map((service: LocalService) => (
                <div key={service.id} className="border rounded-lg p-4">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      {getServiceIcon(service.category)}
                      <div>
                        <p className="font-medium">{service.name}</p>
                        <p className="text-sm text-gray-600 capitalize">{service.category}</p>
                      </div>
                    </div>
                    {service.verified && (
                      <Badge variant="default" className="text-xs">
                        <CheckCircle className="h-3 w-3 mr-1" />
                        Verified
                      </Badge>
                    )}
                  </div>
                  
                  {service.address && (
                    <p className="text-sm text-gray-600 mb-2">{service.address}</p>
                  )}
                  
                  {service.hours && (
                    <div className="flex items-center text-sm text-gray-600 mb-2">
                      <Clock className="h-3 w-3 mr-1" />
                      {service.hours}
                    </div>
                  )}

                  <div className="flex space-x-2">
                    {service.phone && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => window.open(`tel:${service.phone}`)}
                      >
                        <Phone className="h-3 w-3 mr-1" />
                        Call
                      </Button>
                    )}
                    {service.website && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => window.open(service.website, '_blank')}
                      >
                        Website
                      </Button>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Emergency Numbers Quick Reference */}
      <Card className="border-blue-200 bg-blue-50">
        <CardHeader>
          <CardTitle className="text-blue-800">Emergency Numbers</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button
              variant="outline"
              className="h-16 flex-col space-y-1"
              onClick={() => window.open('tel:112')}
            >
              <Phone className="h-4 w-4" />
              <span className="text-xs">EU Emergency</span>
              <span className="font-bold">112</span>
            </Button>
            
            <Button
              variant="outline"
              className="h-16 flex-col space-y-1"
              onClick={() => window.open('tel:911')}
            >
              <Phone className="h-4 w-4" />
              <span className="text-xs">US Emergency</span>
              <span className="font-bold">911</span>
            </Button>
            
            <Button
              variant="outline"
              className="h-16 flex-col space-y-1"
              onClick={() => window.open('tel:999')}
            >
              <Phone className="h-4 w-4" />
              <span className="text-xs">UK Emergency</span>
              <span className="font-bold">999</span>
            </Button>
            
            <Button
              variant="outline"
              className="h-16 flex-col space-y-1"
              onClick={() => window.open('tel:000')}
            >
              <Phone className="h-4 w-4" />
              <span className="text-xs">AU Emergency</span>
              <span className="font-bold">000</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}