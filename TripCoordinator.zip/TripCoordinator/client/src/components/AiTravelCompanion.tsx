import { useState, useEffect } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { apiRequest } from "@/lib/queryClient";
import { Brain, Clock, MapPin, AlertTriangle, CheckCircle, X, Send } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface AiDecision {
  id: number;
  context: string;
  question: string;
  suggestion: string;
  reasoning: string;
  alternatives: string[];
  urgency: "low" | "medium" | "high" | "emergency";
  location?: string;
  isAccepted?: boolean;
  createdAt: string;
}

interface AiTravelCompanionProps {
  tripId: number;
}

export default function AiTravelCompanion({ tripId }: AiTravelCompanionProps) {
  const [isAsking, setIsAsking] = useState(false);
  const [context, setContext] = useState("");
  const [question, setQuestion] = useState("");
  const [location, setLocation] = useState("");
  const [urgency, setUrgency] = useState<"low" | "medium" | "high" | "emergency">("medium");
  const [currentLocation, setCurrentLocation] = useState<{lat: number, lng: number} | null>(null);
  const { toast } = useToast();

  // Get user's current location
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCurrentLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        () => {
          // Location access denied or unavailable
        }
      );
    }
  }, []);

  const { data: decisions = [], refetch } = useQuery({
    queryKey: ['/api/ai-companion/decisions', tripId],
    enabled: !!tripId,
  });

  const askAiMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest('/api/ai-companion/decision', {
        method: 'POST',
        body: JSON.stringify({
          ...data,
          timeOfDay: new Date().toLocaleTimeString(),
          groupSize: 1, // Could be enhanced to get actual group size
        }),
      });
    },
    onSuccess: () => {
      setIsAsking(false);
      setContext("");
      setQuestion("");
      setLocation("");
      refetch();
      toast({
        title: "AI Decision Generated",
        description: "Your travel companion has provided recommendations.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to get AI recommendations. Please try again.",
        variant: "destructive",
      });
    },
  });

  const emergencyAiMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest('/api/ai-companion/emergency', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      refetch();
      toast({
        title: "Emergency Assistance",
        description: "Emergency AI recommendations generated.",
        variant: "destructive",
      });
    },
  });

  const acceptDecisionMutation = useMutation({
    mutationFn: async (decisionId: number) => {
      return await apiRequest(`/api/ai-companion/decisions/${decisionId}/accept`, {
        method: 'PATCH',
      });
    },
    onSuccess: () => {
      refetch();
      toast({
        title: "Decision Accepted",
        description: "Your choice has been recorded.",
      });
    },
  });

  const handleSubmitQuestion = () => {
    if (!context.trim() || !question.trim()) {
      toast({
        title: "Missing Information",
        description: "Please provide both context and your question.",
        variant: "destructive",
      });
      return;
    }

    const questionData = {
      tripId,
      context: context.trim(),
      question: question.trim(),
      location: location.trim() || undefined,
      urgency,
      budget: undefined, // Could be enhanced to get from trip data
    };

    if (urgency === "emergency") {
      emergencyAiMutation.mutate(questionData);
    } else {
      askAiMutation.mutate(questionData);
    }
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case "low": return "bg-green-100 text-green-800";
      case "medium": return "bg-yellow-100 text-yellow-800";
      case "high": return "bg-orange-100 text-orange-800";
      case "emergency": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getUrgencyIcon = (urgency: string) => {
    switch (urgency) {
      case "emergency": return <AlertTriangle className="h-4 w-4" />;
      case "high": return <Clock className="h-4 w-4" />;
      default: return <Brain className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Brain className="h-5 w-5" />
            <span>AI Travel Companion</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {!isAsking ? (
            <div className="text-center">
              <p className="text-gray-600 mb-4">
                Get instant AI-powered advice for any travel situation
              </p>
              <Button onClick={() => setIsAsking(true)} className="mr-2">
                Ask for Advice
              </Button>
              <Button 
                onClick={() => {
                  setIsAsking(true);
                  setUrgency("emergency");
                }} 
                variant="destructive"
              >
                Emergency Help
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <Label htmlFor="context">Current Situation</Label>
                <Textarea
                  id="context"
                  placeholder="Describe your current situation (e.g., 'Lost in downtown Prague', 'Deciding between restaurants', 'Flight delayed')"
                  value={context}
                  onChange={(e) => setContext(e.target.value)}
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="question">Your Question</Label>
                <Textarea
                  id="question"
                  placeholder="What specific advice do you need? (e.g., 'How do I get back to my hotel?', 'Which restaurant should I choose?')"
                  value={question}
                  onChange={(e) => setQuestion(e.target.value)}
                  rows={2}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="location">Location (Optional)</Label>
                  <Input
                    id="location"
                    placeholder="Where are you?"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                  />
                </div>

                <div>
                  <Label htmlFor="urgency">Urgency Level</Label>
                  <Select value={urgency} onValueChange={(value: any) => setUrgency(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low - General advice</SelectItem>
                      <SelectItem value="medium">Medium - Need help soon</SelectItem>
                      <SelectItem value="high">High - Urgent situation</SelectItem>
                      <SelectItem value="emergency">Emergency - Immediate help</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex space-x-2">
                <Button 
                  onClick={handleSubmitQuestion}
                  disabled={askAiMutation.isPending || emergencyAiMutation.isPending}
                  className="flex-1"
                >
                  <Send className="h-4 w-4 mr-2" />
                  {urgency === "emergency" ? "Get Emergency Help" : "Get AI Advice"}
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setIsAsking(false);
                    setContext("");
                    setQuestion("");
                    setLocation("");
                    setUrgency("medium");
                  }}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Recent Decisions */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold">Recent AI Recommendations</h3>
        {decisions.length === 0 ? (
          <Card>
            <CardContent className="text-center py-6">
              <p className="text-gray-500">No AI recommendations yet. Ask your first question above!</p>
            </CardContent>
          </Card>
        ) : (
          decisions.map((decision: AiDecision) => (
            <Card key={decision.id} className="border-l-4 border-l-blue-500">
              <CardContent className="pt-6">
                <div className="space-y-4">
                  {/* Header */}
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-2">
                      {getUrgencyIcon(decision.urgency)}
                      <Badge className={getUrgencyColor(decision.urgency)}>
                        {decision.urgency.toUpperCase()}
                      </Badge>
                      {decision.location && (
                        <div className="flex items-center text-sm text-gray-500">
                          <MapPin className="h-3 w-3 mr-1" />
                          {decision.location}
                        </div>
                      )}
                    </div>
                    <span className="text-xs text-gray-500">
                      {new Date(decision.createdAt).toLocaleString()}
                    </span>
                  </div>

                  {/* Question */}
                  <div>
                    <h4 className="font-medium text-gray-900">Your Question:</h4>
                    <p className="text-gray-600">{decision.question}</p>
                    <p className="text-sm text-gray-500 mt-1">Context: {decision.context}</p>
                  </div>

                  {/* AI Recommendation */}
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <h4 className="font-medium text-blue-900 mb-2">AI Recommendation:</h4>
                    <p className="text-blue-800">{decision.suggestion}</p>
                    <div className="mt-2">
                      <details className="text-sm">
                        <summary className="cursor-pointer text-blue-700 hover:text-blue-900">
                          Why this recommendation?
                        </summary>
                        <p className="mt-2 text-blue-600">{decision.reasoning}</p>
                      </details>
                    </div>
                  </div>

                  {/* Alternatives */}
                  {decision.alternatives && decision.alternatives.length > 0 && (
                    <div>
                      <h4 className="font-medium text-gray-900 mb-2">Alternative Options:</h4>
                      <ul className="list-disc list-inside space-y-1">
                        {decision.alternatives.map((alt, index) => (
                          <li key={index} className="text-gray-600 text-sm">{alt}</li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Action Buttons */}
                  {decision.isAccepted === undefined && (
                    <div className="flex space-x-2">
                      <Button
                        size="sm"
                        onClick={() => acceptDecisionMutation.mutate(decision.id)}
                        disabled={acceptDecisionMutation.isPending}
                      >
                        <CheckCircle className="h-4 w-4 mr-1" />
                        Accept Recommendation
                      </Button>
                    </div>
                  )}

                  {decision.isAccepted && (
                    <div className="flex items-center space-x-2 text-green-600">
                      <CheckCircle className="h-4 w-4" />
                      <span className="text-sm">You accepted this recommendation</span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}