import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { apiRequest } from "@/lib/queryClient";
import { 
  DollarSign, 
  Plus, 
  Receipt, 
  TrendingUp, 
  TrendingDown, 
  Users, 
  AlertTriangle,
  PieChart,
  Calendar
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface BudgetCategory {
  id: number;
  name: string;
  allocatedAmount: string;
  spentAmount: number;
  remainingAmount: number;
  percentageUsed: number;
  color: string;
}

interface Expense {
  id: number;
  amount: string;
  description: string;
  categoryId: number;
  paidById: string;
  splitWith: string[];
  splitType: "equal" | "custom" | "percentage";
  location?: string;
  expenseDate: string;
  isSettled: boolean;
  splits: { userId: string; amount: number }[];
}

interface BudgetSummary {
  totalBudget: number;
  totalSpent: number;
  remaining: number;
  categories: BudgetCategory[];
  dailyAverage: number;
  projectedTotal: number;
  warningLevel: "safe" | "caution" | "danger" | "exceeded";
}

interface SmartBudgetingProps {
  tripId: number;
}

export default function SmartBudgeting({ tripId }: SmartBudgetingProps) {
  const [showAddCategory, setShowAddCategory] = useState(false);
  const [showAddExpense, setShowAddExpense] = useState(false);
  const [newCategory, setNewCategory] = useState({ name: "", allocatedAmount: "", color: "#3b82f6" });
  const [newExpense, setNewExpense] = useState({
    amount: "",
    description: "",
    categoryId: "",
    splitType: "equal" as const,
    location: "",
    expenseDate: new Date().toISOString().split('T')[0],
  });
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: budgetSummary } = useQuery({
    queryKey: ['/api/budget/summary', tripId],
    enabled: !!tripId,
  });

  const { data: expenses = [] } = useQuery({
    queryKey: ['/api/budget/expenses', tripId],
    enabled: !!tripId,
  });

  const { data: balances } = useQuery({
    queryKey: ['/api/budget/balances', tripId],
    enabled: !!tripId,
  });

  const addCategoryMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest('/api/budget/categories', {
        method: 'POST',
        body: JSON.stringify({ tripId, ...data }),
      });
    },
    onSuccess: () => {
      setShowAddCategory(false);
      setNewCategory({ name: "", allocatedAmount: "", color: "#3b82f6" });
      queryClient.invalidateQueries({ queryKey: ['/api/budget/summary', tripId] });
      toast({
        title: "Category Added",
        description: "Budget category created successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create budget category.",
        variant: "destructive",
      });
    },
  });

  const addExpenseMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest('/api/budget/expenses', {
        method: 'POST',
        body: JSON.stringify({ tripId, ...data }),
      });
    },
    onSuccess: () => {
      setShowAddExpense(false);
      setNewExpense({
        amount: "",
        description: "",
        categoryId: "",
        splitType: "equal",
        location: "",
        expenseDate: new Date().toISOString().split('T')[0],
      });
      queryClient.invalidateQueries({ queryKey: ['/api/budget/summary', tripId] });
      queryClient.invalidateQueries({ queryKey: ['/api/budget/expenses', tripId] });
      queryClient.invalidateQueries({ queryKey: ['/api/budget/balances', tripId] });
      toast({
        title: "Expense Added",
        description: "Expense recorded and split calculated.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add expense.",
        variant: "destructive",
      });
    },
  });

  const handleAddCategory = () => {
    if (!newCategory.name.trim() || !newCategory.allocatedAmount) {
      toast({
        title: "Missing Information",
        description: "Please provide category name and budget amount.",
        variant: "destructive",
      });
      return;
    }

    addCategoryMutation.mutate(newCategory);
  };

  const handleAddExpense = () => {
    if (!newExpense.amount || !newExpense.description.trim() || !newExpense.categoryId) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    addExpenseMutation.mutate(newExpense);
  };

  const getWarningColor = (level: string) => {
    switch (level) {
      case "safe": return "text-green-600";
      case "caution": return "text-yellow-600";
      case "danger": return "text-orange-600";
      case "exceeded": return "text-red-600";
      default: return "text-gray-600";
    }
  };

  const getWarningIcon = (level: string) => {
    switch (level) {
      case "exceeded": return <AlertTriangle className="h-5 w-5 text-red-500" />;
      case "danger": return <TrendingDown className="h-5 w-5 text-orange-500" />;
      case "caution": return <TrendingUp className="h-5 w-5 text-yellow-500" />;
      default: return <DollarSign className="h-5 w-5 text-green-500" />;
    }
  };

  if (!budgetSummary) {
    return (
      <Card>
        <CardContent className="text-center py-6">
          <p className="text-gray-500">Loading budget information...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Budget Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <DollarSign className="h-5 w-5" />
              <span>Smart Budget Overview</span>
            </div>
            <div className="flex items-center space-x-2">
              {getWarningIcon(budgetSummary.warningLevel)}
              <span className={`text-sm font-medium ${getWarningColor(budgetSummary.warningLevel)}`}>
                {budgetSummary.warningLevel.toUpperCase()}
              </span>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div className="text-center">
              <p className="text-sm text-gray-600">Total Budget</p>
              <p className="text-2xl font-bold">${budgetSummary.totalBudget.toLocaleString()}</p>
            </div>
            <div className="text-center">
              <p className="text-sm text-gray-600">Spent</p>
              <p className="text-2xl font-bold text-red-600">${budgetSummary.totalSpent.toLocaleString()}</p>
            </div>
            <div className="text-center">
              <p className="text-sm text-gray-600">Remaining</p>
              <p className={`text-2xl font-bold ${budgetSummary.remaining >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                ${budgetSummary.remaining.toLocaleString()}
              </p>
            </div>
            <div className="text-center">
              <p className="text-sm text-gray-600">Daily Average</p>
              <p className="text-2xl font-bold">${budgetSummary.dailyAverage.toLocaleString()}</p>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Budget Progress</span>
              <span>{Math.round((budgetSummary.totalSpent / budgetSummary.totalBudget) * 100)}%</span>
            </div>
            <Progress 
              value={Math.min((budgetSummary.totalSpent / budgetSummary.totalBudget) * 100, 100)} 
              className="h-3"
            />
          </div>
        </CardContent>
      </Card>

      {/* Budget Categories */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <PieChart className="h-5 w-5" />
              <span>Budget Categories</span>
            </div>
            <Dialog open={showAddCategory} onOpenChange={setShowAddCategory}>
              <DialogTrigger asChild>
                <Button size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Category
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add Budget Category</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="categoryName">Category Name</Label>
                    <Input
                      id="categoryName"
                      placeholder="e.g., Food, Transportation, Activities"
                      value={newCategory.name}
                      onChange={(e) => setNewCategory(prev => ({ ...prev, name: e.target.value }))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="categoryAmount">Budget Amount ($)</Label>
                    <Input
                      id="categoryAmount"
                      type="number"
                      placeholder="500"
                      value={newCategory.allocatedAmount}
                      onChange={(e) => setNewCategory(prev => ({ ...prev, allocatedAmount: e.target.value }))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="categoryColor">Category Color</Label>
                    <Input
                      id="categoryColor"
                      type="color"
                      value={newCategory.color}
                      onChange={(e) => setNewCategory(prev => ({ ...prev, color: e.target.value }))}
                    />
                  </div>
                  <div className="flex space-x-2">
                    <Button onClick={handleAddCategory} disabled={addCategoryMutation.isPending}>
                      Add Category
                    </Button>
                    <Button variant="outline" onClick={() => setShowAddCategory(false)}>
                      Cancel
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {budgetSummary.categories.map((category) => (
              <div key={category.id} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <div 
                      className="w-4 h-4 rounded-full" 
                      style={{ backgroundColor: category.color }}
                    />
                    <span className="font-medium">{category.name}</span>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-600">
                      ${category.spentAmount.toLocaleString()} / ${parseFloat(category.allocatedAmount).toLocaleString()}
                    </p>
                    <Badge variant={category.percentageUsed > 100 ? "destructive" : category.percentageUsed > 80 ? "secondary" : "default"}>
                      {category.percentageUsed.toFixed(1)}%
                    </Badge>
                  </div>
                </div>
                <Progress value={Math.min(category.percentageUsed, 100)} className="h-2" />
                <p className="text-xs text-gray-500 mt-1">
                  ${category.remainingAmount.toLocaleString()} remaining
                </p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recent Expenses */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Receipt className="h-5 w-5" />
              <span>Recent Expenses</span>
            </div>
            <Dialog open={showAddExpense} onOpenChange={setShowAddExpense}>
              <DialogTrigger asChild>
                <Button size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Expense
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Expense</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="expenseAmount">Amount ($)</Label>
                      <Input
                        id="expenseAmount"
                        type="number"
                        step="0.01"
                        placeholder="25.50"
                        value={newExpense.amount}
                        onChange={(e) => setNewExpense(prev => ({ ...prev, amount: e.target.value }))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="expenseCategory">Category</Label>
                      <Select value={newExpense.categoryId} onValueChange={(value) => setNewExpense(prev => ({ ...prev, categoryId: value }))}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          {budgetSummary.categories.map((category) => (
                            <SelectItem key={category.id} value={category.id.toString()}>
                              {category.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="expenseDescription">Description</Label>
                    <Textarea
                      id="expenseDescription"
                      placeholder="What was this expense for?"
                      value={newExpense.description}
                      onChange={(e) => setNewExpense(prev => ({ ...prev, description: e.target.value }))}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="expenseLocation">Location (Optional)</Label>
                      <Input
                        id="expenseLocation"
                        placeholder="Restaurant name, store, etc."
                        value={newExpense.location}
                        onChange={(e) => setNewExpense(prev => ({ ...prev, location: e.target.value }))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="expenseDate">Date</Label>
                      <Input
                        id="expenseDate"
                        type="date"
                        value={newExpense.expenseDate}
                        onChange={(e) => setNewExpense(prev => ({ ...prev, expenseDate: e.target.value }))}
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="splitType">Split Type</Label>
                    <Select value={newExpense.splitType} onValueChange={(value: any) => setNewExpense(prev => ({ ...prev, splitType: value }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="equal">Split Equally</SelectItem>
                        <SelectItem value="custom">Custom Split</SelectItem>
                        <SelectItem value="percentage">Percentage Split</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex space-x-2">
                    <Button onClick={handleAddExpense} disabled={addExpenseMutation.isPending}>
                      Add Expense
                    </Button>
                    <Button variant="outline" onClick={() => setShowAddExpense(false)}>
                      Cancel
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {expenses.length === 0 ? (
              <p className="text-gray-500 text-center py-4">No expenses recorded yet.</p>
            ) : (
              expenses.slice(0, 10).map((expense: Expense) => (
                <div key={expense.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2">
                      <span className="font-medium">{expense.description}</span>
                      {expense.splitWith.length > 0 && (
                        <Badge variant="secondary" className="text-xs">
                          <Users className="h-3 w-3 mr-1" />
                          Split {expense.splitWith.length + 1}
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center space-x-4 text-sm text-gray-500">
                      <span className="flex items-center">
                        <Calendar className="h-3 w-3 mr-1" />
                        {new Date(expense.expenseDate).toLocaleDateString()}
                      </span>
                      {expense.location && <span>{expense.location}</span>}
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold">${parseFloat(expense.amount).toLocaleString()}</p>
                    <Badge variant={expense.isSettled ? "default" : "secondary"}>
                      {expense.isSettled ? "Settled" : "Pending"}
                    </Badge>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Balance Summary */}
      {balances && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Users className="h-5 w-5" />
              <span>Your Balance</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center p-4 border rounded-lg">
                <p className="text-sm text-gray-600">You Owe</p>
                <p className="text-2xl font-bold text-red-600">
                  ${balances.owes?.reduce((sum: number, item: any) => sum + item.amount, 0).toLocaleString() || "0"}
                </p>
              </div>
              <div className="text-center p-4 border rounded-lg">
                <p className="text-sm text-gray-600">You're Owed</p>
                <p className="text-2xl font-bold text-green-600">
                  ${balances.owed?.reduce((sum: number, item: any) => sum + item.amount, 0).toLocaleString() || "0"}
                </p>
              </div>
              <div className="text-center p-4 border rounded-lg">
                <p className="text-sm text-gray-600">Net Balance</p>
                <p className={`text-2xl font-bold ${balances.netBalance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  ${Math.abs(balances.netBalance || 0).toLocaleString()}
                  {balances.netBalance !== 0 && (
                    <span className="text-sm ml-1">
                      {balances.netBalance > 0 ? 'owed to you' : 'you owe'}
                    </span>
                  )}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}