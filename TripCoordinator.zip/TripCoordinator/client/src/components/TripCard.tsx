import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Users, DollarSign, MapPin } from "lucide-react";
import { Link } from "wouter";
import type { Trip } from "@shared/schema";

interface TripCardProps {
  trip: Trip;
}

export default function TripCard({ trip }: TripCardProps) {
  const startDate = new Date(trip.startDate);
  const endDate = new Date(trip.endDate);
  const now = new Date();
  
  const isUpcoming = startDate > now;
  const isActive = startDate <= now && endDate >= now;
  const isPast = endDate < now;
  
  const getStatusBadge = () => {
    if (isActive) {
      return <Badge className="bg-green-100 text-green-800">Active</Badge>;
    } else if (isUpcoming) {
      return <Badge className="bg-blue-100 text-blue-800">Upcoming</Badge>;
    } else if (isPast) {
      return <Badge className="bg-gray-100 text-gray-800">Completed</Badge>;
    }
    return null;
  };

  const getDaysInfo = () => {
    if (isActive) {
      const daysLeft = Math.ceil((endDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
      return `${daysLeft} days left`;
    } else if (isUpcoming) {
      const daysUntil = Math.ceil((startDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
      return `${daysUntil} days until trip`;
    } else {
      return `Trip completed`;
    }
  };

  const formatDateRange = () => {
    if (startDate.getFullYear() === endDate.getFullYear()) {
      if (startDate.getMonth() === endDate.getMonth()) {
        return `${startDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - ${endDate.getDate()}, ${startDate.getFullYear()}`;
      } else {
        return `${startDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - ${endDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}, ${startDate.getFullYear()}`;
      }
    } else {
      return `${startDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })} - ${endDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}`;
    }
  };

  return (
    <Card className="hover:shadow-lg transition-shadow cursor-pointer">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-lg">{trip.name}</CardTitle>
            <CardDescription className="flex items-center mt-1">
              <Calendar className="h-4 w-4 mr-1" />
              {formatDateRange()}
            </CardDescription>
          </div>
          {getStatusBadge()}
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="flex items-center justify-between text-sm text-gray-600">
            <span className="flex items-center">
              <MapPin className="h-4 w-4 mr-1" />
              Trip Code: {trip.tripCode}
            </span>
            <span>{getDaysInfo()}</span>
          </div>
          
          {trip.budget && (
            <div className="flex items-center justify-between text-sm">
              <span className="flex items-center text-gray-600">
                <DollarSign className="h-4 w-4 mr-1" />
                Budget
              </span>
              <span className="font-medium">${parseFloat(trip.budget).toLocaleString()}</span>
            </div>
          )}
          
          <div className="pt-3 border-t">
            <Link href={`/trips/${trip.id}`}>
              <Button className="w-full">
                View Trip Details
              </Button>
            </Link>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
