import { useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ThumbsUp, Clock, DollarSign, User, Lock } from "lucide-react";
import type { Activity, User as UserType, ActivityVote } from "@shared/schema";

interface ActivityWithDetails extends Activity {
  creator: UserType;
  votes: ActivityVote[];
  voteCount: number;
}

interface ActivityCardProps {
  activity: ActivityWithDetails;
  currentUserId: string;
}

const categoryColors = {
  adventure: "bg-orange-100 text-orange-800",
  food: "bg-red-100 text-red-800",
  sightseeing: "bg-blue-100 text-blue-800",
  other: "bg-gray-100 text-gray-800",
};

export default function ActivityCard({ activity, currentUserId }: ActivityCardProps) {
  const { toast } = useToast();
  
  const userVote = activity.votes.find(vote => vote.userId === currentUserId);
  const hasVoted = !!userVote;

  const voteMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/activities/${activity.id}/vote`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/trips/${activity.tripId}/activities`] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to vote",
        variant: "destructive",
      });
    },
  });

  const formatTime = (time: string | null) => {
    if (!time) return null;
    return new Date(`2000-01-01T${time}`).toLocaleTimeString([], { 
      hour: 'numeric', 
      minute: '2-digit',
      hour12: true 
    });
  };

  const categoryClass = categoryColors[activity.category as keyof typeof categoryColors] || categoryColors.other;

  return (
    <Card className={`hover:shadow-md transition-shadow ${activity.isLockedIn ? 'ring-2 ring-green-500' : ''}`}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center space-x-2 mb-2">
              <Badge className={categoryClass}>
                {activity.category.charAt(0).toUpperCase() + activity.category.slice(1)}
              </Badge>
              {activity.isLockedIn && (
                <Badge className="bg-green-100 text-green-800">
                  <Lock className="h-3 w-3 mr-1" />
                  Locked In
                </Badge>
              )}
              {activity.time && (
                <span className="text-sm text-gray-600 flex items-center">
                  <Clock className="h-3 w-3 mr-1" />
                  {formatTime(activity.time)}
                </span>
              )}
            </div>
            
            <h4 className="font-semibold text-gray-900 mb-1">{activity.title}</h4>
            
            {activity.description && (
              <p className="text-sm text-gray-600 mb-2">{activity.description}</p>
            )}
            
            {activity.notes && (
              <p className="text-sm text-gray-600 mb-2">{activity.notes}</p>
            )}
            
            <div className="flex items-center space-x-4 text-sm text-gray-500">
              {activity.estimatedCost && (
                <span className="flex items-center">
                  <DollarSign className="h-3 w-3 mr-1" />
                  ${parseFloat(activity.estimatedCost).toLocaleString()}
                </span>
              )}
              <span className="flex items-center">
                <User className="h-3 w-3 mr-1" />
                Added by {activity.creator.firstName} {activity.creator.lastName}
              </span>
            </div>
          </div>
          
          <div className="flex items-center space-x-2 ml-4">
            <Button
              variant={hasVoted ? "default" : "outline"}
              size="sm"
              onClick={() => voteMutation.mutate()}
              disabled={voteMutation.isPending}
              className="flex items-center space-x-1"
            >
              <ThumbsUp className="h-4 w-4" />
              <span>{activity.voteCount}</span>
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
