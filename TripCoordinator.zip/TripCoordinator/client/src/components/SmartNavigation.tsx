import { useState, useEffect } from "react";
import { useLocation, Link } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { 
  MapPin, 
  Home, 
  Calendar, 
  BookOpen, 
  Sparkles, 
  ChevronRight,
  Clock,
  Users,
  TrendingUp
} from "lucide-react";

interface NavigationSuggestion {
  path: string;
  title: string;
  description: string;
  icon: React.ComponentType<any>;
  priority: "high" | "medium" | "low";
  context?: string;
}

export default function SmartNavigation() {
  const [location] = useLocation();
  const { user } = useAuth();
  const [suggestions, setSuggestions] = useState<NavigationSuggestion[]>([]);

  useEffect(() => {
    generateSuggestions();
  }, [location, user]);

  const generateSuggestions = () => {
    const newSuggestions: NavigationSuggestion[] = [];

    // Context-aware suggestions based on current page
    if (location === "/") {
      newSuggestions.push(
        {
          path: "/recommendations",
          title: "Get AI Recommendations",
          description: "Discover personalized travel destinations",
          icon: Sparkles,
          priority: "high",
          context: "Start your trip planning journey"
        },
        {
          path: "/feed",
          title: "Browse Trip Stories",
          description: "Get inspired by other travelers",
          icon: BookOpen,
          priority: "medium",
          context: "Find inspiration for your next adventure"
        }
      );
    } else if (location === "/recommendations") {
      newSuggestions.push(
        {
          path: "/",
          title: "Create Your Trip",
          description: "Turn recommendations into actual plans",
          icon: Calendar,
          priority: "high",
          context: "Ready to plan your trip?"
        }
      );
    } else if (location === "/feed") {
      newSuggestions.push(
        {
          path: "/",
          title: "Plan Your Own Trip",
          description: "Start creating your travel story",
          icon: MapPin,
          priority: "high",
          context: "Inspired? Start planning!"
        }
      );
    } else if (location.startsWith("/trips/")) {
      newSuggestions.push(
        {
          path: "/feed",
          title: "Share Your Story",
          description: "Document your travel experiences",
          icon: BookOpen,
          priority: "medium",
          context: "Share your journey with others"
        }
      );
    }

    // Time-based suggestions
    const currentHour = new Date().getHours();
    if (currentHour >= 18 || currentHour <= 6) {
      newSuggestions.push({
        path: "/feed",
        title: "Evening Inspiration",
        description: "Browse travel stories to wind down",
        icon: BookOpen,
        priority: "low",
        context: "Perfect time for travel inspiration"
      });
    } else if (currentHour >= 9 && currentHour <= 17) {
      newSuggestions.push({
        path: "/recommendations",
        title: "Plan Your Next Trip",
        description: "Use your productive hours for planning",
        icon: Sparkles,
        priority: "medium",
        context: "Great time for trip planning"
      });
    }

    setSuggestions(newSuggestions.slice(0, 3)); // Limit to 3 suggestions
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "bg-blue-100 text-blue-800 border-blue-200";
      case "medium": return "bg-green-100 text-green-800 border-green-200";
      case "low": return "bg-gray-100 text-gray-800 border-gray-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  if (suggestions.length === 0) return null;

  return (
    <Card className="mb-6 border-dashed border-2 border-blue-200 bg-blue-50/50">
      <CardContent className="pt-6">
        <div className="flex items-center space-x-2 mb-4">
          <TrendingUp className="h-5 w-5 text-blue-600" />
          <h3 className="font-semibold text-blue-900">Smart Suggestions</h3>
        </div>
        
        <div className="space-y-3">
          {suggestions.map((suggestion, index) => {
            const IconComponent = suggestion.icon;
            return (
              <Link key={index} href={suggestion.path}>
                <div className="flex items-center justify-between p-3 rounded-lg border bg-white hover:bg-gray-50 transition-colors cursor-pointer group">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 rounded-lg bg-blue-100">
                      <IconComponent className="h-4 w-4 text-blue-600" />
                    </div>
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-medium text-gray-900">{suggestion.title}</span>
                        <Badge className={`text-xs ${getPriorityColor(suggestion.priority)}`}>
                          {suggestion.priority}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600">{suggestion.description}</p>
                      {suggestion.context && (
                        <p className="text-xs text-blue-600 mt-1">{suggestion.context}</p>
                      )}
                    </div>
                  </div>
                  <ChevronRight className="h-4 w-4 text-gray-400 group-hover:text-gray-600" />
                </div>
              </Link>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}