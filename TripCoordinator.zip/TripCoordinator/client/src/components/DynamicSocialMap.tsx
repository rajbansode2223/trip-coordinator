import { useState, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { apiRequest } from "@/lib/queryClient";
import { 
  Map, 
  MapPin, 
  Plus, 
  Navigation, 
  Camera, 
  Star,
  Users,
  Clock,
  Share,
  Route,
  Target,
  Globe
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface TripLocation {
  id: number;
  name: string;
  latitude: string;
  longitude: string;
  address?: string;
  category?: string;
  rating?: string;
  notes?: string;
  isPublic: boolean;
  visitedAt?: string;
  photos: string[];
  userId: string;
}

interface FootprintData {
  userId: string;
  locations: Array<{
    latitude: string;
    longitude: string;
    timestamp: string;
    activity?: string;
  }>;
  currentLocation?: {
    latitude: number;
    longitude: number;
    timestamp: Date;
  };
  totalDistance: number;
  averageSpeed: number;
}

interface DynamicSocialMapProps {
  tripId: number;
}

export default function DynamicSocialMap({ tripId }: DynamicSocialMapProps) {
  const [showAddLocation, setShowAddLocation] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [isRecordingFootprint, setIsRecordingFootprint] = useState(false);
  const [currentLocation, setCurrentLocation] = useState<{lat: number, lng: number} | null>(null);
  const [newLocation, setNewLocation] = useState({
    name: "",
    category: "attraction",
    rating: "",
    notes: "",
    isPublic: true,
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get user's current location
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCurrentLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        () => {
          console.log("Location access denied");
        }
      );
    }
  }, []);

  // Start recording footprint when component mounts
  useEffect(() => {
    if (currentLocation && !isRecordingFootprint) {
      setIsRecordingFootprint(true);
      recordFootprintMutation.mutate({
        latitude: currentLocation.lat,
        longitude: currentLocation.lng,
        activity: "starting",
      });
    }
  }, [currentLocation]);

  const { data: locations = [] } = useQuery({
    queryKey: ['/api/map/locations', tripId, selectedCategory],
    enabled: !!tripId,
  });

  const { data: footprints = {} } = useQuery({
    queryKey: ['/api/map/footprints', tripId],
    enabled: !!tripId,
  });

  const addLocationMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest('/api/map/locations', {
        method: 'POST',
        body: JSON.stringify({
          tripId,
          latitude: currentLocation?.lat,
          longitude: currentLocation?.lng,
          ...data,
        }),
      });
    },
    onSuccess: () => {
      setShowAddLocation(false);
      setNewLocation({
        name: "",
        category: "attraction",
        rating: "",
        notes: "",
        isPublic: true,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/map/locations', tripId] });
      toast({
        title: "Location Added",
        description: "Location has been saved to the trip map.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add location to map.",
        variant: "destructive",
      });
    },
  });

  const recordFootprintMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest('/api/map/footprint', {
        method: 'POST',
        body: JSON.stringify({ tripId, ...data }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/map/footprints', tripId] });
    },
    onError: () => {
      console.log("Failed to record footprint");
    },
  });

  const handleAddLocation = () => {
    if (!newLocation.name.trim()) {
      toast({
        title: "Missing Information",
        description: "Please provide a location name.",
        variant: "destructive",
      });
      return;
    }

    if (!currentLocation) {
      toast({
        title: "Location Required",
        description: "Current location is needed to add this place.",
        variant: "destructive",
      });
      return;
    }

    addLocationMutation.mutate(newLocation);
  };

  const shareCurrentLocation = () => {
    if (!currentLocation) {
      toast({
        title: "Location Unavailable",
        description: "Cannot access your current location.",
        variant: "destructive",
      });
      return;
    }

    addLocationMutation.mutate({
      name: "Shared Location",
      category: "shared",
      notes: `Shared at ${new Date().toLocaleString()}`,
      isPublic: true,
    });
  };

  const recordCurrentFootprint = () => {
    if (!currentLocation) return;

    recordFootprintMutation.mutate({
      latitude: currentLocation.lat,
      longitude: currentLocation.lng,
      activity: "manual",
    });

    toast({
      title: "Location Recorded",
      description: "Your current position has been added to the footprint trail.",
    });
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "restaurant": return "🍽️";
      case "hotel": return "🏨";
      case "attraction": return "🎭";
      case "transport": return "🚌";
      case "shopping": return "🛍️";
      case "shared": return "📍";
      default: return "📍";
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "restaurant": return "bg-orange-100 text-orange-800";
      case "hotel": return "bg-blue-100 text-blue-800";
      case "attraction": return "bg-purple-100 text-purple-800";
      case "transport": return "bg-green-100 text-green-800";
      case "shopping": return "bg-pink-100 text-pink-800";
      case "shared": return "bg-gray-100 text-gray-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const openInMaps = (location: TripLocation) => {
    const lat = parseFloat(location.latitude);
    const lng = parseFloat(location.longitude);
    const mapsUrl = `https://www.google.com/maps?q=${lat},${lng}`;
    window.open(mapsUrl, '_blank');
  };

  const filteredLocations = selectedCategory === "all" 
    ? locations 
    : locations.filter((loc: TripLocation) => loc.category === selectedCategory);

  return (
    <div className="space-y-6">
      {/* Map Controls */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Map className="h-5 w-5" />
              <span>Dynamic Social Map</span>
            </div>
            <div className="flex space-x-2">
              <Button
                size="sm"
                variant="outline"
                onClick={shareCurrentLocation}
                disabled={!currentLocation || addLocationMutation.isPending}
              >
                <Share className="h-4 w-4 mr-2" />
                Share Location
              </Button>
              <Dialog open={showAddLocation} onOpenChange={setShowAddLocation}>
                <DialogTrigger asChild>
                  <Button size="sm">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Place
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add Location to Map</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="locationName">Place Name</Label>
                      <Input
                        id="locationName"
                        placeholder="Restaurant, hotel, attraction..."
                        value={newLocation.name}
                        onChange={(e) => setNewLocation(prev => ({ ...prev, name: e.target.value }))}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="category">Category</Label>
                        <Select value={newLocation.category} onValueChange={(value) => setNewLocation(prev => ({ ...prev, category: value }))}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="restaurant">🍽️ Restaurant</SelectItem>
                            <SelectItem value="hotel">🏨 Hotel</SelectItem>
                            <SelectItem value="attraction">🎭 Attraction</SelectItem>
                            <SelectItem value="transport">🚌 Transport</SelectItem>
                            <SelectItem value="shopping">🛍️ Shopping</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label htmlFor="rating">Rating (1-5)</Label>
                        <Select value={newLocation.rating} onValueChange={(value) => setNewLocation(prev => ({ ...prev, rating: value }))}>
                          <SelectTrigger>
                            <SelectValue placeholder="Rate this place" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="1">⭐ 1 Star</SelectItem>
                            <SelectItem value="2">⭐⭐ 2 Stars</SelectItem>
                            <SelectItem value="3">⭐⭐⭐ 3 Stars</SelectItem>
                            <SelectItem value="4">⭐⭐⭐⭐ 4 Stars</SelectItem>
                            <SelectItem value="5">⭐⭐⭐⭐⭐ 5 Stars</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="notes">Notes</Label>
                      <Textarea
                        id="notes"
                        placeholder="What did you think? Any tips for other travelers?"
                        value={newLocation.notes}
                        onChange={(e) => setNewLocation(prev => ({ ...prev, notes: e.target.value }))}
                        rows={3}
                      />
                    </div>

                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="isPublic"
                        checked={newLocation.isPublic}
                        onChange={(e) => setNewLocation(prev => ({ ...prev, isPublic: e.target.checked }))}
                      />
                      <Label htmlFor="isPublic" className="text-sm">
                        Share with other travelers
                      </Label>
                    </div>

                    <div className="flex space-x-2">
                      <Button onClick={handleAddLocation} disabled={addLocationMutation.isPending}>
                        Add Location
                      </Button>
                      <Button variant="outline" onClick={() => setShowAddLocation(false)}>
                        Cancel
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-4 mb-4">
            <div className="flex items-center space-x-2">
              <Label>Filter by:</Label>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Places</SelectItem>
                  <SelectItem value="restaurant">🍽️ Restaurants</SelectItem>
                  <SelectItem value="hotel">🏨 Hotels</SelectItem>
                  <SelectItem value="attraction">🎭 Attractions</SelectItem>
                  <SelectItem value="transport">🚌 Transport</SelectItem>
                  <SelectItem value="shopping">🛍️ Shopping</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Button
              size="sm"
              variant="outline"
              onClick={recordCurrentFootprint}
              disabled={!currentLocation || recordFootprintMutation.isPending}
            >
              <Target className="h-4 w-4 mr-2" />
              Record Current Location
            </Button>
          </div>

          {/* Current Location Display */}
          {currentLocation && (
            <div className="bg-blue-50 p-3 rounded-lg mb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Navigation className="h-4 w-4 text-blue-600" />
                  <span className="text-sm font-medium text-blue-900">Current Location</span>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    const mapsUrl = `https://www.google.com/maps?q=${currentLocation.lat},${currentLocation.lng}`;
                    window.open(mapsUrl, '_blank');
                  }}
                >
                  <Globe className="h-3 w-3 mr-1" />
                  View in Maps
                </Button>
              </div>
              <p className="text-xs text-blue-700 mt-1">
                {currentLocation.lat.toFixed(6)}, {currentLocation.lng.toFixed(6)}
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Trip Locations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <MapPin className="h-5 w-5" />
            <span>Trip Locations ({filteredLocations.length})</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {filteredLocations.length === 0 ? (
              <p className="text-gray-500 text-center py-4">
                {selectedCategory === "all" 
                  ? "No locations added yet. Start by adding places you visit!"
                  : `No ${selectedCategory} locations found.`
                }
              </p>
            ) : (
              filteredLocations.map((location: TripLocation) => (
                <div key={location.id} className="border rounded-lg p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <span className="text-lg">{getCategoryIcon(location.category || "")}</span>
                        <h4 className="font-medium">{location.name}</h4>
                        {location.category && (
                          <Badge className={getCategoryColor(location.category)}>
                            {location.category}
                          </Badge>
                        )}
                        {location.isPublic && (
                          <Badge variant="outline" className="text-xs">
                            <Users className="h-3 w-3 mr-1" />
                            Public
                          </Badge>
                        )}
                      </div>

                      {location.rating && (
                        <div className="flex items-center space-x-2 mb-2">
                          <Star className="h-4 w-4 text-yellow-500" />
                          <span className="text-sm">{location.rating}/5 stars</span>
                        </div>
                      )}

                      {location.notes && (
                        <p className="text-sm text-gray-600 mb-2">{location.notes}</p>
                      )}

                      <div className="flex items-center space-x-4 text-xs text-gray-500">
                        <span className="flex items-center">
                          <MapPin className="h-3 w-3 mr-1" />
                          {parseFloat(location.latitude).toFixed(4)}, {parseFloat(location.longitude).toFixed(4)}
                        </span>
                        {location.visitedAt && (
                          <span className="flex items-center">
                            <Clock className="h-3 w-3 mr-1" />
                            {new Date(location.visitedAt).toLocaleDateString()}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex flex-col space-y-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => openInMaps(location)}
                      >
                        <Navigation className="h-3 w-3 mr-1" />
                        Directions
                      </Button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Footprint Trail */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Route className="h-5 w-5" />
            <span>Footprint Trail</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {Object.keys(footprints).length === 0 ? (
            <p className="text-gray-500 text-center py-4">
              No footprint data available yet. Location tracking will build your trail automatically.
            </p>
          ) : (
            <div className="space-y-4">
              {Object.entries(footprints).map(([userId, data]: [string, any]) => (
                <div key={userId} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-medium">Travel Path</h4>
                    <Badge variant="outline">
                      {data.locations?.length || 0} points recorded
                    </Badge>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <p className="text-gray-600">Total Distance</p>
                      <p className="font-medium">{data.totalDistance?.toFixed(1) || 0} km</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Average Speed</p>
                      <p className="font-medium">{data.averageSpeed?.toFixed(1) || 0} km/h</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Last Update</p>
                      <p className="font-medium">
                        {data.currentLocation 
                          ? new Date(data.currentLocation.timestamp).toLocaleTimeString()
                          : "N/A"
                        }
                      </p>
                    </div>
                  </div>

                  {data.currentLocation && (
                    <div className="mt-3 p-2 bg-green-50 rounded">
                      <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <span className="text-sm text-green-800">
                          Currently at: {data.currentLocation.latitude.toFixed(4)}, {data.currentLocation.longitude.toFixed(4)}
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Map Integration Notice */}
      <Card className="border-blue-200 bg-blue-50">
        <CardContent className="pt-6">
          <div className="flex items-start space-x-3">
            <Map className="h-5 w-5 text-blue-600 mt-0.5" />
            <div>
              <h4 className="font-medium text-blue-900 mb-1">Interactive Map Coming Soon</h4>
              <p className="text-sm text-blue-800">
                A full interactive map view with location pins and footprint trails will be available in the next update. 
                For now, click "Directions" to view locations in Google Maps.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}