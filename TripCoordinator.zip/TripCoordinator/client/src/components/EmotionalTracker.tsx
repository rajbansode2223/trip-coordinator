import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Slider } from "@/components/ui/slider";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { apiRequest } from "@/lib/queryClient";
import { 
  Heart, 
  TrendingUp, 
  TrendingDown, 
  Smile, 
  Frown, 
  Meh, 
  Battery,
  Star,
  Plus,
  Calendar,
  MapPin,
  Cloud,
  Lightbulb,
  AlertTriangle
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface MoodCheckin {
  id: number;
  mood: "excited" | "happy" | "content" | "neutral" | "tired" | "stressed" | "disappointed";
  energy: number;
  satisfaction: number;
  notes?: string;
  location?: string;
  weather?: string;
  createdAt: string;
}

interface WellbeingReport {
  overallScore: number;
  trends: Array<{
    date: string;
    averageMood: number;
    averageEnergy: number;
    averageSatisfaction: number;
  }>;
  insights: Array<{
    insight: string;
    category: "pattern" | "recommendation" | "warning" | "celebration";
    confidence: string;
    suggestions: string[];
  }>;
  recommendations: string[];
  alerts: string[];
}

interface EmotionalTrackerProps {
  tripId: number;
}

export default function EmotionalTracker({ tripId }: EmotionalTrackerProps) {
  const [showCheckin, setShowCheckin] = useState(false);
  const [checkinData, setCheckinData] = useState({
    mood: "neutral" as const,
    energy: [3],
    satisfaction: [3],
    notes: "",
    location: "",
    weather: "",
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: checkins = [] } = useQuery({
    queryKey: ['/api/mood/checkins', tripId],
    enabled: !!tripId,
  });

  const { data: wellbeingReport } = useQuery({
    queryKey: ['/api/mood/report', tripId],
    enabled: !!tripId,
  });

  const recordCheckinMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest('/api/mood/checkin', {
        method: 'POST',
        body: JSON.stringify({
          tripId,
          ...data,
          energy: data.energy[0],
          satisfaction: data.satisfaction[0],
        }),
      });
    },
    onSuccess: () => {
      setShowCheckin(false);
      setCheckinData({
        mood: "neutral",
        energy: [3],
        satisfaction: [3],
        notes: "",
        location: "",
        weather: "",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/mood/checkins', tripId] });
      queryClient.invalidateQueries({ queryKey: ['/api/mood/report', tripId] });
      toast({
        title: "Mood Recorded",
        description: "Your check-in has been saved and analyzed.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to record mood check-in.",
        variant: "destructive",
      });
    },
  });

  const handleCheckin = () => {
    if (!checkinData.mood) {
      toast({
        title: "Missing Information",
        description: "Please select your current mood.",
        variant: "destructive",
      });
      return;
    }

    recordCheckinMutation.mutate(checkinData);
  };

  const getMoodIcon = (mood: string) => {
    switch (mood) {
      case "excited": return <Smile className="h-5 w-5 text-green-500" />;
      case "happy": return <Smile className="h-5 w-5 text-green-400" />;
      case "content": return <Smile className="h-5 w-5 text-blue-400" />;
      case "neutral": return <Meh className="h-5 w-5 text-gray-400" />;
      case "tired": return <Meh className="h-5 w-5 text-yellow-400" />;
      case "stressed": return <Frown className="h-5 w-5 text-orange-400" />;
      case "disappointed": return <Frown className="h-5 w-5 text-red-400" />;
      default: return <Meh className="h-5 w-5 text-gray-400" />;
    }
  };

  const getMoodColor = (mood: string) => {
    switch (mood) {
      case "excited": return "bg-green-100 text-green-800";
      case "happy": return "bg-green-100 text-green-700";
      case "content": return "bg-blue-100 text-blue-700";
      case "neutral": return "bg-gray-100 text-gray-700";
      case "tired": return "bg-yellow-100 text-yellow-700";
      case "stressed": return "bg-orange-100 text-orange-700";
      case "disappointed": return "bg-red-100 text-red-700";
      default: return "bg-gray-100 text-gray-700";
    }
  };

  const getInsightIcon = (category: string) => {
    switch (category) {
      case "pattern": return <TrendingUp className="h-4 w-4" />;
      case "recommendation": return <Lightbulb className="h-4 w-4" />;
      case "warning": return <AlertTriangle className="h-4 w-4" />;
      case "celebration": return <Star className="h-4 w-4" />;
      default: return <Heart className="h-4 w-4" />;
    }
  };

  const getInsightColor = (category: string) => {
    switch (category) {
      case "pattern": return "text-blue-600";
      case "recommendation": return "text-yellow-600";
      case "warning": return "text-red-600";
      case "celebration": return "text-green-600";
      default: return "text-gray-600";
    }
  };

  return (
    <div className="space-y-6">
      {/* Mood Check-in */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Heart className="h-5 w-5" />
              <span>Emotional Check-in</span>
            </div>
            <Dialog open={showCheckin} onOpenChange={setShowCheckin}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Record Mood
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>How are you feeling?</DialogTitle>
                </DialogHeader>
                <div className="space-y-6">
                  <div>
                    <Label>Current Mood</Label>
                    <div className="grid grid-cols-3 gap-2 mt-2">
                      {[
                        { value: "excited", label: "Excited", icon: "😍" },
                        { value: "happy", label: "Happy", icon: "😊" },
                        { value: "content", label: "Content", icon: "🙂" },
                        { value: "neutral", label: "Neutral", icon: "😐" },
                        { value: "tired", label: "Tired", icon: "😴" },
                        { value: "stressed", label: "Stressed", icon: "😰" },
                        { value: "disappointed", label: "Disappointed", icon: "😞" },
                      ].map((mood) => (
                        <Button
                          key={mood.value}
                          variant={checkinData.mood === mood.value ? "default" : "outline"}
                          size="sm"
                          onClick={() => setCheckinData(prev => ({ ...prev, mood: mood.value as any }))}
                          className="flex flex-col h-16 text-xs"
                        >
                          <span className="text-lg">{mood.icon}</span>
                          <span>{mood.label}</span>
                        </Button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <Label>Energy Level (1-5)</Label>
                    <div className="flex items-center space-x-4 mt-2">
                      <Battery className="h-4 w-4" />
                      <Slider
                        value={checkinData.energy}
                        onValueChange={(value) => setCheckinData(prev => ({ ...prev, energy: value }))}
                        min={1}
                        max={5}
                        step={1}
                        className="flex-1"
                      />
                      <span className="text-sm font-medium w-8">{checkinData.energy[0]}/5</span>
                    </div>
                  </div>

                  <div>
                    <Label>Satisfaction Level (1-5)</Label>
                    <div className="flex items-center space-x-4 mt-2">
                      <Star className="h-4 w-4" />
                      <Slider
                        value={checkinData.satisfaction}
                        onValueChange={(value) => setCheckinData(prev => ({ ...prev, satisfaction: value }))}
                        min={1}
                        max={5}
                        step={1}
                        className="flex-1"
                      />
                      <span className="text-sm font-medium w-8">{checkinData.satisfaction[0]}/5</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="location">Current Location</Label>
                      <Input
                        id="location"
                        placeholder="Where are you?"
                        value={checkinData.location}
                        onChange={(e) => setCheckinData(prev => ({ ...prev, location: e.target.value }))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="weather">Weather</Label>
                      <Select value={checkinData.weather} onValueChange={(value) => setCheckinData(prev => ({ ...prev, weather: value }))}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select weather" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="sunny">☀️ Sunny</SelectItem>
                          <SelectItem value="cloudy">☁️ Cloudy</SelectItem>
                          <SelectItem value="rainy">🌧️ Rainy</SelectItem>
                          <SelectItem value="snowy">❄️ Snowy</SelectItem>
                          <SelectItem value="windy">🌬️ Windy</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="notes">Notes (Optional)</Label>
                    <Textarea
                      id="notes"
                      placeholder="What's happening? How do you feel about your current activity?"
                      value={checkinData.notes}
                      onChange={(e) => setCheckinData(prev => ({ ...prev, notes: e.target.value }))}
                      rows={3}
                    />
                  </div>

                  <div className="flex space-x-2">
                    <Button onClick={handleCheckin} disabled={recordCheckinMutation.isPending}>
                      Record Check-in
                    </Button>
                    <Button variant="outline" onClick={() => setShowCheckin(false)}>
                      Cancel
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {checkins.length === 0 ? (
            <p className="text-gray-500 text-center py-4">
              Start tracking your travel emotions by recording your first mood check-in.
            </p>
          ) : (
            <div className="space-y-3">
              {checkins.slice(0, 3).map((checkin: MoodCheckin) => (
                <div key={checkin.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    {getMoodIcon(checkin.mood)}
                    <div>
                      <div className="flex items-center space-x-2">
                        <Badge className={getMoodColor(checkin.mood)}>
                          {checkin.mood.charAt(0).toUpperCase() + checkin.mood.slice(1)}
                        </Badge>
                        <span className="text-sm text-gray-600">
                          Energy: {checkin.energy}/5
                        </span>
                        <span className="text-sm text-gray-600">
                          Satisfaction: {checkin.satisfaction}/5
                        </span>
                      </div>
                      <div className="flex items-center space-x-4 text-xs text-gray-500">
                        <span className="flex items-center">
                          <Calendar className="h-3 w-3 mr-1" />
                          {new Date(checkin.createdAt).toLocaleString()}
                        </span>
                        {checkin.location && (
                          <span className="flex items-center">
                            <MapPin className="h-3 w-3 mr-1" />
                            {checkin.location}
                          </span>
                        )}
                        {checkin.weather && (
                          <span className="flex items-center">
                            <Cloud className="h-3 w-3 mr-1" />
                            {checkin.weather}
                          </span>
                        )}
                      </div>
                      {checkin.notes && (
                        <p className="text-sm text-gray-600 mt-1">{checkin.notes}</p>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Wellbeing Report */}
      {wellbeingReport && (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <TrendingUp className="h-5 w-5" />
                <span>Wellbeing Overview</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="relative w-24 h-24 mx-auto mb-4">
                    <div className="absolute inset-0 rounded-full border-8 border-gray-200"></div>
                    <div 
                      className="absolute inset-0 rounded-full border-8 border-blue-500"
                      style={{
                        clipPath: `polygon(50% 50%, 50% 0%, ${50 + (wellbeingReport.overallScore * 50) / 5}% 0%, 50% 50%)`
                      }}
                    ></div>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-2xl font-bold">{wellbeingReport.overallScore.toFixed(1)}</span>
                    </div>
                  </div>
                  <p className="font-medium">Overall Wellbeing</p>
                  <p className="text-sm text-gray-600">Out of 5.0</p>
                </div>

                <div className="space-y-3">
                  <h4 className="font-medium">Recent Trends</h4>
                  {wellbeingReport.trends.slice(0, 5).map((trend, index) => (
                    <div key={index} className="flex items-center justify-between text-sm">
                      <span>{new Date(trend.date).toLocaleDateString()}</span>
                      <div className="flex space-x-2">
                        <span>Mood: {trend.averageMood.toFixed(1)}</span>
                        <span>Energy: {trend.averageEnergy.toFixed(1)}</span>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="space-y-3">
                  <h4 className="font-medium">Quick Stats</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Check-ins</span>
                      <span>{checkins.length}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Avg Energy</span>
                      <span>{wellbeingReport.trends.length > 0 ? (wellbeingReport.trends.reduce((sum, t) => sum + t.averageEnergy, 0) / wellbeingReport.trends.length).toFixed(1) : "N/A"}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Avg Satisfaction</span>
                      <span>{wellbeingReport.trends.length > 0 ? (wellbeingReport.trends.reduce((sum, t) => sum + t.averageSatisfaction, 0) / wellbeingReport.trends.length).toFixed(1) : "N/A"}</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* AI Insights */}
          {wellbeingReport.insights.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Lightbulb className="h-5 w-5" />
                  <span>AI Emotional Insights</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {wellbeingReport.insights.map((insight, index) => (
                    <div key={index} className="border rounded-lg p-4">
                      <div className="flex items-start space-x-3">
                        <div className={`mt-1 ${getInsightColor(insight.category)}`}>
                          {getInsightIcon(insight.category)}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <Badge variant="outline" className={getInsightColor(insight.category)}>
                              {insight.category.charAt(0).toUpperCase() + insight.category.slice(1)}
                            </Badge>
                            <span className="text-xs text-gray-500">
                              Confidence: {Math.round(parseFloat(insight.confidence) * 100)}%
                            </span>
                          </div>
                          <p className="text-gray-800 mb-2">{insight.insight}</p>
                          {insight.suggestions.length > 0 && (
                            <div>
                              <p className="text-sm font-medium text-gray-700 mb-1">Suggestions:</p>
                              <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
                                {insight.suggestions.map((suggestion, idx) => (
                                  <li key={idx}>{suggestion}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Recommendations & Alerts */}
          {(wellbeingReport.recommendations.length > 0 || wellbeingReport.alerts.length > 0) && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {wellbeingReport.recommendations.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2 text-blue-700">
                      <Lightbulb className="h-5 w-5" />
                      <span>Recommendations</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {wellbeingReport.recommendations.map((rec, index) => (
                        <li key={index} className="flex items-start space-x-2">
                          <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                          <span className="text-sm">{rec}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              )}

              {wellbeingReport.alerts.length > 0 && (
                <Card className="border-orange-200 bg-orange-50">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2 text-orange-700">
                      <AlertTriangle className="h-5 w-5" />
                      <span>Wellness Alerts</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {wellbeingReport.alerts.map((alert, index) => (
                        <li key={index} className="flex items-start space-x-2">
                          <AlertTriangle className="w-4 h-4 text-orange-500 mt-0.5 flex-shrink-0" />
                          <span className="text-sm text-orange-800">{alert}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              )}
            </div>
          )}
        </>
      )}
    </div>
  );
}