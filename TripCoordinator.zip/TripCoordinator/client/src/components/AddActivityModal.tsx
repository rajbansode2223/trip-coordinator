import { useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertActivitySchema } from "@shared/schema";
import { z } from "zod";

const createActivityFormSchema = insertActivitySchema.extend({
  title: z.string().min(1, "Activity title is required"),
  date: z.string().min(1, "Date is required"),
  time: z.string().optional(),
  category: z.enum(["Adventure", "Food", "Sightseeing", "Other"], {
    required_error: "Please select a category",
  }),
  estimatedCost: z.string().optional(),
  notes: z.string().optional(),
}).omit({ tripId: true, creatorId: true });

type CreateActivityFormData = z.infer<typeof createActivityFormSchema>;

interface AddActivityModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  tripId: number;
  tripDates: {
    startDate: string;
    endDate: string;
  };
}

export default function AddActivityModal({ open, onOpenChange, tripId, tripDates }: AddActivityModalProps) {
  const { toast } = useToast();
  
  const {
    register,
    handleSubmit,
    reset,
    control,
    formState: { errors }
  } = useForm<CreateActivityFormData>({
    resolver: zodResolver(createActivityFormSchema),
    defaultValues: {
      title: "",
      date: "",
      time: "",
      category: undefined,
      estimatedCost: "",
      notes: "",
    }
  });

  const createActivityMutation = useMutation({
    mutationFn: async (data: CreateActivityFormData) => {
      const response = await apiRequest("POST", `/api/trips/${tripId}/activities`, {
        title: data.title,
        description: data.notes,
        date: data.date,
        time: data.time || null,
        category: data.category.toLowerCase(),
        estimatedCost: data.estimatedCost ? parseFloat(data.estimatedCost).toString() : null,
        notes: data.notes,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/trips/${tripId}/activities`] });
      onOpenChange(false);
      reset();
      toast({
        title: "Success",
        description: "Activity added successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to add activity",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: CreateActivityFormData) => {
    // Validate date is within trip dates
    const activityDate = new Date(data.date);
    const startDate = new Date(tripDates.startDate);
    const endDate = new Date(tripDates.endDate);
    
    if (activityDate < startDate || activityDate > endDate) {
      toast({
        title: "Invalid date",
        description: "Activity date must be within the trip dates",
        variant: "destructive",
      });
      return;
    }
    
    createActivityMutation.mutate(data);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Add New Activity</DialogTitle>
          <DialogDescription>
            Add an activity to your trip itinerary. Others can vote on it to help decide what to do.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Activity Title</Label>
            <Input
              id="title"
              placeholder="e.g., Kayaking at Blue Lagoon"
              {...register("title")}
            />
            {errors.title && (
              <p className="text-sm text-red-600">{errors.title.message}</p>
            )}
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="date">Date</Label>
              <Input
                id="date"
                type="date"
                min={tripDates.startDate}
                max={tripDates.endDate}
                {...register("date")}
              />
              {errors.date && (
                <p className="text-sm text-red-600">{errors.date.message}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="time">Time (optional)</Label>
              <Input
                id="time"
                type="time"
                {...register("time")}
              />
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="category">Category</Label>
              <Controller
                name="category"
                control={control}
                render={({ field }) => (
                  <Select onValueChange={field.onChange} value={field.value}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Adventure">Adventure</SelectItem>
                      <SelectItem value="Food">Food</SelectItem>
                      <SelectItem value="Sightseeing">Sightseeing</SelectItem>
                      <SelectItem value="Other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                )}
              />
              {errors.category && (
                <p className="text-sm text-red-600">{errors.category.message}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="estimatedCost">Estimated Cost (optional)</Label>
              <Input
                id="estimatedCost"
                type="number"
                placeholder="0.00"
                step="0.01"
                {...register("estimatedCost")}
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="notes">Notes (optional)</Label>
            <Textarea
              id="notes"
              placeholder="Add any additional details, booking info, or special requirements..."
              rows={3}
              {...register("notes")}
            />
          </div>
          
          <div className="flex justify-end space-x-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={createActivityMutation.isPending}>
              {createActivityMutation.isPending ? "Adding..." : "Add Activity"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
