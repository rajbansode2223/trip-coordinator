import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { CalendarIcon, MapPin, DollarSign, Users, Plane } from "lucide-react";

export default function Demo() {
  const { toast } = useToast();
  const [tripData, setTripData] = useState({
    name: "",
    destination: "",
    budget: "",
    startDate: "",
    endDate: "",
    description: ""
  });
  const [createdTrip, setCreatedTrip] = useState<any>(null);

  const createTripMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await fetch("/api/trips/demo", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        throw new Error("Failed to create trip");
      }
      return response.json();
    },
    onSuccess: (trip) => {
      setCreatedTrip(trip);
      toast({
        title: "Demo Trip Created!",
        description: `"${trip.name}" is ready for your interview demonstration.`,
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create demo trip. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createTripMutation.mutate(tripData);
  };

  const quickFillDemo = () => {
    setTripData({
      name: "Team Building Adventure",
      destination: "Kyoto, Japan",
      budget: "4500",
      startDate: "2024-12-20",
      endDate: "2024-12-27",
      description: "A week-long team building trip exploring traditional Japanese culture, temples, and cuisine."
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Planit Demo - Interview Mode
          </h1>
          <p className="text-lg text-gray-600">
            Create demonstration trips instantly without authentication
          </p>
        </div>

        {!createdTrip ? (
          <Card className="max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plane className="h-6 w-6 text-blue-600" />
                Create Demo Trip
              </CardTitle>
              <CardDescription>
                Fill out the details below to create a demo trip for your interview presentation
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Trip Name</Label>
                    <Input
                      id="name"
                      value={tripData.name}
                      onChange={(e) => setTripData({ ...tripData, name: e.target.value })}
                      placeholder="Enter trip name"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="destination" className="flex items-center gap-1">
                      <MapPin className="h-4 w-4" />
                      Destination
                    </Label>
                    <Input
                      id="destination"
                      value={tripData.destination}
                      onChange={(e) => setTripData({ ...tripData, destination: e.target.value })}
                      placeholder="Where are you going?"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="budget" className="flex items-center gap-1">
                      <DollarSign className="h-4 w-4" />
                      Budget (USD)
                    </Label>
                    <Input
                      id="budget"
                      type="number"
                      value={tripData.budget}
                      onChange={(e) => setTripData({ ...tripData, budget: e.target.value })}
                      placeholder="5000"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="startDate" className="flex items-center gap-1">
                      <CalendarIcon className="h-4 w-4" />
                      Start Date
                    </Label>
                    <Input
                      id="startDate"
                      type="date"
                      value={tripData.startDate}
                      onChange={(e) => setTripData({ ...tripData, startDate: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="endDate">End Date</Label>
                    <Input
                      id="endDate"
                      type="date"
                      value={tripData.endDate}
                      onChange={(e) => setTripData({ ...tripData, endDate: e.target.value })}
                      required
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="description">Description (Optional)</Label>
                  <Textarea
                    id="description"
                    value={tripData.description}
                    onChange={(e) => setTripData({ ...tripData, description: e.target.value })}
                    placeholder="Describe your trip plans..."
                    rows={3}
                  />
                </div>

                <div className="flex gap-3 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={quickFillDemo}
                    className="flex-1"
                  >
                    Quick Fill Demo Data
                  </Button>
                  <Button
                    type="submit"
                    disabled={createTripMutation.isPending}
                    className="flex-1"
                  >
                    {createTripMutation.isPending ? "Creating..." : "Create Demo Trip"}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            <Card className="border-green-200 bg-green-50">
              <CardHeader>
                <CardTitle className="text-green-800 flex items-center gap-2">
                  <Users className="h-6 w-6" />
                  Demo Trip Created Successfully!
                </CardTitle>
                <CardDescription className="text-green-700">
                  Your demonstration trip is ready for the interview presentation
                </CardDescription>
              </CardHeader>
              <CardContent className="text-green-800">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="font-semibold">Trip Name:</p>
                    <p>{createdTrip.name}</p>
                  </div>
                  <div>
                    <p className="font-semibold">Destination:</p>
                    <p>{createdTrip.destination}</p>
                  </div>
                  <div>
                    <p className="font-semibold">Budget:</p>
                    <p>${createdTrip.budget}</p>
                  </div>
                  <div>
                    <p className="font-semibold">Trip Code:</p>
                    <p className="font-mono text-lg">{createdTrip.tripCode}</p>
                  </div>
                  <div>
                    <p className="font-semibold">Duration:</p>
                    <p>{createdTrip.startDate} to {createdTrip.endDate}</p>
                  </div>
                  <div>
                    <p className="font-semibold">Trip ID:</p>
                    <p>#{createdTrip.id}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Interview Demonstration Points</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="font-semibold text-lg mb-3">Core Features</h3>
                    <ul className="space-y-2 text-sm">
                      <li>✅ Trip creation without authentication</li>
                      <li>✅ Unique trip code generation</li>
                      <li>✅ Database persistence</li>
                      <li>✅ Responsive form design</li>
                      <li>✅ Real-time validation</li>
                    </ul>
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg mb-3">Advanced Features Ready</h3>
                    <ul className="space-y-2 text-sm">
                      <li>🤖 AI Travel Companion</li>
                      <li>💰 Smart Budgeting</li>
                      <li>🗺️ Dynamic Social Map</li>
                      <li>😊 Emotional Tracker</li>
                      <li>🚨 Rescue Me Panic Mode</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="text-center">
              <Button
                onClick={() => {
                  setCreatedTrip(null);
                  setTripData({
                    name: "",
                    destination: "",
                    budget: "",
                    startDate: "",
                    endDate: "",
                    description: ""
                  });
                }}
                variant="outline"
                size="lg"
              >
                Create Another Demo Trip
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}