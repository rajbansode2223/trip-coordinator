import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Heart, MessageCircle, Share2, Plus, MapPin, Calendar, Camera, Send, Clock, Users } from "lucide-react";
import { Link } from "wouter";
import VirtualAssistant from "@/components/VirtualAssistant";
import SmartNavigation from "@/components/SmartNavigation";
import OnTheGoHelp from "@/components/OnTheGoHelp";
import type { TripStory, User, Trip, StoryLike, StoryComment } from "@shared/schema";
import { z } from "zod";

interface StoryWithDetails extends TripStory {
  author: User;
  trip: Trip;
  likes: StoryLike[];
  comments: (StoryComment & { author: User })[];
  likeCount: number;
  commentCount: number;
  userHasLiked: boolean;
}

const createStorySchema = z.object({
  tripId: z.number(),
  title: z.string().min(1, "Title is required"),
  content: z.string().min(1, "Content is required"),
  location: z.string().optional(),
  isPublic: z.boolean().default(true),
});

type CreateStoryFormData = z.infer<typeof createStorySchema>;

export default function Feed() {
  const { user, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedStory, setSelectedStory] = useState<StoryWithDetails | null>(null);
  const [newComment, setNewComment] = useState("");

  const { data: stories = [], isLoading: storiesLoading } = useQuery<StoryWithDetails[]>({
    queryKey: ["/api/stories"],
    enabled: !!user,
    retry: false,
  });

  const { data: userTrips = [] } = useQuery<Trip[]>({
    queryKey: ["/api/trips"],
    enabled: !!user && showCreateModal,
    retry: false,
  });

  const createStoryMutation = useMutation({
    mutationFn: async (data: CreateStoryFormData) => {
      await apiRequest("POST", "/api/stories", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/stories"] });
      setShowCreateModal(false);
      toast({
        title: "Success",
        description: "Story shared successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to share story",
        variant: "destructive",
      });
    },
  });

  const toggleLikeMutation = useMutation({
    mutationFn: async (storyId: number) => {
      await apiRequest("POST", `/api/stories/${storyId}/like`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/stories"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized", 
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update like",
        variant: "destructive",
      });
    },
  });

  const addCommentMutation = useMutation({
    mutationFn: async ({ storyId, content }: { storyId: number; content: string }) => {
      await apiRequest("POST", `/api/stories/${storyId}/comments`, { content });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/stories"] });
      setNewComment("");
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to add comment",
        variant: "destructive",
      });
    },
  });

  const handleCreateStory = (data: CreateStoryFormData) => {
    createStoryMutation.mutate(data);
  };

  const handleLike = (storyId: number) => {
    toggleLikeMutation.mutate(storyId);
  };

  const handleAddComment = (storyId: number) => {
    if (!newComment.trim()) return;
    addCommentMutation.mutate({ storyId, content: newComment.trim() });
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Link href="/">
                <div className="flex items-center space-x-2">
                  <MapPin className="h-6 w-6 text-blue-600" />
                  <h1 className="text-xl font-bold text-gray-900">Planit</h1>
                </div>
              </Link>
              <span className="text-gray-300">|</span>
              <span className="font-medium text-gray-700">Trip Stories</span>
            </div>
            <div className="flex items-center space-x-4">
              <Button onClick={() => setShowCreateModal(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Share Story
              </Button>
              <div className="flex items-center space-x-2">
                {(user as any)?.profileImageUrl && (
                  <img
                    src={(user as any).profileImageUrl}
                    alt="Profile"
                    className="w-8 h-8 rounded-full object-cover"
                  />
                )}
                <span className="text-sm font-medium">
                  {(user as any)?.firstName} {(user as any)?.lastName}
                </span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Smart Navigation */}
        <SmartNavigation />

        {/* Feed Header */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Travel Stories</h2>
          <p className="text-gray-600">Discover amazing travel experiences shared by the community</p>
        </div>

        {/* Stories Feed */}
        {storiesLoading ? (
          <div className="space-y-6">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="animate-pulse">
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-gray-300 rounded-full"></div>
                    <div className="flex-1">
                      <div className="h-4 bg-gray-300 rounded w-1/4 mb-2"></div>
                      <div className="h-3 bg-gray-300 rounded w-1/3"></div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="h-4 bg-gray-300 rounded w-3/4 mb-4"></div>
                  <div className="h-32 bg-gray-300 rounded mb-4"></div>
                  <div className="flex space-x-4">
                    <div className="h-8 bg-gray-300 rounded w-16"></div>
                    <div className="h-8 bg-gray-300 rounded w-16"></div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : stories.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <Camera className="h-12 w-12 mx-auto text-gray-400 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No stories yet</h3>
              <p className="text-gray-600 mb-6">Be the first to share your travel experiences!</p>
              <Button onClick={() => setShowCreateModal(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Share Your Story
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {stories.map((story: StoryWithDetails) => (
              <Card key={story.id} className="overflow-hidden">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Avatar>
                        <AvatarImage src={story.author.profileImageUrl || ""} />
                        <AvatarFallback>
                          {story.author.firstName?.[0]}{story.author.lastName?.[0]}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium text-gray-900">
                          {story.author.firstName} {story.author.lastName}
                        </p>
                        <div className="flex items-center space-x-2 text-sm text-gray-600">
                          <Clock className="h-3 w-3" />
                          <span>{new Date(story.createdAt || "").toLocaleDateString()}</span>
                          {story.location && (
                            <>
                              <span>•</span>
                              <MapPin className="h-3 w-3" />
                              <span>{story.location}</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                    <Badge variant="outline">
                      <Link href={`/trips/${story.trip.id}`} className="flex items-center space-x-1">
                        <Users className="h-3 w-3" />
                        <span>{story.trip.name}</span>
                      </Link>
                    </Badge>
                  </div>
                </CardHeader>
                
                <CardContent>
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">{story.title}</h3>
                  <p className="text-gray-700 whitespace-pre-wrap mb-4">{story.content}</p>
                  
                  {story.images && story.images.length > 0 && (
                    <div className="grid grid-cols-2 gap-2 mb-4">
                      {story.images.slice(0, 4).map((image, index) => (
                        <img
                          key={index}
                          src={image}
                          alt={`Story image ${index + 1}`}
                          className="w-full h-48 object-cover rounded-lg"
                        />
                      ))}
                    </div>
                  )}

                  <Separator className="my-4" />
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleLike(story.id)}
                        className={story.userHasLiked ? "text-red-600" : ""}
                      >
                        <Heart className={`h-4 w-4 mr-1 ${story.userHasLiked ? "fill-current" : ""}`} />
                        {story.likeCount}
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setSelectedStory(story)}
                      >
                        <MessageCircle className="h-4 w-4 mr-1" />
                        {story.commentCount}
                      </Button>
                    </div>
                    <Button variant="ghost" size="sm">
                      <Share2 className="h-4 w-4 mr-1" />
                      Share
                    </Button>
                  </div>

                  {story.comments.length > 0 && (
                    <div className="mt-4 space-y-3">
                      {story.comments.slice(0, 2).map((comment) => (
                        <div key={comment.id} className="flex items-start space-x-2">
                          <Avatar className="w-6 h-6">
                            <AvatarImage src={comment.author.profileImageUrl || ""} />
                            <AvatarFallback className="text-xs">
                              {comment.author.firstName?.[0]}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 bg-gray-50 rounded-lg p-2">
                            <p className="text-xs font-medium text-gray-900">
                              {comment.author.firstName} {comment.author.lastName}
                            </p>
                            <p className="text-sm text-gray-700">{comment.content}</p>
                          </div>
                        </div>
                      ))}
                      {story.commentCount > 2 && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setSelectedStory(story)}
                          className="text-xs"
                        >
                          View all {story.commentCount} comments
                        </Button>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>

      {/* Create Story Modal */}
      <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Share Your Trip Story</DialogTitle>
            <DialogDescription>
              Share your travel experiences with the community
            </DialogDescription>
          </DialogHeader>
          <CreateStoryForm 
            trips={userTrips}
            onSubmit={handleCreateStory}
            isSubmitting={createStoryMutation.isPending}
          />
        </DialogContent>
      </Dialog>

      {/* Story Comments Modal */}
      {selectedStory && (
        <Dialog open={!!selectedStory} onOpenChange={() => setSelectedStory(null)}>
          <DialogContent className="max-w-2xl max-h-[80vh]">
            <DialogHeader>
              <DialogTitle>{selectedStory.title}</DialogTitle>
              <DialogDescription>
                by {selectedStory.author.firstName} {selectedStory.author.lastName}
              </DialogDescription>
            </DialogHeader>
            <ScrollArea className="max-h-96 pr-4">
              <div className="space-y-4">
                {selectedStory.comments.map((comment) => (
                  <div key={comment.id} className="flex items-start space-x-3">
                    <Avatar>
                      <AvatarImage src={comment.author.profileImageUrl || ""} />
                      <AvatarFallback>
                        {comment.author.firstName?.[0]}{comment.author.lastName?.[0]}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="bg-gray-50 rounded-lg p-3">
                        <p className="font-medium text-gray-900 text-sm">
                          {comment.author.firstName} {comment.author.lastName}
                        </p>
                        <p className="text-gray-700">{comment.content}</p>
                      </div>
                      <p className="text-xs text-gray-500 mt-1">
                        {new Date(comment.createdAt || "").toLocaleString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
            <div className="flex space-x-2 mt-4">
              <Input
                placeholder="Add a comment..."
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleAddComment(selectedStory.id);
                  }
                }}
              />
              <Button 
                onClick={() => handleAddComment(selectedStory.id)}
                disabled={!newComment.trim() || addCommentMutation.isPending}
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}

      <OnTheGoHelp />
    </div>
  );
}

function CreateStoryForm({ 
  trips, 
  onSubmit, 
  isSubmitting 
}: { 
  trips: Trip[]; 
  onSubmit: (data: CreateStoryFormData) => void; 
  isSubmitting: boolean; 
}) {
  const [formData, setFormData] = useState<CreateStoryFormData>({
    tripId: 0,
    title: "",
    content: "",
    location: "",
    isPublic: true,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.tripId || !formData.title.trim() || !formData.content.trim()) return;
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Trip
        </label>
        <select
          value={formData.tripId}
          onChange={(e) => setFormData({ ...formData, tripId: parseInt(e.target.value) })}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          required
        >
          <option value={0}>Select a trip</option>
          {trips.map((trip: Trip) => (
            <option key={trip.id} value={trip.id}>
              {trip.name}
            </option>
          ))}
        </select>
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Title
        </label>
        <Input
          value={formData.title}
          onChange={(e) => setFormData({ ...formData, title: e.target.value })}
          placeholder="Give your story a catchy title..."
          required
        />
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Location (Optional)
        </label>
        <Input
          value={formData.location}
          onChange={(e) => setFormData({ ...formData, location: e.target.value })}
          placeholder="Where did this happen?"
        />
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Your Story
        </label>
        <Textarea
          value={formData.content}
          onChange={(e) => setFormData({ ...formData, content: e.target.value })}
          placeholder="Share your amazing travel experience..."
          rows={6}
          required
        />
      </div>
      
      <div className="flex justify-end space-x-2">
        <Button type="button" variant="outline" disabled={isSubmitting}>
          Save Draft
        </Button>
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting ? "Sharing..." : "Share Story"}
        </Button>
      </div>
    </form>
  );
}