import { useState } from "react";
import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import AiTravelCompanion from "@/components/AiTravelCompanion";
import SmartBudgeting from "@/components/SmartBudgeting";
import DynamicSocialMap from "@/components/DynamicSocialMap";
import EmotionalTracker from "@/components/EmotionalTracker";
import RescueMePanicMode from "@/components/RescueMePanicMode";
import { 
  Brain, 
  DollarSign, 
  Map, 
  Heart, 
  Shield, 
  ArrowLeft,
  Sparkles
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function AdvancedFeatures() {
  const { tripId } = useParams();
  const { user, isLoading } = useAuth();
  const [activeTab, setActiveTab] = useState("ai-companion");

  const { data: trip } = useQuery({
    queryKey: ['/api/trips', tripId],
    enabled: !!tripId,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading advanced features...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="text-center py-6">
            <p className="text-gray-600 mb-4">Please log in to access advanced features.</p>
            <Link href="/api/login">
              <Button>Log In</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const features = [
    {
      id: "ai-companion",
      title: "AI Travel Companion",
      description: "Real-time decision assistant for any travel situation",
      icon: Brain,
      component: <AiTravelCompanion tripId={parseInt(tripId || "0")} />,
      color: "text-purple-600",
      bgColor: "bg-purple-50",
    },
    {
      id: "smart-budgeting", 
      title: "Smart Budgeting",
      description: "Expense tracking with automatic splitting and insights",
      icon: DollarSign,
      component: <SmartBudgeting tripId={parseInt(tripId || "0")} />,
      color: "text-green-600",
      bgColor: "bg-green-50",
    },
    {
      id: "social-map",
      title: "Dynamic Social Map",
      description: "Interactive map with location sharing and footprint trails",
      icon: Map,
      component: <DynamicSocialMap tripId={parseInt(tripId || "0")} />,
      color: "text-blue-600", 
      bgColor: "bg-blue-50",
    },
    {
      id: "emotional-tracker",
      title: "Emotional Tracker",
      description: "Monitor your travel wellbeing with AI insights",
      icon: Heart,
      component: <EmotionalTracker tripId={parseInt(tripId || "0")} />,
      color: "text-pink-600",
      bgColor: "bg-pink-50",
    },
    {
      id: "panic-mode",
      title: "Rescue Me Mode",
      description: "Emergency assistance and local help when you need it most",
      icon: Shield,
      component: <RescueMePanicMode tripId={parseInt(tripId || "0")} />,
      color: "text-red-600",
      bgColor: "bg-red-50",
    },
  ];

  const activeFeature = features.find(f => f.id === activeTab);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Link href={`/trips/${tripId}`}>
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Trip
                </Button>
              </Link>
              <div className="flex items-center space-x-2">
                <Sparkles className="h-6 w-6 text-purple-600" />
                <h1 className="text-xl font-bold text-gray-900">Advanced Features</h1>
                <Badge variant="secondary" className="bg-purple-100 text-purple-800">
                  Beta
                </Badge>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              {user?.profileImageUrl && (
                <img
                  src={user.profileImageUrl}
                  alt="Profile"
                  className="w-8 h-8 rounded-full object-cover"
                />
              )}
              <span className="text-sm font-medium">
                {user?.firstName} {user?.lastName}
              </span>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Trip Context */}
        {trip && (
          <Card className="mb-6">
            <CardContent className="py-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-semibold text-gray-900">{trip.name}</h2>
                  <p className="text-sm text-gray-600">
                    {new Date(trip.startDate).toLocaleDateString()} - {new Date(trip.endDate).toLocaleDateString()}
                  </p>
                </div>
                <Badge variant="outline" className="bg-blue-50 text-blue-700">
                  Trip ID: {tripId}
                </Badge>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Feature Overview */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Sparkles className="h-5 w-5 text-purple-600" />
              <span>Next-Generation Travel Features</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 mb-6">
              Experience the future of travel planning with AI-powered assistance, smart budgeting, 
              emotional wellbeing tracking, social mapping, and emergency support.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {features.map((feature) => {
                const Icon = feature.icon;
                return (
                  <div
                    key={feature.id}
                    className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                      activeTab === feature.id 
                        ? `border-${feature.color.split('-')[1]}-300 ${feature.bgColor}` 
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                    onClick={() => setActiveTab(feature.id)}
                  >
                    <div className="flex items-start space-x-3">
                      <div className={`p-2 rounded-lg ${feature.bgColor}`}>
                        <Icon className={`h-5 w-5 ${feature.color}`} />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-gray-900 mb-1">{feature.title}</h3>
                        <p className="text-sm text-gray-600">{feature.description}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Feature Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-5 mb-6">
            {features.map((feature) => {
              const Icon = feature.icon;
              return (
                <TabsTrigger 
                  key={feature.id} 
                  value={feature.id}
                  className="flex items-center space-x-2"
                >
                  <Icon className="h-4 w-4" />
                  <span className="hidden sm:inline">{feature.title.split(' ')[0]}</span>
                </TabsTrigger>
              );
            })}
          </TabsList>

          {features.map((feature) => (
            <TabsContent key={feature.id} value={feature.id}>
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <feature.icon className={`h-6 w-6 ${feature.color}`} />
                    <span>{feature.title}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {feature.component}
                </CardContent>
              </Card>
            </TabsContent>
          ))}
        </Tabs>

        {/* Help Section */}
        <Card className="mt-8 border-blue-200 bg-blue-50">
          <CardContent className="py-6">
            <div className="flex items-start space-x-3">
              <Sparkles className="h-5 w-5 text-blue-600 mt-0.5" />
              <div>
                <h4 className="font-medium text-blue-900 mb-2">Getting Started with Advanced Features</h4>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• <strong>AI Companion:</strong> Ask questions about your current travel situation for instant advice</li>
                  <li>• <strong>Smart Budgeting:</strong> Track expenses and automatically split costs with your travel group</li>
                  <li>• <strong>Social Map:</strong> Share locations and track your journey with automatic footprint trails</li>
                  <li>• <strong>Emotional Tracker:</strong> Monitor your travel wellbeing and get AI-powered insights</li>
                  <li>• <strong>Rescue Mode:</strong> Set up emergency contacts and access local help when needed</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}