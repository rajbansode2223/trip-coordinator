import { useParams } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { MapPin, Plus, Share2, Users, Calendar, DollarSign, ArrowLeft, Copy, Trash2, UserMinus, AlertTriangle, Sparkles } from "lucide-react";
import { Link } from "wouter";
import AddActivityModal from "@/components/AddActivityModal";
import InviteModal from "@/components/InviteModal";
import ActivityCard from "@/components/ActivityCard";
import BudgetChart from "@/components/BudgetChart";
import VirtualAssistant from "@/components/VirtualAssistant";
import SmartNavigation from "@/components/SmartNavigation";
import OnTheGoHelp from "@/components/OnTheGoHelp";
import type { Trip, Activity, User, TripParticipant } from "@shared/schema";

interface ActivityWithDetails extends Activity {
  creator: User;
  votes: any[];
  voteCount: number;
}

interface ParticipantWithUser extends TripParticipant {
  user: User;
}

export default function TripDetails() {
  const { id } = useParams();
  const tripId = parseInt(id || "0");
  const { user, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const [showAddActivityModal, setShowAddActivityModal] = useState(false);
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [activeTab, setActiveTab] = useState("timeline");

  useEffect(() => {
    if (!authLoading && !user) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [user, authLoading, toast]);

  // Load saved preferences
  useEffect(() => {
    const saved = localStorage.getItem('planit_preferences');
    if (saved) {
      try {
        const prefs = JSON.parse(saved);
        if (prefs.lastActiveTrip) {
          // Update last active trip
          localStorage.setItem('planit_preferences', JSON.stringify({
            ...prefs,
            lastActiveTrip: tripId
          }));
        }
        if (prefs.activeTab) {
          setActiveTab(prefs.activeTab);
        }
      } catch (e) {
        console.error('Error loading preferences:', e);
      }
    } else {
      // Set initial preferences
      localStorage.setItem('planit_preferences', JSON.stringify({
        lastActiveTrip: tripId,
        activeTab: 'timeline'
      }));
    }
  }, [tripId]);

  // Save tab preference
  useEffect(() => {
    const saved = localStorage.getItem('planit_preferences');
    if (saved) {
      try {
        const prefs = JSON.parse(saved);
        localStorage.setItem('planit_preferences', JSON.stringify({
          ...prefs,
          activeTab
        }));
      } catch (e) {
        console.error('Error saving preferences:', e);
      }
    }
  }, [activeTab]);

  const { data: trip, isLoading: tripLoading } = useQuery({
    queryKey: [`/api/trips/${tripId}`],
    enabled: !!tripId,
    retry: false,
  });

  const { data: activities = [], isLoading: activitiesLoading } = useQuery({
    queryKey: [`/api/trips/${tripId}/activities`],
    enabled: !!tripId,
    retry: false,
  });

  const { data: participants = [], isLoading: participantsLoading } = useQuery({
    queryKey: [`/api/trips/${tripId}/participants`],
    enabled: !!tripId,
    retry: false,
  });

  const copyTripCode = () => {
    if ((trip as Trip)?.tripCode) {
      navigator.clipboard.writeText((trip as Trip).tripCode);
      toast({
        title: "Copied!",
        description: "Trip code copied to clipboard",
      });
    }
  };

  const deleteTripMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/trips/${tripId}`);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Trip deleted successfully",
      });
      window.location.href = "/";
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to delete trip",
        variant: "destructive",
      });
    },
  });

  const leaveTripMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", `/api/trips/${tripId}/leave`);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Left trip successfully",
      });
      window.location.href = "/";
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to leave trip",
        variant: "destructive",
      });
    },
  });

  if (authLoading || tripLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="animate-pulse">
          <div className="h-16 bg-white border-b"></div>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="h-48 bg-gray-300 rounded-xl mb-8"></div>
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
              <div className="lg:col-span-3 space-y-6">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="h-32 bg-gray-300 rounded-lg"></div>
                ))}
              </div>
              <div className="space-y-6">
                <div className="h-64 bg-gray-300 rounded-lg"></div>
                <div className="h-48 bg-gray-300 rounded-lg"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!trip) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="pt-6">
            <div className="text-center">
              <MapPin className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Trip Not Found</h3>
              <p className="text-gray-600 mb-4">
                This trip doesn't exist or you don't have access to it.
              </p>
              <Link href="/">
                <Button>
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Home
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Group activities by date
  const groupedActivities = activities.reduce((groups: Record<string, ActivityWithDetails[]>, activity: ActivityWithDetails) => {
    const date = activity.date;
    if (!groups[date]) {
      groups[date] = [];
    }
    groups[date].push(activity);
    return groups;
  }, {});

  // Calculate budget stats
  const totalBudget = parseFloat(trip.budget || "0");
  const spentAmount = activities.reduce((sum: number, activity: ActivityWithDetails) => 
    sum + parseFloat(activity.estimatedCost || "0"), 0);
  const remainingBudget = totalBudget - spentAmount;
  const budgetPercentage = totalBudget > 0 ? (spentAmount / totalBudget) * 100 : 0;

  // Calculate category breakdown
  const categoryTotals = activities.reduce((totals: Record<string, number>, activity: ActivityWithDetails) => {
    const category = activity.category;
    const cost = parseFloat(activity.estimatedCost || "0");
    totals[category] = (totals[category] || 0) + cost;
    return totals;
  }, {});

  const tripDays = [];
  const startDate = new Date(trip.startDate);
  const endDate = new Date(trip.endDate);
  for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
    tripDays.push(new Date(d).toISOString().split('T')[0]);
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Link href="/">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back
                </Button>
              </Link>
              <div className="flex items-center space-x-2">
                <MapPin className="h-6 w-6 text-blue-600" />
                <h1 className="text-xl font-bold text-gray-900">Planit</h1>
              </div>
              <span className="text-gray-300">|</span>
              <span className="font-medium text-gray-700">{trip.name}</span>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="outline" onClick={() => setShowInviteModal(true)}>
                <Share2 className="h-4 w-4 mr-2" />
                Invite
              </Button>
              <Button onClick={() => setShowAddActivityModal(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Add Activity
              </Button>
              <div className="flex items-center space-x-2">
                {user?.profileImageUrl && (
                  <img
                    src={user.profileImageUrl}
                    alt="Profile"
                    className="w-8 h-8 rounded-full object-cover"
                  />
                )}
                <span className="text-sm font-medium">
                  {user?.firstName} {user?.lastName}
                </span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Smart Navigation */}
        <SmartNavigation />

        {/* Trip Header */}
        <Card className="mb-8 overflow-hidden">
          <div className="h-48 bg-gradient-to-r from-blue-500 to-cyan-500 relative">
            <div className="absolute inset-0 bg-black bg-opacity-30"></div>
            <div className="relative p-8 text-white">
              <h1 className="text-4xl font-bold mb-2">{trip.name}</h1>
              <div className="flex items-center space-x-6 text-sm">
                <span>
                  <Calendar className="h-4 w-4 inline mr-2" />
                  {new Date(trip.startDate).toLocaleDateString()} - {new Date(trip.endDate).toLocaleDateString()}
                </span>
                <span>
                  <Users className="h-4 w-4 inline mr-2" />
                  {participants.length} travelers
                </span>
                <span>
                  <DollarSign className="h-4 w-4 inline mr-2" />
                  ${totalBudget.toLocaleString()} budget
                </span>
                <div className="bg-white/20 px-3 py-1 rounded-full cursor-pointer" onClick={copyTripCode}>
                  Trip Code: {trip.tripCode}
                  <Copy className="h-3 w-3 inline ml-1" />
                </div>
              </div>
              <div className="absolute top-4 right-4">
                <Link href={`/trips/${id}/features`}>
                  <Button className="bg-white/20 hover:bg-white/30 text-white border-white/30">
                    <Sparkles className="h-4 w-4 mr-2" />
                    Advanced Features
                  </Button>
                </Link>
              </div>
            </div>
          </div>
          
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">{activities.length}</div>
                <div className="text-sm text-gray-600">Total Activities</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">
                  {activities.filter((a: ActivityWithDetails) => a.isLockedIn).length}
                </div>
                <div className="text-sm text-gray-600">Locked In</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-orange-600">${spentAmount.toLocaleString()}</div>
                <div className="text-sm text-gray-600">Planned Cost</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">${remainingBudget.toLocaleString()}</div>
                <div className="text-sm text-gray-600">Remaining</div>
              </div>
            </div>
            
            {totalBudget > 0 && (
              <div className="mt-6">
                <div className="flex justify-between text-sm text-gray-600 mb-2">
                  <span>Budget Usage</span>
                  <span>{budgetPercentage.toFixed(1)}% used</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-gradient-to-r from-green-500 to-orange-500 h-2 rounded-full transition-all duration-300" 
                    style={{ width: `${Math.min(budgetPercentage, 100)}%` }}
                  ></div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="timeline">Timeline</TabsTrigger>
                <TabsTrigger value="budget">Budget</TabsTrigger>
                <TabsTrigger value="participants">Participants</TabsTrigger>
              </TabsList>
              
              <TabsContent value="timeline" className="space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-semibold text-gray-900">Trip Timeline</h2>
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm">All Activities</Button>
                    <Button variant="outline" size="sm">Locked In Only</Button>
                  </div>
                </div>

                {tripDays.map((date) => {
                  const dayActivities = groupedActivities[date] || [];
                  const dayNumber = Math.floor((new Date(date).getTime() - new Date(trip.startDate).getTime()) / (1000 * 60 * 60 * 24)) + 1;
                  
                  return (
                    <Card key={date}>
                      <CardHeader>
                        <div className="flex items-center space-x-3">
                          <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold">
                            {dayNumber}
                          </div>
                          <div>
                            <CardTitle>Day {dayNumber} - {new Date(date).toLocaleDateString()}</CardTitle>
                            <p className="text-sm text-gray-600">
                              {new Date(date).toLocaleDateString('en-US', { weekday: 'long' })}
                            </p>
                          </div>
                          <div className="ml-auto">
                            <span className="text-sm text-gray-500">
                              {dayActivities.length} activities
                            </span>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        {dayActivities.length > 0 ? (
                          <div className="space-y-4">
                            {dayActivities.map((activity) => (
                              <ActivityCard 
                                key={activity.id} 
                                activity={activity} 
                                currentUserId={user?.id || ""}
                              />
                            ))}
                          </div>
                        ) : (
                          <div className="text-center py-8 text-gray-500">
                            <Calendar className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                            <p>No activities planned for this day</p>
                            <Button 
                              variant="outline" 
                              className="mt-4"
                              onClick={() => setShowAddActivityModal(true)}
                            >
                              Add Activity
                            </Button>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  );
                })}
              </TabsContent>

              <TabsContent value="budget">
                <BudgetChart 
                  totalBudget={totalBudget}
                  spentAmount={spentAmount}
                  categoryTotals={categoryTotals}
                />
              </TabsContent>

              <TabsContent value="participants">
                <Card>
                  <CardHeader>
                    <CardTitle>Trip Participants</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {participantsLoading ? (
                        <div className="space-y-3">
                          {[1, 2, 3].map((i) => (
                            <div key={i} className="flex items-center space-x-3">
                              <div className="w-12 h-12 bg-gray-300 rounded-full animate-pulse"></div>
                              <div className="flex-1">
                                <div className="h-4 bg-gray-300 rounded w-1/4 mb-2 animate-pulse"></div>
                                <div className="h-3 bg-gray-300 rounded w-1/3 animate-pulse"></div>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        participants.map((participant: ParticipantWithUser) => (
                          <div key={participant.id} className="flex items-center space-x-3">
                            {participant.user.profileImageUrl ? (
                              <img
                                src={participant.user.profileImageUrl}
                                alt={`${participant.user.firstName} ${participant.user.lastName}`}
                                className="w-12 h-12 rounded-full object-cover"
                              />
                            ) : (
                              <div className="w-12 h-12 bg-gray-300 rounded-full flex items-center justify-center">
                                <Users className="h-6 w-6 text-gray-600" />
                              </div>
                            )}
                            <div className="flex-1">
                              <div className="flex items-center space-x-2">
                                <h4 className="font-medium text-gray-900">
                                  {participant.user.firstName} {participant.user.lastName}
                                </h4>
                                {participant.userId === trip.creatorId && (
                                  <Badge variant="secondary">Creator</Badge>
                                )}
                              </div>
                              <p className="text-sm text-gray-600">{participant.user.email}</p>
                            </div>
                            <div className="text-sm text-gray-500">
                              Joined {new Date(participant.joinedAt).toLocaleDateString()}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button 
                  className="w-full justify-start" 
                  onClick={() => setShowAddActivityModal(true)}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Activity
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start"
                  onClick={() => setShowInviteModal(true)}
                >
                  <Share2 className="h-4 w-4 mr-2" />
                  Invite Friends
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start"
                  onClick={copyTripCode}
                >
                  <Copy className="h-4 w-4 mr-2" />
                  Copy Trip Code
                </Button>
              </CardContent>
            </Card>

            {/* Trip Management */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-red-600">
                  <AlertTriangle className="h-5 w-5 mr-2" />
                  Trip Management
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {(user as any)?.id === (trip as Trip)?.creatorId ? (
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button 
                        variant="destructive" 
                        className="w-full justify-start"
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete Trip
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete Trip</AlertDialogTitle>
                        <AlertDialogDescription>
                          Are you sure you want to delete this trip? This action cannot be undone. 
                          All activities, participants, and trip data will be permanently removed.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => deleteTripMutation.mutate()}
                          disabled={deleteTripMutation.isPending}
                          className="bg-red-600 hover:bg-red-700"
                        >
                          {deleteTripMutation.isPending ? "Deleting..." : "Delete Trip"}
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                ) : (
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button 
                        variant="outline" 
                        className="w-full justify-start text-red-600 border-red-300 hover:bg-red-50"
                      >
                        <UserMinus className="h-4 w-4 mr-2" />
                        Leave Trip
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Leave Trip</AlertDialogTitle>
                        <AlertDialogDescription>
                          Are you sure you want to leave this trip? You'll no longer have access 
                          to the trip details, activities, or be able to participate in planning.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => leaveTripMutation.mutate()}
                          disabled={leaveTripMutation.isPending}
                          className="bg-red-600 hover:bg-red-700"
                        >
                          {leaveTripMutation.isPending ? "Leaving..." : "Leave Trip"}
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                )}
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm">
                  {activities.slice(0, 5).map((activity: ActivityWithDetails) => (
                    <div key={activity.id} className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                      <div>
                        <p className="font-medium">{activity.title}</p>
                        <p className="text-gray-600">
                          Added by {activity.creator.firstName} {activity.creator.lastName}
                        </p>
                      </div>
                    </div>
                  ))}
                  {activities.length === 0 && (
                    <p className="text-gray-500">No activities yet</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* Modals */}
      <AddActivityModal
        open={showAddActivityModal}
        onOpenChange={setShowAddActivityModal}
        tripId={tripId}
        tripDates={{ startDate: trip.startDate, endDate: trip.endDate }}
      />

      <InviteModal
        open={showInviteModal}
        onOpenChange={setShowInviteModal}
        tripCode={(trip as Trip).tripCode}
      />

      <OnTheGoHelp />
    </div>
  );
}
