import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MapPin, DollarSign, Calendar, Sparkles, Plus, Trash2, Clock, Globe } from "lucide-react";
import { Link } from "wouter";
import SmartNavigation from "@/components/SmartNavigation";
import OnTheGoHelp from "@/components/OnTheGoHelp";
import type { TripRecommendation, User } from "@shared/schema";

interface RecommendationFormData {
  budget: string;
  preferredAreas: string;
  travelStyle: string;
  duration: string;
}

export default function Recommendations() {
  const { user, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const [formData, setFormData] = useState<RecommendationFormData>({
    budget: "",
    preferredAreas: "",
    travelStyle: "",
    duration: "7",
  });

  useEffect(() => {
    if (!authLoading && !user) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [user, authLoading, toast]);

  const { data: recommendations = [], isLoading: recommendationsLoading, refetch } = useQuery<TripRecommendation[]>({
    queryKey: ["/api/recommendations"],
    retry: false,
  });

  const generateMutation = useMutation({
    mutationFn: async (data: RecommendationFormData) => {
      const response = await apiRequest("POST", "/api/recommendations/generate", {
        budget: parseFloat(data.budget),
        preferredAreas: data.preferredAreas.split(",").map(area => area.trim()).filter(Boolean),
        travelStyle: data.travelStyle || undefined,
        duration: parseInt(data.duration),
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recommendations"] });
      toast({
        title: "Success",
        description: "New travel recommendations generated!",
      });
      refetch();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to generate recommendations",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/recommendations/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recommendations"] });
      toast({
        title: "Success",
        description: "Recommendation deleted successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to delete recommendation",
        variant: "destructive",
      });
    },
  });

  const createTripMutation = useMutation({
    mutationFn: async (recommendationId: number) => {
      const response = await apiRequest("POST", `/api/recommendations/${recommendationId}/create-trip`);
      return response.json();
    },
    onSuccess: (trip) => {
      queryClient.invalidateQueries({ queryKey: ["/api/trips"] });
      toast({
        title: "Success",
        description: "Trip created from recommendation!",
      });
      window.location.href = `/trips/${trip.id}`;
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to create trip from recommendation",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.budget || parseFloat(formData.budget) <= 0) {
      toast({
        title: "Invalid budget",
        description: "Please enter a valid budget amount",
        variant: "destructive",
      });
      return;
    }
    generateMutation.mutate(formData);
  };

  const formatBudgetBreakdown = (breakdown: any) => {
    if (!breakdown || typeof breakdown !== 'object') return [];
    return Object.entries(breakdown).map(([key, value]) => ({
      category: key.charAt(0).toUpperCase() + key.slice(1),
      amount: Number(value)
    }));
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-300 rounded w-64 mb-8"></div>
          <div className="space-y-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-48 bg-gray-300 rounded-xl w-96"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Link href="/">
                <Button variant="ghost" size="sm">
                  ← Back to Home
                </Button>
              </Link>
              <div className="flex items-center space-x-2">
                <Sparkles className="h-6 w-6 text-purple-600" />
                <h1 className="text-xl font-bold text-gray-900">Trip Recommendations</h1>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              {(user as User)?.profileImageUrl && (
                <img
                  src={(user as User).profileImageUrl || ""}
                  alt="Profile"
                  className="w-8 h-8 rounded-full object-cover"
                />
              )}
              <span className="text-sm font-medium">
                {(user as User)?.firstName} {(user as User)?.lastName}
              </span>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Smart Navigation */}
        <SmartNavigation />

        <Tabs defaultValue="generate" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="generate">Generate New</TabsTrigger>
            <TabsTrigger value="saved">Saved Recommendations</TabsTrigger>
          </TabsList>

          <TabsContent value="generate">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Sparkles className="h-5 w-5 text-purple-600" />
                  <span>Get AI-Powered Travel Recommendations</span>
                </CardTitle>
                <CardDescription>
                  Tell us your budget and preferences, and we'll suggest amazing destinations that fit your criteria.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="budget">Total Budget (USD)</Label>
                      <Input
                        id="budget"
                        type="number"
                        placeholder="e.g., 3000"
                        value={formData.budget}
                        onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="duration">Trip Duration (days)</Label>
                      <Select
                        value={formData.duration}
                        onValueChange={(value) => setFormData({ ...formData, duration: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select duration" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="3">3 days</SelectItem>
                          <SelectItem value="5">5 days</SelectItem>
                          <SelectItem value="7">7 days</SelectItem>
                          <SelectItem value="10">10 days</SelectItem>
                          <SelectItem value="14">14 days</SelectItem>
                          <SelectItem value="21">21 days</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="preferredAreas">Preferred Areas/Regions</Label>
                    <Input
                      id="preferredAreas"
                      placeholder="e.g., Southeast Asia, Europe, Caribbean, Japan"
                      value={formData.preferredAreas}
                      onChange={(e) => setFormData({ ...formData, preferredAreas: e.target.value })}
                    />
                    <p className="text-sm text-gray-600">
                      Separate multiple areas with commas, or leave blank for worldwide suggestions
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="travelStyle">Travel Style (optional)</Label>
                    <Select
                      value={formData.travelStyle}
                      onValueChange={(value) => setFormData({ ...formData, travelStyle: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select your travel style" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="budget">Budget/Backpacker</SelectItem>
                        <SelectItem value="mid-range">Mid-range</SelectItem>
                        <SelectItem value="luxury">Luxury</SelectItem>
                        <SelectItem value="adventure">Adventure</SelectItem>
                        <SelectItem value="cultural">Cultural</SelectItem>
                        <SelectItem value="relaxation">Relaxation</SelectItem>
                        <SelectItem value="family">Family-friendly</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Button
                    type="submit"
                    className="w-full"
                    disabled={generateMutation.isPending}
                  >
                    {generateMutation.isPending ? (
                      <Clock className="h-4 w-4 mr-2 animate-spin" />
                    ) : (
                      <Sparkles className="h-4 w-4 mr-2" />
                    )}
                    {generateMutation.isPending ? "Generating..." : "Generate Recommendations"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="saved">
            {recommendationsLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="h-96 bg-gray-300 rounded-xl animate-pulse"></div>
                ))}
              </div>
            ) : recommendations.length === 0 ? (
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center py-12">
                    <Globe className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No recommendations yet</h3>
                    <p className="text-gray-600 mb-6">
                      Generate your first AI-powered travel recommendations to get started.
                    </p>
                    <Button onClick={() => {
                      const generateTab = document.querySelector('[value="generate"]') as HTMLElement;
                      generateTab?.click();
                    }}>
                      <Sparkles className="h-4 w-4 mr-2" />
                      Generate Recommendations
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {recommendations.map((rec: TripRecommendation) => (
                  <Card key={rec.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="text-lg">{rec.destination}</CardTitle>
                          <CardDescription className="flex items-center mt-1">
                            <MapPin className="h-4 w-4 mr-1" />
                            {rec.country}
                          </CardDescription>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteMutation.mutate(rec.id)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <p className="text-sm text-gray-600 line-clamp-3">{rec.description}</p>
                        
                        <div className="flex items-center justify-between text-sm">
                          <span className="flex items-center text-gray-600">
                            <DollarSign className="h-4 w-4 mr-1" />
                            Budget
                          </span>
                          <span className="font-medium">${parseFloat(rec.estimatedBudget).toLocaleString()}</span>
                        </div>
                        
                        <div className="flex items-center justify-between text-sm">
                          <span className="flex items-center text-gray-600">
                            <Calendar className="h-4 w-4 mr-1" />
                            Duration
                          </span>
                          <span className="font-medium">{rec.duration} days</span>
                        </div>

                        {rec.bestTime && (
                          <div className="text-sm">
                            <span className="font-medium text-gray-700">Best Time:</span>
                            <p className="text-gray-600">{rec.bestTime}</p>
                          </div>
                        )}

                        {rec.highlights && Array.isArray(rec.highlights) && rec.highlights.length > 0 && (
                          <div>
                            <span className="text-sm font-medium text-gray-700">Highlights:</span>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {rec.highlights.slice(0, 3).map((highlight: string, index: number) => (
                                <Badge key={index} variant="secondary" className="text-xs">
                                  {highlight}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}

                        {rec.budgetBreakdown && (
                          <div>
                            <span className="text-sm font-medium text-gray-700">Budget Breakdown:</span>
                            <div className="grid grid-cols-2 gap-1 mt-1 text-xs">
                              {formatBudgetBreakdown(rec.budgetBreakdown).slice(0, 4).map((item: any, index: number) => (
                                <div key={index} className="flex justify-between">
                                  <span className="text-gray-600">{item.category}:</span>
                                  <span className="font-medium">${item.amount.toLocaleString()}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        <Button
                          className="w-full"
                          onClick={() => createTripMutation.mutate(rec.id)}
                          disabled={createTripMutation.isPending}
                        >
                          <Plus className="h-4 w-4 mr-2" />
                          Create Trip from This
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </main>
      
      <OnTheGoHelp />
    </div>
  );
}