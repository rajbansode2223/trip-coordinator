import { useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { MapPin, Plus, Users, Calendar, DollarSign, Sparkles, BookOpen } from "lucide-react";
import { Link } from "wouter";
import CreateTripModal from "@/components/CreateTripModal";
import TripCard from "@/components/TripCard";
import VirtualAssistant from "@/components/VirtualAssistant";
import SmartNavigation from "@/components/SmartNavigation";
import OnTheGoHelp from "@/components/OnTheGoHelp";
import type { Trip, User } from "@shared/schema";

export default function Home() {
  const { user, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showJoinModal, setShowJoinModal] = useState(false);
  const [tripCode, setTripCode] = useState("");

  useEffect(() => {
    if (!authLoading && !user) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [user, authLoading, toast]);

  const { data: trips, isLoading } = useQuery<Trip[]>({
    queryKey: ["/api/trips"],
    retry: false,
  });

  const joinTripMutation = useMutation({
    mutationFn: async (tripCode: string) => {
      await apiRequest("POST", "/api/trips/join", { tripCode });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/trips"] });
      setShowJoinModal(false);
      setTripCode("");
      toast({
        title: "Success",
        description: "Joined trip successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to join trip",
        variant: "destructive",
      });
    },
  });

  if (authLoading || isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <header className="bg-white shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center space-x-2">
                <MapPin className="h-8 w-8 text-blue-600" />
                <h1 className="text-2xl font-bold text-gray-900">Planit</h1>
              </div>
              <div className="flex items-center space-x-4">
                <div className="w-8 h-8 bg-gray-300 rounded-full animate-pulse"></div>
              </div>
            </div>
          </div>
        </header>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-300 rounded w-1/4 mb-8"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-64 bg-gray-300 rounded-xl"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <MapPin className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900">Planit</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Link href="/feed">
                <Button variant="outline" className="flex items-center space-x-2">
                  <BookOpen className="h-4 w-4" />
                  <span>Trip Stories</span>
                </Button>
              </Link>
              <Link href="/recommendations">
                <Button variant="outline" className="flex items-center space-x-2">
                  <Sparkles className="h-4 w-4" />
                  <span>AI Recommendations</span>
                </Button>
              </Link>
              <Button variant="outline" onClick={() => setShowJoinModal(true)}>
                Join Trip
              </Button>
              <Button onClick={() => setShowCreateModal(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Create Trip
              </Button>
              <div className="flex items-center space-x-2">
                {(user as User)?.profileImageUrl && (
                  <img
                    src={(user as User).profileImageUrl || ""}
                    alt="Profile"
                    className="w-8 h-8 rounded-full object-cover"
                  />
                )}
                <span className="text-sm font-medium">
                  {(user as User)?.firstName} {(user as User)?.lastName}
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => window.location.href = "/api/logout"}
                >
                  Logout
                </Button>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Smart Navigation */}
        <SmartNavigation />

        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">
            Welcome back, {(user as User)?.firstName}!
          </h2>
          <p className="text-gray-600">
            Ready to plan your next adventure? Here are your trips.
          </p>
        </div>

        {/* Quick Stats */}
        {trips && trips.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Trips</CardTitle>
                <MapPin className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{trips.length}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Trips</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {trips.filter((trip: Trip) => new Date(trip.endDate) >= new Date()).length}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">This Month</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {trips.filter((trip: Trip) => {
                    const tripDate = new Date(trip.startDate);
                    const now = new Date();
                    return tripDate.getMonth() === now.getMonth() && tripDate.getFullYear() === now.getFullYear();
                  }).length}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Budget</CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  ${trips.reduce((sum: number, trip: Trip) => sum + (parseFloat(trip.budget || "0")), 0).toLocaleString()}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Trips Grid */}
        {trips && trips.length > 0 ? (
          <div>
            <h3 className="text-xl font-semibold text-gray-900 mb-6">Your Trips</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {trips.map((trip: Trip) => (
                <TripCard key={trip.id} trip={trip} />
              ))}
            </div>
          </div>
        ) : (
          <div className="text-center py-16">
            <MapPin className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No trips yet</h3>
            <p className="text-gray-600 mb-6">
              Create your first trip or join an existing one with a trip code.
            </p>
            <div className="flex justify-center space-x-4">
              <Button onClick={() => setShowCreateModal(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Create Trip
              </Button>
              <Button variant="outline" onClick={() => setShowJoinModal(true)}>
                Join Trip
              </Button>
            </div>
          </div>
        )}
      </main>

      {/* Create Trip Modal */}
      <CreateTripModal 
        open={showCreateModal} 
        onOpenChange={setShowCreateModal} 
      />

      {/* Join Trip Modal */}
      <Dialog open={showJoinModal} onOpenChange={setShowJoinModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Join a Trip</DialogTitle>
            <DialogDescription>
              Enter the trip code shared by your friend to join their trip.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <Input
              placeholder="Enter trip code (e.g., ABC123XY)"
              value={tripCode}
              onChange={(e) => setTripCode(e.target.value.toUpperCase())}
              className="font-mono"
            />
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setShowJoinModal(false)}>
                Cancel
              </Button>
              <Button 
                onClick={() => joinTripMutation.mutate(tripCode)}
                disabled={!tripCode || joinTripMutation.isPending}
              >
                {joinTripMutation.isPending ? "Joining..." : "Join Trip"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <OnTheGoHelp />
    </div>
  );
}
